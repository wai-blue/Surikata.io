set foreign_key_checks = 0;;
drop table if exists `srkt_adios_config`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_adios_translate`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_adios_users`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_adios_roles`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_adios_tokens`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_blogs`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_blogs_tags`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_blogs_tags_assignment`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_dpd_vydajne_miesta`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_homepage_slideshow`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_news`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_compare`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_variations`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_variations_attributes`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_variations_groups_attributes`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_variations_groups_items`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_variations_values`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_addresses`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_categories`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_products_compared`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_products_displayed`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_tokens`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_uid`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_watchdog`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_wishlist`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_customers_search_queries`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_shopping_carts`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_shopping_carts_items`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_vouchers`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_contact_form`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_newsletter`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_claims`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_orders`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_orders_history`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_orders_items`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_orders_tags`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_orders_tags_assignment`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_invoices`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_invoices_items`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_invoice_numeric_series`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_merchants`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_brands`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_accessories`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_categories`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_categories_assignment`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_product_price_discounts`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_domains_assignment`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_extensions`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_features`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_features_assignment`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_gallery`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_product_price_margins`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_product_prices`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_related`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_services_assignment`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_sets`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_sets_items`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_products_stock_states`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_services`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_suppliers`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_shipping_delivery_services`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_shipping_destination_countries`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_shipping_payment_services`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_shipping_shipments`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_shipping_prices`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_web_menu`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_web_menu_items`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_web_pages`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_web_redirects`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_web_translations`;;
set foreign_key_checks = 1;;
set foreign_key_checks = 0;;
drop table if exists `srkt_units`;;
set foreign_key_checks = 1;;
start transaction;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_adios_config`;;
drop table if exists `srkt_adios_config`;;
create table `srkt_adios_config` (
  `id` int(8) primary key auto_increment,
  `path` varchar(250)  default '' ,
  `value` text ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_adios_config`
              add constraint `path` unique (`path`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Core-Models-Config/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Core-Models-Config/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_adios_translate`;;
drop table if exists `srkt_adios_translate`;;
create table `srkt_adios_translate` (
  `id` int(8) primary key auto_increment,
  `hash` varchar(32)  default '' ,
  `value` varchar(255)  default '' ,
  `context` varchar(120)  default '' ,
  `lang` varchar(2)  default '' ,
  `category` varchar(50)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Core-Models-Translate/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Core-Models-Translate/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_adios_users`;;
drop table if exists `srkt_adios_users`;;
create table `srkt_adios_users` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  `surname` varchar(255)  default '' ,
  `login` varchar(255)  default '' ,
  `password` varchar(255)  default '' ,
  `email` varchar(255)  default '' ,
  `id_role` int(8)  NULL ,
  `photo` varchar(255)  default '' ,
  `active` boolean  NOT NULL default 0 ,
  index `id` (`id`),
  index `id_role` (`id_role`),
  index `active` (`active`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Core-Models-User/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Core-Models-User/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_adios_roles`;;
drop table if exists `srkt_adios_roles`;;
create table `srkt_adios_roles` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Core-Models-UserRole/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Core-Models-UserRole/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_adios_tokens`;;
drop table if exists `srkt_adios_tokens`;;
create table `srkt_adios_tokens` (
  `id` int(8) primary key auto_increment,
  `type` int(8)  default null ,
  `valid_to` datetime  default null ,
  `token` varchar(255)  default '' ,
  index `id` (`id`),
  index `type` (`type`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_adios_tokens`
              add index `uid` (`token`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Core-Models-Token/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Core-Models-Token/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_blogs`;;
drop table if exists `srkt_blogs`;;
create table `srkt_blogs` (
  `id` int(8) primary key auto_increment,
  `domain` varchar(255)  default '' ,
  `name` varchar(255)  default '' ,
  `content` text ,
  `perex` text ,
  `image` varchar(255)  default '' ,
  `created_at` date  default null ,
  `id_user` int(8)  NULL ,
  index `id` (`id`),
  index `created_at` (`created_at`),
  index `id_user` (`id_user`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Blog-Catalog-Models-Blog/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Blog-Catalog-Models-Blog/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_blogs_tags`;;
drop table if exists `srkt_blogs_tags`;;
create table `srkt_blogs_tags` (
  `id` int(8) primary key auto_increment,
  `domain` varchar(255)  default '' ,
  `name` varchar(255)  default '' ,
  `description` text ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_blogs_tags`
              add constraint `unique_name_for_domain` unique (`name`, `domain`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Blog-Catalog-Models-BlogTag/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Blog-Catalog-Models-BlogTag/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_blogs_tags_assignment`;;
drop table if exists `srkt_blogs_tags_assignment`;;
create table `srkt_blogs_tags_assignment` (
  `id` int(8) primary key auto_increment,
  `id_blog` int(8)  NULL ,
  `id_tag` int(8)  NULL ,
  index `id` (`id`),
  index `id_blog` (`id_blog`),
  index `id_tag` (`id_tag`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Blog-Catalog-Models-BlogTagAssignment/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Blog-Catalog-Models-BlogTagAssignment/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_dpd_vydajne_miesta`;;
drop table if exists `srkt_dpd_vydajne_miesta`;;
create table `srkt_dpd_vydajne_miesta` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  `logo` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Delivery-DPD-Models-DPDVydajneMiesto/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Delivery-DPD-Models-DPDVydajneMiesto/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_homepage_slideshow`;;
drop table if exists `srkt_homepage_slideshow`;;
create table `srkt_homepage_slideshow` (
  `id` int(8) primary key auto_increment,
  `domain` varchar(255)  default '' ,
  `heading` varchar(255)  default '' ,
  `description` varchar(255)  default '' ,
  `button_url` varchar(255)  default '' ,
  `button_text` varchar(255)  default '' ,
  `image` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_homepage_slideshow`
              add index `domain` (`domain`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Misc-Slideshow-Models-HomepageSlideshow/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Misc-Slideshow-Models-HomepageSlideshow/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_news`;;
drop table if exists `srkt_news`;;
create table `srkt_news` (
  `id` int(8) primary key auto_increment,
  `title` varchar(255)  default '' ,
  `content` text ,
  `image` varchar(255)  default '' ,
  `perex` text ,
  `domain` varchar(255)  default '' ,
  `show_from` date  default null ,
  index `id` (`id`),
  index `show_from` (`show_from`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-News-Models-News/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-News-Models-News/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_compare`;;
drop table if exists `srkt_products_compare`;;
create table `srkt_products_compare` (
  `id` int(8) primary key auto_increment,
  `id_customer_uid` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  index `id` (`id`),
  index `id_customer_uid` (`id_customer_uid`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_products_compare`
              add constraint `unique_copmarison` unique (`id_customer_uid`, `id_product`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Proprietary-Product-Compare-Models-ProductCompare/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Proprietary-Product-Compare-Models-ProductCompare/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_variations`;;
drop table if exists `srkt_products_variations`;;
create table `srkt_products_variations` (
  `group_uid` int(8)  default null ,
  `id_product` int(8)  NULL ,
  `id_attribute` int(8)  NULL ,
  `id_value` int(8)  NULL ,
  index `group_uid` (`group_uid`),
  index `id_product` (`id_product`),
  index `id_attribute` (`id_attribute`),
  index `id_value` (`id_value`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariation/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariation/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_variations_attributes`;;
drop table if exists `srkt_products_variations_attributes`;;
create table `srkt_products_variations_attributes` (
  `id` int(8) primary key auto_increment,
  `name_lang_1` varchar(255)  default '' ,
  `name_lang_2` varchar(255)  default '' ,
  `name_lang_3` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariationAttribute/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariationAttribute/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_variations_groups_attributes`;;
drop table if exists `srkt_products_variations_groups_attributes`;;
create table `srkt_products_variations_groups_attributes` (
  `group_uid` int(8)  default null ,
  `id_attribute` int(8)  NULL ,
  index `group_uid` (`group_uid`),
  index `id_attribute` (`id_attribute`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_products_variations_groups_attributes`
              add constraint `c59c550b60d7b2e411b3eada68b56105` unique (`group_uid`, `id_attribute`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariationGroupAttribute/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariationGroupAttribute/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_variations_groups_items`;;
drop table if exists `srkt_products_variations_groups_items`;;
create table `srkt_products_variations_groups_items` (
  `group_uid` int(8)  default null ,
  `id_product` int(8)  NULL ,
  index `group_uid` (`group_uid`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_products_variations_groups_items`
              add constraint `6cda84a66a7e23faa95eb6f46f254564` unique (`group_uid`, `id_product`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariationGroupItem/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariationGroupItem/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_variations_values`;;
drop table if exists `srkt_products_variations_values`;;
create table `srkt_products_variations_values` (
  `id` int(8) primary key auto_increment,
  `id_attribute` int(8)  NULL ,
  `value_lang_1` varchar(255)  default '' ,
  `value_lang_2` varchar(255)  default '' ,
  `value_lang_3` varchar(255)  default '' ,
  index `id` (`id`),
  index `id_attribute` (`id_attribute`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariationValue/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Plugins-WAI-Proprietary-Product-Variations-Models-ProductVariationValue/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers`;;
drop table if exists `srkt_customers`;;
create table `srkt_customers` (
  `id` int(8) primary key auto_increment,
  `id_category` int(8)  NULL ,
  `email` varchar(255)  default '' ,
  `given_name` varchar(255)  default '' ,
  `family_name` varchar(255)  default '' ,
  `company_name` varchar(255)  default '' ,
  `company_id` varchar(255)  default '' ,
  `company_tax_id` varchar(255)  default '' ,
  `company_vat_id` varchar(255)  default '' ,
  `inv_given_name` varchar(255)  default '' ,
  `inv_family_name` varchar(255)  default '' ,
  `inv_company_name` varchar(255)  default '' ,
  `inv_street_1` varchar(255)  default '' ,
  `inv_street_2` varchar(255)  default '' ,
  `inv_city` varchar(255)  default '' ,
  `inv_zip` varchar(255)  default '' ,
  `inv_region` varchar(255)  default '' ,
  `inv_country` varchar(255)  default '' ,
  `password` varchar(255)  default '' ,
  `is_wholesale` boolean  NOT NULL default 0 ,
  `is_validated` boolean  NOT NULL default 0 ,
  `is_blocked` boolean  NOT NULL default 0 ,
  `last_login` datetime  default null ,
  `consent_privacy` boolean  NOT NULL default 0 ,
  `consent_newsletter` boolean  NOT NULL default 0 ,
  index `id` (`id`),
  index `id_category` (`id_category`),
  index `is_wholesale` (`is_wholesale`),
  index `is_validated` (`is_validated`),
  index `is_blocked` (`is_blocked`),
  index `consent_privacy` (`consent_privacy`),
  index `consent_newsletter` (`consent_newsletter`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_customers`
              add constraint `uid` unique (`email`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-Customer/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-Customer/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_addresses`;;
drop table if exists `srkt_customers_addresses`;;
create table `srkt_customers_addresses` (
  `id` int(8) primary key auto_increment,
  `id_customer` int(8)  NULL ,
  `hash` varchar(255)  default '' ,
  `del_given_name` varchar(255)  default '' ,
  `del_family_name` varchar(255)  default '' ,
  `del_company_name` varchar(255)  default '' ,
  `del_street_1` varchar(255)  default '' ,
  `del_street_2` varchar(255)  default '' ,
  `del_floor` varchar(255)  default '' ,
  `del_city` varchar(255)  default '' ,
  `del_zip` varchar(255)  default '' ,
  `del_region` varchar(255)  default '' ,
  `del_country` varchar(255)  default '' ,
  `phone_number` varchar(255)  default '' ,
  `email` varchar(255)  default '' ,
  index `id` (`id`),
  index `id_customer` (`id_customer`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_customers_addresses`
              add index `hash` (`hash`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-CustomerAddress/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-CustomerAddress/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_categories`;;
drop table if exists `srkt_customers_categories`;;
create table `srkt_customers_categories` (
  `id` int(8) primary key auto_increment,
  `code` varchar(255)  default '' ,
  `name` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-CustomerCategory/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-CustomerCategory/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_products_compared`;;
drop table if exists `srkt_customers_products_compared`;;
create table `srkt_customers_products_compared` (
  `id` int(8) primary key auto_increment,
  `id_customer_uid` int(8)  NULL ,
  `id_product_1` int(8)  NULL ,
  `id_product_2` int(8)  NULL ,
  `comparison_datetime` datetime  default null ,
  index `id` (`id`),
  index `id_customer_uid` (`id_customer_uid`),
  index `id_product_1` (`id_product_1`),
  index `id_product_2` (`id_product_2`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-CustomerProductCompared/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-CustomerProductCompared/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_products_displayed`;;
drop table if exists `srkt_customers_products_displayed`;;
create table `srkt_customers_products_displayed` (
  `id` int(8) primary key auto_increment,
  `id_customer_uid` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  `display_datetime` datetime  default null ,
  index `id` (`id`),
  index `id_customer_uid` (`id_customer_uid`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-CustomerProductDisplayed/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-CustomerProductDisplayed/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_tokens`;;
drop table if exists `srkt_customers_tokens`;;
create table `srkt_customers_tokens` (
  `id` int(8) primary key auto_increment,
  `id_customer` int(8)  NULL ,
  `id_token` int(8)  NULL ,
  index `id` (`id`),
  index `id_customer` (`id_customer`),
  index `id_token` (`id_token`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-CustomerTokenAssignment/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-CustomerTokenAssignment/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_uid`;;
drop table if exists `srkt_customers_uid`;;
create table `srkt_customers_uid` (
  `id` int(8) primary key auto_increment,
  `id_customer` int(8)  NULL ,
  `uid` varchar(255)  default '' ,
  `cookie_consent` varchar(255)  default '' ,
  `cookie_date` datetime  default null ,
  index `id` (`id`),
  index `id_customer` (`id_customer`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_customers_uid`
              add index `uid` (`uid`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-CustomerUID/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-CustomerUID/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_watchdog`;;
drop table if exists `srkt_customers_watchdog`;;
create table `srkt_customers_watchdog` (
  `id` int(8) primary key auto_increment,
  `id_customer` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  index `id` (`id`),
  index `id_customer` (`id_customer`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_customers_watchdog`
              add constraint `id_customer___id_product` unique (`id_customer`, `id_product`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-CustomerWatchdog/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-CustomerWatchdog/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_wishlist`;;
drop table if exists `srkt_customers_wishlist`;;
create table `srkt_customers_wishlist` (
  `id` int(8) primary key auto_increment,
  `id_customer` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  index `id` (`id`),
  index `id_customer` (`id_customer`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_customers_wishlist`
              add constraint `id_customer___id_product` unique (`id_customer`, `id_product`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-CustomerWishlist/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-CustomerWishlist/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_customers_search_queries`;;
drop table if exists `srkt_customers_search_queries`;;
create table `srkt_customers_search_queries` (
  `id` int(8) primary key auto_increment,
  `id_customer_uid` int(8)  NULL ,
  `query` varchar(255)  default '' ,
  `target_url` varchar(255)  default '' ,
  `search_datetime` datetime  default null ,
  index `id` (`id`),
  index `id_customer_uid` (`id_customer_uid`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_customers_search_queries`
              add index `query` (`query`)
;;

              alter table `srkt_customers_search_queries`
              add index `query___search_datetime` (`query`, `search_datetime`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-SearchQuery/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-SearchQuery/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_shopping_carts`;;
drop table if exists `srkt_shopping_carts`;;
create table `srkt_shopping_carts` (
  `id` int(8) primary key auto_increment,
  `id_customer_uid` int(8)  NULL ,
  `id_order` int(8)  NULL ,
  index `id` (`id`),
  index `id_customer_uid` (`id_customer_uid`),
  index `id_order` (`id_order`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-ShoppingCart/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-ShoppingCart/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_shopping_carts_items`;;
drop table if exists `srkt_shopping_carts_items`;;
create table `srkt_shopping_carts_items` (
  `id` int(8) primary key auto_increment,
  `id_shopping_cart` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  `quantity` double(14, 2)  default null ,
  `unit_price` decimal(16, 4)  default null ,
  `added_on` datetime  default null ,
  `updated_on` datetime  default null ,
  index `id` (`id`),
  index `id_shopping_cart` (`id_shopping_cart`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-ShoppingCartItem/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-ShoppingCartItem/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_vouchers`;;
drop table if exists `srkt_vouchers`;;
create table `srkt_vouchers` (
  `id` int(8) primary key auto_increment,
  `voucher` varchar(255)  default '' ,
  `discount_sum` double(14, 2)  default null ,
  `discount_percentage` double(14, 2)  default null ,
  `valid` char(1)  default 'N' ,
  index `id` (`id`),
  index `valid` (`valid`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_vouchers`
              add index `voucher` (`voucher`)
;;

              alter table `srkt_vouchers`
              add index `voucher_valid` (`voucher`, `valid`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Customers-Models-Voucher/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Customers-Models-Voucher/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_contact_form`;;
drop table if exists `srkt_contact_form`;;
create table `srkt_contact_form` (
  `id` int(8) primary key auto_increment,
  `email` varchar(255)  default '' ,
  `name` varchar(255)  default '' ,
  `phone_number` varchar(255)  default '' ,
  `message` text ,
  `received` datetime  default null ,
  `recipient` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-CRM-Models-ContactForm/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-CRM-Models-ContactForm/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_newsletter`;;
drop table if exists `srkt_newsletter`;;
create table `srkt_newsletter` (
  `id` int(8) primary key auto_increment,
  `email` varchar(255)  default '' ,
  `domain` varchar(255)  default '' ,
  `created_at` datetime  default null ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-CRM-Models-Newsletter/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-CRM-Models-Newsletter/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_claims`;;
drop table if exists `srkt_claims`;;
create table `srkt_claims` (
  `id` int(8) primary key auto_increment,
  `id_order` int(8)  NULL ,
  `cas` date  default null ,
  `notes` varchar(255)  default '' ,
  `state` int(8)  default null ,
  index `id` (`id`),
  index `id_order` (`id_order`),
  index `cas` (`cas`),
  index `state` (`state`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Orders-Models-Claim/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Orders-Models-Claim/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_orders`;;
drop table if exists `srkt_orders`;;
create table `srkt_orders` (
  `id` int(8) primary key auto_increment,
  `accounting_year` int(8)  default null ,
  `serial_number` int(8)  default null ,
  `number` varchar(255)  default '' ,
  `id_customer` int(8)  NULL ,
  `id_customer_uid` int(8)  NULL ,
  `del_given_name` varchar(255)  default '' ,
  `del_family_name` varchar(255)  default '' ,
  `del_company_name` varchar(255)  default '' ,
  `del_street_1` varchar(255)  default '' ,
  `del_street_2` varchar(255)  default '' ,
  `del_floor` varchar(255)  default '' ,
  `del_city` varchar(255)  default '' ,
  `del_zip` varchar(255)  default '' ,
  `del_region` varchar(255)  default '' ,
  `del_country` varchar(255)  default '' ,
  `inv_given_name` varchar(255)  default '' ,
  `inv_family_name` varchar(255)  default '' ,
  `inv_company_name` varchar(255)  default '' ,
  `inv_street_1` varchar(255)  default '' ,
  `inv_street_2` varchar(255)  default '' ,
  `inv_city` varchar(255)  default '' ,
  `inv_zip` varchar(255)  default '' ,
  `inv_region` varchar(255)  default '' ,
  `inv_country` varchar(255)  default '' ,
  `confirmation_time` datetime  default null ,
  `id_delivery_service` int(8)  NULL ,
  `id_payment_service` int(8)  NULL ,
  `id_destination_country` int(8)  NULL ,
  `delivery_fee` double(14, 2)  default null ,
  `payment_fee` double(14, 2)  default null ,
  `preferred_delivery_day` date  default null ,
  `number_customer` varchar(255)  default '' ,
  `notes` text ,
  `state` int(8)  default null ,
  `id_invoice` int(8)  NULL ,
  `phone_number` varchar(255)  default '' ,
  `email` varchar(255)  default '' ,
  `company_id` varchar(255)  default '' ,
  `company_tax_id` varchar(255)  default '' ,
  `company_vat_id` varchar(255)  default '' ,
  `domain` varchar(255)  default '' ,
  `discount` double(14, 2)  default null ,
  `price_total_excl_vat` double(14, 2)  default null ,
  `price_total_incl_vat` double(14, 2)  default null ,
  `weight_total` double(14, 2)  default null ,
  `is_paid` boolean  NOT NULL default 0 ,
  index `id` (`id`),
  index `accounting_year` (`accounting_year`),
  index `serial_number` (`serial_number`),
  index `id_customer` (`id_customer`),
  index `id_customer_uid` (`id_customer_uid`),
  index `id_delivery_service` (`id_delivery_service`),
  index `id_payment_service` (`id_payment_service`),
  index `id_destination_country` (`id_destination_country`),
  index `preferred_delivery_day` (`preferred_delivery_day`),
  index `state` (`state`),
  index `id_invoice` (`id_invoice`),
  index `is_paid` (`is_paid`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_orders`
              add constraint `order___accounting_year___serial_number` unique (`accounting_year`, `serial_number`)
;;

              alter table `srkt_orders`
              add constraint `order___number` unique (`number`)
;;

              alter table `srkt_orders`
              add index `b1cae319c7418c141a49d5d7628e2ff0` (`company_id`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Orders-Models-Order/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Orders-Models-Order/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_orders_history`;;
drop table if exists `srkt_orders_history`;;
create table `srkt_orders_history` (
  `id` int(8) primary key auto_increment,
  `id_order` int(8)  NULL ,
  `state` int(8)  default null ,
  `event_time` datetime  default null ,
  `user` int(8)  NULL ,
  index `id` (`id`),
  index `id_order` (`id_order`),
  index `state` (`state`),
  index `user` (`user`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Orders-Models-OrderHistory/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Orders-Models-OrderHistory/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_orders_items`;;
drop table if exists `srkt_orders_items`;;
create table `srkt_orders_items` (
  `id` int(8) primary key auto_increment,
  `id_order` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  `quantity` double(14, 2)  default null ,
  `id_delivery_unit` int(8)  NULL ,
  `unit_price` decimal(16, 4)  default null ,
  `vat_percent` int(8)  default null ,
  index `id` (`id`),
  index `id_order` (`id_order`),
  index `id_product` (`id_product`),
  index `id_delivery_unit` (`id_delivery_unit`),
  index `vat_percent` (`vat_percent`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Orders-Models-OrderItem/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Orders-Models-OrderItem/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_orders_tags`;;
drop table if exists `srkt_orders_tags`;;
create table `srkt_orders_tags` (
  `id` int(8) primary key auto_increment,
  `tag` varchar(255)  default '' ,
  `color` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Orders-Models-OrderTag/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Orders-Models-OrderTag/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_orders_tags_assignment`;;
drop table if exists `srkt_orders_tags_assignment`;;
create table `srkt_orders_tags_assignment` (
  `id` int(8) primary key auto_increment,
  `id_order` int(8)  NULL ,
  `id_tag` int(8)  NULL ,
  index `id` (`id`),
  index `id_order` (`id_order`),
  index `id_tag` (`id_tag`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Orders-Models-OrderTagAssignment/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Orders-Models-OrderTagAssignment/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_invoices`;;
drop table if exists `srkt_invoices`;;
create table `srkt_invoices` (
  `id` int(8) primary key auto_increment,
  `id_numeric_series` int(8)  NULL ,
  `accounting_year` int(8)  default null ,
  `serial_number` int(8)  default null ,
  `number` varchar(255)  default '' ,
  `id_customer` int(8)  NULL ,
  `id_order` int(8)  NULL ,
  `customer_name` varchar(255)  default '' ,
  `customer_street_1` varchar(255)  default '' ,
  `customer_street_2` varchar(255)  default '' ,
  `customer_city` varchar(255)  default '' ,
  `customer_zip` varchar(255)  default '' ,
  `customer_country` varchar(255)  default '' ,
  `customer_company_id` varchar(255)  default '' ,
  `customer_company_tax_id` varchar(255)  default '' ,
  `customer_company_vat_id` varchar(255)  default '' ,
  `customer_email` varchar(255)  default '' ,
  `customer_phone` varchar(255)  default '' ,
  `customer_www` varchar(255)  default '' ,
  `customer_iban` varchar(255)  default '' ,
  `supplier_name` varchar(255)  default '' ,
  `supplier_street_1` varchar(255)  default '' ,
  `supplier_street_2` varchar(255)  default '' ,
  `supplier_city` varchar(255)  default '' ,
  `supplier_zip` varchar(255)  default '' ,
  `supplier_country` varchar(255)  default '' ,
  `supplier_company_id` varchar(255)  default '' ,
  `supplier_company_tax_id` varchar(255)  default '' ,
  `supplier_company_vat_id` varchar(255)  default '' ,
  `supplier_email` varchar(255)  default '' ,
  `supplier_phone` varchar(255)  default '' ,
  `supplier_www` varchar(255)  default '' ,
  `supplier_iban` varchar(255)  default '' ,
  `issue_time` datetime  default null ,
  `delivery_time` datetime  default null ,
  `payment_due_time` datetime  default null ,
  `variable_symbol` varchar(255)  default '' ,
  `specific_symbol` varchar(255)  default '' ,
  `constant_symbol` varchar(255)  default '' ,
  `payment_method` int(8)  default null ,
  `order_number` varchar(255)  default '' ,
  `price_total_excl_vat` double(14, 2)  default null ,
  `price_total_incl_vat` double(14, 2)  default null ,
  `notes` varchar(255)  default '' ,
  `state` int(8)  default null ,
  index `id` (`id`),
  index `id_numeric_series` (`id_numeric_series`),
  index `accounting_year` (`accounting_year`),
  index `serial_number` (`serial_number`),
  index `id_customer` (`id_customer`),
  index `id_order` (`id_order`),
  index `payment_method` (`payment_method`),
  index `state` (`state`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_invoices`
              add constraint `invoice___accounting_year___serial_number` unique (`accounting_year`, `serial_number`)
;;

              alter table `srkt_invoices`
              add constraint `invoice___number` unique (`number`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Finances-Models-Invoice/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Finances-Models-Invoice/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_invoices_items`;;
drop table if exists `srkt_invoices_items`;;
create table `srkt_invoices_items` (
  `id` int(8) primary key auto_increment,
  `id_invoice` int(8)  NULL ,
  `item` varchar(255)  default '' ,
  `quantity` double(14, 2)  default null ,
  `id_delivery_unit` int(8)  NULL ,
  `unit_price` decimal(16, 4)  default null ,
  `vat_percent` int(8)  default null ,
  index `id` (`id`),
  index `id_invoice` (`id_invoice`),
  index `id_delivery_unit` (`id_delivery_unit`),
  index `vat_percent` (`vat_percent`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Finances-Models-InvoiceItem/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Finances-Models-InvoiceItem/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_invoice_numeric_series`;;
drop table if exists `srkt_invoice_numeric_series`;;
create table `srkt_invoice_numeric_series` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  `pattern` varchar(255)  default '' ,
  `id_merchant` int(8)  NULL ,
  index `id` (`id`),
  index `id_merchant` (`id_merchant`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Finances-Models-InvoiceNumericSeries/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Finances-Models-InvoiceNumericSeries/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_merchants`;;
drop table if exists `srkt_merchants`;;
create table `srkt_merchants` (
  `id` int(8) primary key auto_increment,
  `company_name` varchar(255)  default '' ,
  `street_1` varchar(255)  default '' ,
  `street_2` varchar(255)  default '' ,
  `city` varchar(255)  default '' ,
  `zip` varchar(255)  default '' ,
  `country` varchar(255)  default '' ,
  `company_id` varchar(255)  default '' ,
  `company_tax_id` varchar(255)  default '' ,
  `company_vat_id` varchar(255)  default '' ,
  `email` varchar(255)  default '' ,
  `phone` varchar(255)  default '' ,
  `www` varchar(255)  default '' ,
  `iban` varchar(255)  default '' ,
  `description` text ,
  `logo` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Finances-Models-Merchant/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Finances-Models-Merchant/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_brands`;;
drop table if exists `srkt_brands`;;
create table `srkt_brands` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  `description` text ,
  `logo` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-Brand/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-Brand/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products`;;
drop table if exists `srkt_products`;;
create table `srkt_products` (
  `id` int(8) primary key auto_increment,
  `name_lang_1` varchar(255)  default '' ,
  `brief_lang_1` varchar(255)  default '' ,
  `description_lang_1` text ,
  `gift_lang_1` varchar(255)  default '' ,
  `name_lang_2` varchar(255)  default '' ,
  `brief_lang_2` varchar(255)  default '' ,
  `description_lang_2` text ,
  `gift_lang_2` varchar(255)  default '' ,
  `name_lang_3` varchar(255)  default '' ,
  `brief_lang_3` varchar(255)  default '' ,
  `description_lang_3` text ,
  `gift_lang_3` varchar(255)  default '' ,
  `number` varchar(255)  default '' ,
  `ean` varchar(255)  default '' ,
  `weight` double(14, 2)  default null ,
  `price_calculation_method` int(8)  default null ,
  `full_price_excl_vat_custom` decimal(16, 4)  default null ,
  `full_price_incl_vat_custom` decimal(16, 4)  default null ,
  `sale_price_excl_vat_custom` decimal(16, 4)  default null ,
  `sale_price_incl_vat_custom` decimal(16, 4)  default null ,
  `sale_price_excl_vat_cached` decimal(16, 4)  default null ,
  `full_price_excl_vat_cached` decimal(16, 4)  default null ,
  `sale_price_incl_vat_cached` decimal(16, 4)  default null ,
  `full_price_incl_vat_cached` decimal(16, 4)  default null ,
  `id_delivery_unit` int(8)  NULL ,
  `id_stock_state` int(8)  NULL ,
  `stock_quantity` double(14, 2)  default null ,
  `delivery_day` int(8)  default null ,
  `delivery_time` time  default null ,
  `order_deadline` time  default null ,
  `extended_warranty` int(8)  default null ,
  `vat_percent` int(8)  default null ,
  `id_category` int(8)  NULL ,
  `id_brand` int(8)  NULL ,
  `image` varchar(255)  default '' ,
  `product_info` varchar(255)  default '' ,
  `is_on_sale` boolean  NOT NULL default 0 ,
  `is_sale_out` boolean  NOT NULL default 0 ,
  `is_new` boolean  NOT NULL default 0 ,
  `is_recommended` boolean  NOT NULL default 0 ,
  `is_top` boolean  NOT NULL default 0 ,
  `is_used` boolean  NOT NULL default 0 ,
  `is_unpacked` boolean  NOT NULL default 0 ,
  `currently_viewed` int(8)  default null ,
  `count_sold` int(8)  default null ,
  `last_buy` datetime  default null ,
  `end_of_sale` date  default null ,
  `order_index` int(8)  default null ,
  `is_hidden` boolean  NOT NULL default 0 ,
  index `id` (`id`),
  index `price_calculation_method` (`price_calculation_method`),
  index `id_delivery_unit` (`id_delivery_unit`),
  index `id_stock_state` (`id_stock_state`),
  index `delivery_day` (`delivery_day`),
  index `extended_warranty` (`extended_warranty`),
  index `vat_percent` (`vat_percent`),
  index `id_category` (`id_category`),
  index `id_brand` (`id_brand`),
  index `is_on_sale` (`is_on_sale`),
  index `is_sale_out` (`is_sale_out`),
  index `is_new` (`is_new`),
  index `is_recommended` (`is_recommended`),
  index `is_top` (`is_top`),
  index `is_used` (`is_used`),
  index `is_unpacked` (`is_unpacked`),
  index `currently_viewed` (`currently_viewed`),
  index `count_sold` (`count_sold`),
  index `end_of_sale` (`end_of_sale`),
  index `order_index` (`order_index`),
  index `is_hidden` (`is_hidden`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_products`
              add constraint `number` unique (`number`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-Product/installed-version',
              `value` = '2'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-Product/installed-version',
              `value` = '2'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_accessories`;;
drop table if exists `srkt_products_accessories`;;
create table `srkt_products_accessories` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `id_accessory` int(8)  NULL ,
  index `id` (`id`),
  index `id_product` (`id_product`),
  index `id_accessory` (`id_accessory`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductAccessory/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductAccessory/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_categories`;;
drop table if exists `srkt_products_categories`;;
create table `srkt_products_categories` (
  `id` int(8) primary key auto_increment,
  `name_lang_1` varchar(255)  default '' ,
  `description_lang_1` text ,
  `name_lang_2` varchar(255)  default '' ,
  `description_lang_2` text ,
  `name_lang_3` varchar(255)  default '' ,
  `description_lang_3` text ,
  `id_parent` int(8)  NULL ,
  `order_index` int(8)  default null ,
  `tree_left_index` int(8)  default null ,
  `tree_right_index` int(8)  default null ,
  `image` varchar(255)  default '' ,
  `is_highlighted` boolean  NOT NULL default 0 ,
  index `id` (`id`),
  index `id_parent` (`id_parent`),
  index `order_index` (`order_index`),
  index `tree_left_index` (`tree_left_index`),
  index `tree_right_index` (`tree_right_index`),
  index `is_highlighted` (`is_highlighted`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductCategory/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductCategory/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_categories_assignment`;;
drop table if exists `srkt_products_categories_assignment`;;
create table `srkt_products_categories_assignment` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `id_category` int(8)  NULL ,
  index `id` (`id`),
  index `id_product` (`id_product`),
  index `id_category` (`id_category`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_products_categories_assignment`
              add constraint `id_product___id_category` unique (`id_product`, `id_category`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductCategoryAssignment/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductCategoryAssignment/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_product_price_discounts`;;
drop table if exists `srkt_product_price_discounts`;;
create table `srkt_product_price_discounts` (
  `id` int(8) primary key auto_increment,
  `id_customer` int(8)  NULL ,
  `id_customer_category` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  `id_product_category` int(8)  NULL ,
  `id_brand` int(8)  NULL ,
  `id_supplier` int(8)  NULL ,
  `discount_percentage` double(14, 2)  default null ,
  index `id` (`id`),
  index `id_customer` (`id_customer`),
  index `id_customer_category` (`id_customer_category`),
  index `id_product` (`id_product`),
  index `id_product_category` (`id_product_category`),
  index `id_brand` (`id_brand`),
  index `id_supplier` (`id_supplier`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductDiscount/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductDiscount/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_domains_assignment`;;
drop table if exists `srkt_products_domains_assignment`;;
create table `srkt_products_domains_assignment` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `domain` varchar(255)  default '' ,
  index `id` (`id`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_products_domains_assignment`
              add index `domain` (`domain`)
;;

              alter table `srkt_products_domains_assignment`
              add constraint `id_product___domain` unique (`id_product`, `domain`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductDomainAssignment/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductDomainAssignment/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_extensions`;;
drop table if exists `srkt_products_extensions`;;
create table `srkt_products_extensions` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `name_lang_1` varchar(255)  default '' ,
  `description_lang_1` text ,
  `name_lang_2` varchar(255)  default '' ,
  `description_lang_2` text ,
  `name_lang_3` varchar(255)  default '' ,
  `description_lang_3` text ,
  `description` text ,
  `sale_price` double(14, 2)  default null ,
  `image` varchar(255)  default '' ,
  index `id` (`id`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductExtension/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductExtension/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_features`;;
drop table if exists `srkt_products_features`;;
create table `srkt_products_features` (
  `id` int(8) primary key auto_increment,
  `name_lang_1` varchar(255)  default '' ,
  `description_lang_1` text ,
  `name_lang_2` varchar(255)  default '' ,
  `description_lang_2` text ,
  `name_lang_3` varchar(255)  default '' ,
  `description_lang_3` text ,
  `icon` varchar(255)  default '' ,
  `value_type` int(8)  default null ,
  `id_measurement_unit` int(8)  NULL ,
  `entry_method` int(8)  default null ,
  `min` int(8)  default null ,
  `max` int(8)  default null ,
  `order_index` int(8)  default null ,
  index `id` (`id`),
  index `value_type` (`value_type`),
  index `id_measurement_unit` (`id_measurement_unit`),
  index `entry_method` (`entry_method`),
  index `min` (`min`),
  index `max` (`max`),
  index `order_index` (`order_index`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductFeature/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductFeature/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_features_assignment`;;
drop table if exists `srkt_products_features_assignment`;;
create table `srkt_products_features_assignment` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `id_feature` int(8)  NULL ,
  `value_text` text ,
  `value_number` double(14, 2)  default null ,
  `value_boolean` boolean  NOT NULL default 0 ,
  index `id` (`id`),
  index `id_product` (`id_product`),
  index `id_feature` (`id_feature`),
  index `value_boolean` (`value_boolean`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_products_features_assignment`
              add constraint `id_product___id_feature` unique (`id_product`, `id_feature`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductFeatureAssignment/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductFeatureAssignment/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_gallery`;;
drop table if exists `srkt_products_gallery`;;
create table `srkt_products_gallery` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `image` varchar(255)  default '' ,
  index `id` (`id`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductGallery/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductGallery/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_product_price_margins`;;
drop table if exists `srkt_product_price_margins`;;
create table `srkt_product_price_margins` (
  `id` int(8) primary key auto_increment,
  `id_customer` int(8)  NULL ,
  `id_customer_category` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  `id_product_category` int(8)  NULL ,
  `id_brand` int(8)  NULL ,
  `id_supplier` int(8)  NULL ,
  `margin` double(14, 2)  default null ,
  index `id` (`id`),
  index `id_customer` (`id_customer`),
  index `id_customer_category` (`id_customer_category`),
  index `id_product` (`id_product`),
  index `id_product_category` (`id_product_category`),
  index `id_brand` (`id_brand`),
  index `id_supplier` (`id_supplier`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductMargin/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductMargin/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_product_prices`;;
drop table if exists `srkt_product_prices`;;
create table `srkt_product_prices` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `purchase_price` double(14, 2)  default null ,
  `recommended_price` double(14, 2)  default null ,
  index `id` (`id`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductPrice/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductPrice/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_related`;;
drop table if exists `srkt_products_related`;;
create table `srkt_products_related` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `id_related` int(8)  NULL ,
  index `id` (`id`),
  index `id_product` (`id_product`),
  index `id_related` (`id_related`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductRelated/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductRelated/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_services_assignment`;;
drop table if exists `srkt_products_services_assignment`;;
create table `srkt_products_services_assignment` (
  `id` int(8) primary key auto_increment,
  `id_product` int(8)  NULL ,
  `id_service` int(8)  NULL ,
  index `id` (`id`),
  index `id_product` (`id_product`),
  index `id_service` (`id_service`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductServiceAssignment/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductServiceAssignment/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_sets`;;
drop table if exists `srkt_products_sets`;;
create table `srkt_products_sets` (
  `id` int(8) primary key auto_increment,
  `name_lang_1` varchar(255)  default '' ,
  `name_lang_2` varchar(255)  default '' ,
  `name_lang_3` varchar(255)  default '' ,
  `name_lang_4` varchar(255)  default '' ,
  `name_lang_5` varchar(255)  default '' ,
  `name_lang_6` varchar(255)  default '' ,
  `name_lang_7` varchar(255)  default '' ,
  `name_lang_8` varchar(255)  default '' ,
  `name_lang_9` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductSet/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductSet/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_sets_items`;;
drop table if exists `srkt_products_sets_items`;;
create table `srkt_products_sets_items` (
  `id` int(8) primary key auto_increment,
  `id_set` int(8)  NULL ,
  `id_product` int(8)  NULL ,
  index `id` (`id`),
  index `id_set` (`id_set`),
  index `id_product` (`id_product`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductSetItem/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductSetItem/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_products_stock_states`;;
drop table if exists `srkt_products_stock_states`;;
create table `srkt_products_stock_states` (
  `id` int(8) primary key auto_increment,
  `name_lang_1` varchar(255)  default '' ,
  `name_lang_2` varchar(255)  default '' ,
  `name_lang_3` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-ProductStockState/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-ProductStockState/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_services`;;
drop table if exists `srkt_services`;;
create table `srkt_services` (
  `id` int(8) primary key auto_increment,
  `name_lang_1` varchar(255)  default '' ,
  `description_lang_1` text ,
  `name_lang_2` varchar(255)  default '' ,
  `description_lang_2` text ,
  `name_lang_3` varchar(255)  default '' ,
  `description_lang_3` text ,
  `pictogram` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-Service/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-Service/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_suppliers`;;
drop table if exists `srkt_suppliers`;;
create table `srkt_suppliers` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  `description` text ,
  `logo` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Products-Models-Supplier/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Products-Models-Supplier/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_shipping_delivery_services`;;
drop table if exists `srkt_shipping_delivery_services`;;
create table `srkt_shipping_delivery_services` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  `description` varchar(255)  default '' ,
  `logo` varchar(255)  default '' ,
  `is_enabled` boolean  NOT NULL default 0 ,
  `connected_plugin` varchar(255)  default '' ,
  index `id` (`id`),
  index `is_enabled` (`is_enabled`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_shipping_delivery_services`
              add index `connected_plugin` (`connected_plugin`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Shipping-Models-DeliveryService/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Shipping-Models-DeliveryService/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_shipping_destination_countries`;;
drop table if exists `srkt_shipping_destination_countries`;;
create table `srkt_shipping_destination_countries` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  `short` varchar(255)  default '' ,
  `flag` varchar(255)  default '' ,
  `is_enabled` boolean  NOT NULL default 0 ,
  `order_index` int(8)  default null ,
  index `id` (`id`),
  index `is_enabled` (`is_enabled`),
  index `order_index` (`order_index`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_shipping_destination_countries`
              add index `cf1c19dcef72ac60b6fc0a88aeba9bcc` (`short`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Shipping-Models-DestinationCountry/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Shipping-Models-DestinationCountry/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_shipping_payment_services`;;
drop table if exists `srkt_shipping_payment_services`;;
create table `srkt_shipping_payment_services` (
  `id` int(8) primary key auto_increment,
  `name` varchar(255)  default '' ,
  `description` varchar(255)  default '' ,
  `logo` varchar(255)  default '' ,
  `is_enabled` boolean  NOT NULL default 0 ,
  `connected_plugin` varchar(255)  default '' ,
  index `id` (`id`),
  index `is_enabled` (`is_enabled`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_shipping_payment_services`
              add index `connected_plugin` (`connected_plugin`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Shipping-Models-PaymentService/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Shipping-Models-PaymentService/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_shipping_shipments`;;
drop table if exists `srkt_shipping_shipments`;;
create table `srkt_shipping_shipments` (
  `id` int(8) primary key auto_increment,
  `id_delivery_service` int(8)  NULL ,
  `id_payment_service` int(8)  NULL ,
  `id_destination_country` int(8)  NULL ,
  `name` varchar(255)  default '' ,
  `description` text ,
  `logo` varchar(255)  default '' ,
  `is_enabled` boolean  NOT NULL default 0 ,
  `order_index` int(8)  default null ,
  index `id` (`id`),
  index `id_delivery_service` (`id_delivery_service`),
  index `id_payment_service` (`id_payment_service`),
  index `id_destination_country` (`id_destination_country`),
  index `is_enabled` (`is_enabled`),
  index `order_index` (`order_index`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_shipping_shipments`
              add index `7f6ed5e9cfafcbf3129f7e73f6ed62c4` (`id_delivery_service`, `id_payment_service`, `id_destination_country`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Shipping-Models-Shipment/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Shipping-Models-Shipment/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_shipping_prices`;;
drop table if exists `srkt_shipping_prices`;;
create table `srkt_shipping_prices` (
  `id` int(8) primary key auto_increment,
  `id_shipment` int(8)  NULL ,
  `delivery_fee_calculation_method` varchar(255)  default '' ,
  `price_from` double(14, 2)  default null ,
  `price_to` double(14, 2)  default null ,
  `weight_from` double(14, 2)  default null ,
  `weight_to` double(14, 2)  default null ,
  `delivery_fee` double(14, 2)  default null ,
  `payment_fee` double(14, 2)  default null ,
  `name` varchar(255)  default '' ,
  index `id` (`id`),
  index `id_shipment` (`id_shipment`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_shipping_prices`
              add constraint `4e78812002041637b8d49df889f649d3` unique (`name`)
;;

              alter table `srkt_shipping_prices`
              add index `27f994c202599d6860bf03925bba98e5` (`price_from`)
;;

              alter table `srkt_shipping_prices`
              add index `ec0a084f3f9cdc68f74f5dfcea2e802b` (`price_to`)
;;

              alter table `srkt_shipping_prices`
              add index `3d6ed9b9bae3146c734fc3ab8e5004dd` (`weight_from`)
;;

              alter table `srkt_shipping_prices`
              add index `5e25edc419c6581e481a636af9caf5dd` (`weight_to`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Shipping-Models-ShipmentPrice/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Shipping-Models-ShipmentPrice/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_web_menu`;;
drop table if exists `srkt_web_menu`;;
create table `srkt_web_menu` (
  `id` int(8) primary key auto_increment,
  `domain` varchar(255)  default '' ,
  `name` varchar(255)  default '' ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_web_menu`
              add index `domain` (`domain`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Website-Models-WebMenu/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Website-Models-WebMenu/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_web_menu_items`;;
drop table if exists `srkt_web_menu_items`;;
create table `srkt_web_menu_items` (
  `id` int(8) primary key auto_increment,
  `id_menu` int(8)  NULL ,
  `title` varchar(255)  default '' ,
  `url` varchar(255)  default '' ,
  `expand_product_categories` boolean  NOT NULL default 0 ,
  `id_parent` int(8)  NULL ,
  `order_index` int(8)  default null ,
  index `id` (`id`),
  index `id_menu` (`id_menu`),
  index `expand_product_categories` (`expand_product_categories`),
  index `id_parent` (`id_parent`),
  index `order_index` (`order_index`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Website-Models-WebMenuItem/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Website-Models-WebMenuItem/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_web_pages`;;
drop table if exists `srkt_web_pages`;;
create table `srkt_web_pages` (
  `id` int(8) primary key auto_increment,
  `domain` varchar(255)  default '' ,
  `name` varchar(255)  default '' ,
  `url` varchar(255)  default '' ,
  `content_structure` text ,
  `visibility` int(8)  default null ,
  `publish_always` boolean  NOT NULL default 0 ,
  `publish_from` date  default null ,
  `publish_to` date  default null ,
  `seo_title` varchar(255)  default '' ,
  `seo_keywords` varchar(255)  default '' ,
  `seo_description` varchar(255)  default '' ,
  index `id` (`id`),
  index `visibility` (`visibility`),
  index `publish_always` (`publish_always`),
  index `publish_from` (`publish_from`),
  index `publish_to` (`publish_to`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_web_pages`
              add index `domain` (`domain`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Website-Models-WebPage/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Website-Models-WebPage/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_web_redirects`;;
drop table if exists `srkt_web_redirects`;;
create table `srkt_web_redirects` (
  `id` int(8) primary key auto_increment,
  `domain` varchar(255)  default '' ,
  `from_url` varchar(255)  default '' ,
  `to_url` varchar(255)  default '' ,
  `type` int(8)  default null ,
  index `id` (`id`),
  index `type` (`type`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_web_redirects`
              add index `domain` (`domain`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Website-Models-WebRedirect/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Website-Models-WebRedirect/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_web_translations`;;
drop table if exists `srkt_web_translations`;;
create table `srkt_web_translations` (
  `id` int(8) primary key auto_increment,
  `domain` varchar(255)  default '' ,
  `context` varchar(255)  default '' ,
  `original` varchar(255)  default '' ,
  `translated` text ,
  index `id` (`id`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_web_translations`
              add index `754d1c05ea5f287460220a74c2011120` (`domain`)
;;

              alter table `srkt_web_translations`
              add index `52a2520ff7839cc8dcc5c161fb66b8d9` (`domain`, `context`, `original`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Website-Models-WebTranslation/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Website-Models-WebTranslation/installed-version',
              `value` = '0'
;;
SET foreign_key_checks = 0;;
drop table if exists `srkt_units`;;
drop table if exists `srkt_units`;;
create table `srkt_units` (
  `id` int(8) primary key auto_increment,
  `unit` varchar(255)  default '' ,
  `name` varchar(255)  default '' ,
  `is_for_products` boolean  NOT NULL default 0 ,
  `is_for_features` boolean  NOT NULL default 0 ,
  index `id` (`id`),
  index `is_for_products` (`is_for_products`),
  index `is_for_features` (`is_for_features`)) ENGINE = InnoDB;;
SET foreign_key_checks = 1;;

              alter table `srkt_units`
              add index `unit` (`unit`)
;;

            insert into `srkt_adios_config` set
              `path` = 'models/Widgets-Settings-Models-Unit/installed-version',
              `value` = '0'
            on duplicate key update
              `path` = 'models/Widgets-Settings-Models-Unit/installed-version',
              `value` = '0'
;;
ALTER TABLE `srkt_adios_users`
            ADD CONSTRAINT `fk_a3da6da6f23c3b6c7d39166fa6756c80`
            FOREIGN KEY (`id_role`)
            REFERENCES `srkt_adios_roles` (`id`);;
ALTER TABLE `srkt_blogs`
            ADD CONSTRAINT `fk_77eefa7bf9fffc7f022e113cacb46396`
            FOREIGN KEY (`id_user`)
            REFERENCES `srkt_adios_users` (`id`);;
ALTER TABLE `srkt_blogs_tags_assignment`
            ADD CONSTRAINT `fk_7bd4fe00a7a2f1cf7f25cc2a04af2e79`
            FOREIGN KEY (`id_blog`)
            REFERENCES `srkt_blogs` (`id`);;
ALTER TABLE `srkt_blogs_tags_assignment`
            ADD CONSTRAINT `fk_e8da46b50069555db5582aec333c5763`
            FOREIGN KEY (`id_tag`)
            REFERENCES `srkt_blogs_tags` (`id`);;
ALTER TABLE `srkt_products_compare`
            ADD CONSTRAINT `fk_3da3399921de2b9c0848909b395d3f99`
            FOREIGN KEY (`id_customer_uid`)
            REFERENCES `srkt_customers_uid` (`id`);;
ALTER TABLE `srkt_products_compare`
            ADD CONSTRAINT `fk_7490ceb05d029391c748d45cc7374dfa`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_variations`
            ADD CONSTRAINT `fk_c7a3823d35516f659847e423617c4556`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_variations`
            ADD CONSTRAINT `fk_fb8f00c6870c2aaa603f463ecdccefe6`
            FOREIGN KEY (`id_attribute`)
            REFERENCES `srkt_products_variations_attributes` (`id`);;
ALTER TABLE `srkt_products_variations`
            ADD CONSTRAINT `fk_989987211712fc044339114963323baf`
            FOREIGN KEY (`id_value`)
            REFERENCES `srkt_products_variations_values` (`id`);;
ALTER TABLE `srkt_products_variations_groups_attributes`
            ADD CONSTRAINT `fk_fe4a4b8f745e9a0ad264bed6bb67c7ee`
            FOREIGN KEY (`id_attribute`)
            REFERENCES `srkt_products_variations_attributes` (`id`);;
ALTER TABLE `srkt_products_variations_groups_items`
            ADD CONSTRAINT `fk_c644d678d856a228ee1b5778419dba69`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_variations_values`
            ADD CONSTRAINT `fk_df9083e600d396cbd81b458dcfd8ff37`
            FOREIGN KEY (`id_attribute`)
            REFERENCES `srkt_products_variations_attributes` (`id`);;
ALTER TABLE `srkt_customers`
            ADD CONSTRAINT `fk_6cb5b5026fdebd68cdb43f1efbdb2587`
            FOREIGN KEY (`id_category`)
            REFERENCES `srkt_customers_categories` (`id`);;
ALTER TABLE `srkt_customers_addresses`
            ADD CONSTRAINT `fk_d117a55741178e64af73aa2c786ac0eb`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_customers_products_compared`
            ADD CONSTRAINT `fk_7521d6306a2a1276ab6c6709f504ee05`
            FOREIGN KEY (`id_customer_uid`)
            REFERENCES `srkt_customers_uid` (`id`);;
ALTER TABLE `srkt_customers_products_compared`
            ADD CONSTRAINT `fk_418d75f9f4df6ff6b039f5cd6dc861f6`
            FOREIGN KEY (`id_product_1`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_customers_products_compared`
            ADD CONSTRAINT `fk_5eab1cff0dec2f75befc975256667cb6`
            FOREIGN KEY (`id_product_2`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_customers_products_displayed`
            ADD CONSTRAINT `fk_f4b5aee360a01c7e92399deb07110378`
            FOREIGN KEY (`id_customer_uid`)
            REFERENCES `srkt_customers_uid` (`id`);;
ALTER TABLE `srkt_customers_products_displayed`
            ADD CONSTRAINT `fk_d127e59001de40fcbf2b70d9cba5713a`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_customers_tokens`
            ADD CONSTRAINT `fk_c3299036049a0fb2499171c737aed288`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_customers_tokens`
            ADD CONSTRAINT `fk_b9127a3af3559049278bd3154227cd33`
            FOREIGN KEY (`id_token`)
            REFERENCES `srkt_adios_tokens` (`id`);;
ALTER TABLE `srkt_customers_uid`
            ADD CONSTRAINT `fk_7393fccc71a3aca060cc67f37bbbe5ca`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_customers_watchdog`
            ADD CONSTRAINT `fk_5a004a5e142b9683f2fe6b58553f8553`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_customers_watchdog`
            ADD CONSTRAINT `fk_dba6ed9dcabf7b8ed49fc6240c80765e`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_customers_wishlist`
            ADD CONSTRAINT `fk_0a649e21b477f2678e4b42c5daa75c91`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_customers_wishlist`
            ADD CONSTRAINT `fk_e2798678391e5f046edd7de3a7accf51`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_customers_search_queries`
            ADD CONSTRAINT `fk_c9a08f4f3cec8ef0b27a123c5339a79e`
            FOREIGN KEY (`id_customer_uid`)
            REFERENCES `srkt_customers_uid` (`id`);;
ALTER TABLE `srkt_shopping_carts`
            ADD CONSTRAINT `fk_cc8b3e59a47c565ec9dd7d8fa5155d5e`
            FOREIGN KEY (`id_customer_uid`)
            REFERENCES `srkt_customers_uid` (`id`);;
ALTER TABLE `srkt_shopping_carts`
            ADD CONSTRAINT `fk_6ddbea7e78af51925f4bd39a8a95fa0a`
            FOREIGN KEY (`id_order`)
            REFERENCES `srkt_orders` (`id`);;
ALTER TABLE `srkt_shopping_carts_items`
            ADD CONSTRAINT `fk_c313d3b62c22045593ae6984cc44ee50`
            FOREIGN KEY (`id_shopping_cart`)
            REFERENCES `srkt_shopping_carts` (`id`);;
ALTER TABLE `srkt_shopping_carts_items`
            ADD CONSTRAINT `fk_e04943bf17e2bd5205a7352816d8dc20`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_claims`
            ADD CONSTRAINT `fk_6f5137bc1cec585d067014d83b19d66d`
            FOREIGN KEY (`id_order`)
            REFERENCES `srkt_orders` (`id`);;
ALTER TABLE `srkt_orders`
            ADD CONSTRAINT `fk_8373f94d08da180521e286a5554beb4b`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_orders`
            ADD CONSTRAINT `fk_7f90a775d6e3b9c224ba111d3c842225`
            FOREIGN KEY (`id_customer_uid`)
            REFERENCES `srkt_customers_uid` (`id`);;
ALTER TABLE `srkt_orders`
            ADD CONSTRAINT `fk_bc2305ccf1e4ffaf335a59c7a27bebd2`
            FOREIGN KEY (`id_delivery_service`)
            REFERENCES `srkt_shipping_delivery_services` (`id`);;
ALTER TABLE `srkt_orders`
            ADD CONSTRAINT `fk_951898869134f0f10ef278e204030a26`
            FOREIGN KEY (`id_payment_service`)
            REFERENCES `srkt_shipping_payment_services` (`id`);;
ALTER TABLE `srkt_orders`
            ADD CONSTRAINT `fk_a9ecdd71df240f464b4d9afe1d380bad`
            FOREIGN KEY (`id_destination_country`)
            REFERENCES `srkt_shipping_destination_countries` (`id`);;
ALTER TABLE `srkt_orders`
            ADD CONSTRAINT `fk_61a4559a734d0ccc01918a13205d22c2`
            FOREIGN KEY (`id_invoice`)
            REFERENCES `srkt_invoices` (`id`);;
ALTER TABLE `srkt_orders_history`
            ADD CONSTRAINT `fk_bef39ca7ca5b14b58567617d56f7fe02`
            FOREIGN KEY (`id_order`)
            REFERENCES `srkt_orders` (`id`);;
ALTER TABLE `srkt_orders_history`
            ADD CONSTRAINT `fk_ce3223eab1f8988d98426a45a29d26be`
            FOREIGN KEY (`user`)
            REFERENCES `srkt_adios_users` (`id`);;
ALTER TABLE `srkt_orders_items`
            ADD CONSTRAINT `fk_99feb7a7dd30bf58fbaf705d7e5cc804`
            FOREIGN KEY (`id_order`)
            REFERENCES `srkt_orders` (`id`);;
ALTER TABLE `srkt_orders_items`
            ADD CONSTRAINT `fk_62de51c087f930e49dd1d8283a589163`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_orders_items`
            ADD CONSTRAINT `fk_dbd95f4c727e71ec3893ef30e4358aa1`
            FOREIGN KEY (`id_delivery_unit`)
            REFERENCES `srkt_units` (`id`);;
ALTER TABLE `srkt_orders_tags_assignment`
            ADD CONSTRAINT `fk_b13c901ec2504a3fe0786dc8240fe735`
            FOREIGN KEY (`id_order`)
            REFERENCES `srkt_orders` (`id`);;
ALTER TABLE `srkt_orders_tags_assignment`
            ADD CONSTRAINT `fk_1f75a76c9bc0104b2cfb9bc917127833`
            FOREIGN KEY (`id_tag`)
            REFERENCES `srkt_orders_tags` (`id`);;
ALTER TABLE `srkt_invoices`
            ADD CONSTRAINT `fk_2824be743dd8e07f1132c2faac3c4c1d`
            FOREIGN KEY (`id_numeric_series`)
            REFERENCES `srkt_invoice_numeric_series` (`id`);;
ALTER TABLE `srkt_invoices`
            ADD CONSTRAINT `fk_45c463e9f5ee7073ba520796dc75a778`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_invoices`
            ADD CONSTRAINT `fk_3e23c0421159f0d464dd63e65c9dafa6`
            FOREIGN KEY (`id_order`)
            REFERENCES `srkt_orders` (`id`);;
ALTER TABLE `srkt_invoices_items`
            ADD CONSTRAINT `fk_fd7eb5de9f18edaaacb02c3527fe4cfa`
            FOREIGN KEY (`id_invoice`)
            REFERENCES `srkt_invoices` (`id`);;
ALTER TABLE `srkt_invoices_items`
            ADD CONSTRAINT `fk_c0c8d5f7c785cb0bc4bd95af762e61f0`
            FOREIGN KEY (`id_delivery_unit`)
            REFERENCES `srkt_units` (`id`);;
ALTER TABLE `srkt_invoice_numeric_series`
            ADD CONSTRAINT `fk_242ef942e5e934b911a10e5e35db777c`
            FOREIGN KEY (`id_merchant`)
            REFERENCES `srkt_merchants` (`id`);;
ALTER TABLE `srkt_products`
            ADD CONSTRAINT `fk_083cc42687b98dfbc429e2d11400d522`
            FOREIGN KEY (`id_delivery_unit`)
            REFERENCES `srkt_units` (`id`);;
ALTER TABLE `srkt_products`
            ADD CONSTRAINT `fk_f93138443f9170d225e263351633be65`
            FOREIGN KEY (`id_stock_state`)
            REFERENCES `srkt_products_stock_states` (`id`);;
ALTER TABLE `srkt_products`
            ADD CONSTRAINT `fk_0e0517a7300bcfa4c8618d646816f4b2`
            FOREIGN KEY (`id_category`)
            REFERENCES `srkt_products_categories` (`id`);;
ALTER TABLE `srkt_products`
            ADD CONSTRAINT `fk_3a5bdb477ccf78e303c64f4553d7dead`
            FOREIGN KEY (`id_brand`)
            REFERENCES `srkt_brands` (`id`);;
ALTER TABLE `srkt_products_accessories`
            ADD CONSTRAINT `fk_078957fdbf6c4fb43cda2f56e86e59d2`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_accessories`
            ADD CONSTRAINT `fk_10fbe7bdf35b627a430146b63f3b5cb0`
            FOREIGN KEY (`id_accessory`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_categories`
            ADD CONSTRAINT `fk_5c4fc8ae231a9ab9088e0657e42f2da8`
            FOREIGN KEY (`id_parent`)
            REFERENCES `srkt_products_categories` (`id`);;
ALTER TABLE `srkt_products_categories_assignment`
            ADD CONSTRAINT `fk_643726eb58611dd48e6ce9da3e911296`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_categories_assignment`
            ADD CONSTRAINT `fk_c84d2e37da1f88ad26503eadfeaf71b1`
            FOREIGN KEY (`id_category`)
            REFERENCES `srkt_products_categories` (`id`);;
ALTER TABLE `srkt_product_price_discounts`
            ADD CONSTRAINT `fk_76e5a94eea68aab03c1c2695ea21ff3a`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_product_price_discounts`
            ADD CONSTRAINT `fk_1f98be37530835ec6561270408dcef3c`
            FOREIGN KEY (`id_customer_category`)
            REFERENCES `srkt_customers_categories` (`id`);;
ALTER TABLE `srkt_product_price_discounts`
            ADD CONSTRAINT `fk_58913a09e5961d0abaeba3a80e1c4753`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_product_price_discounts`
            ADD CONSTRAINT `fk_70d14dd22e6221e4c37c723a62133fd2`
            FOREIGN KEY (`id_product_category`)
            REFERENCES `srkt_products_categories` (`id`);;
ALTER TABLE `srkt_product_price_discounts`
            ADD CONSTRAINT `fk_1fcb8d9c2d9f47093bc999b2d8c84f6d`
            FOREIGN KEY (`id_brand`)
            REFERENCES `srkt_brands` (`id`);;
ALTER TABLE `srkt_product_price_discounts`
            ADD CONSTRAINT `fk_bc80f35e7dfb166084acc99a4d3a3e23`
            FOREIGN KEY (`id_supplier`)
            REFERENCES `srkt_suppliers` (`id`);;
ALTER TABLE `srkt_products_domains_assignment`
            ADD CONSTRAINT `fk_82784afb7cb8daf849af3542c0366d25`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_extensions`
            ADD CONSTRAINT `fk_df542bc0a21082186c7aedb0ea66583e`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_features`
            ADD CONSTRAINT `fk_7967f23c88877efba74060b5d148e818`
            FOREIGN KEY (`id_measurement_unit`)
            REFERENCES `srkt_units` (`id`);;
ALTER TABLE `srkt_products_features_assignment`
            ADD CONSTRAINT `fk_85fce10cf5116f606578b3d00a30455e`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_features_assignment`
            ADD CONSTRAINT `fk_725291f3c1e8cfe7ca40037ba440bd76`
            FOREIGN KEY (`id_feature`)
            REFERENCES `srkt_products_features` (`id`);;
ALTER TABLE `srkt_products_gallery`
            ADD CONSTRAINT `fk_a38619d643739e058ea689b711df0f1a`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_product_price_margins`
            ADD CONSTRAINT `fk_fb1784307e100d6b9e9a21561906f77d`
            FOREIGN KEY (`id_customer`)
            REFERENCES `srkt_customers` (`id`);;
ALTER TABLE `srkt_product_price_margins`
            ADD CONSTRAINT `fk_5d05c297220b6735c1b10f93fe6fe15a`
            FOREIGN KEY (`id_customer_category`)
            REFERENCES `srkt_customers_categories` (`id`);;
ALTER TABLE `srkt_product_price_margins`
            ADD CONSTRAINT `fk_062d2255f0929481f79d823a9571c7f6`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_product_price_margins`
            ADD CONSTRAINT `fk_6e0e03edeb75d2b3f942bdec537f7666`
            FOREIGN KEY (`id_product_category`)
            REFERENCES `srkt_products_categories` (`id`);;
ALTER TABLE `srkt_product_price_margins`
            ADD CONSTRAINT `fk_5f09fea14e9506803e7e5f9f43c2f47d`
            FOREIGN KEY (`id_brand`)
            REFERENCES `srkt_brands` (`id`);;
ALTER TABLE `srkt_product_price_margins`
            ADD CONSTRAINT `fk_4ef5f7d1f512932262c73a64d241b653`
            FOREIGN KEY (`id_supplier`)
            REFERENCES `srkt_suppliers` (`id`);;
ALTER TABLE `srkt_product_prices`
            ADD CONSTRAINT `fk_fe3e3ebcb0b52f5a64c6883dac0fd9bb`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_related`
            ADD CONSTRAINT `fk_39251711eb9903c13765054fb111ac9a`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_related`
            ADD CONSTRAINT `fk_305ce0b82432d140836730e9c469670d`
            FOREIGN KEY (`id_related`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_services_assignment`
            ADD CONSTRAINT `fk_61158be85259a90190de0541620fad5d`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_products_services_assignment`
            ADD CONSTRAINT `fk_83077010e4eeed8edbd71a1c0293d5b7`
            FOREIGN KEY (`id_service`)
            REFERENCES `srkt_services` (`id`);;
ALTER TABLE `srkt_products_sets_items`
            ADD CONSTRAINT `fk_91595ab9a5ff98f3204816408a3951b5`
            FOREIGN KEY (`id_set`)
            REFERENCES `srkt_products_sets` (`id`);;
ALTER TABLE `srkt_products_sets_items`
            ADD CONSTRAINT `fk_eedf6420d7c2cd669b3053bbadbbbf67`
            FOREIGN KEY (`id_product`)
            REFERENCES `srkt_products` (`id`);;
ALTER TABLE `srkt_shipping_shipments`
            ADD CONSTRAINT `fk_b31add6b5cdff2a4cbcc5a6fa845a71c`
            FOREIGN KEY (`id_delivery_service`)
            REFERENCES `srkt_shipping_delivery_services` (`id`);;
ALTER TABLE `srkt_shipping_shipments`
            ADD CONSTRAINT `fk_6a29bac1aae04373ce5b30588e13e9d9`
            FOREIGN KEY (`id_payment_service`)
            REFERENCES `srkt_shipping_payment_services` (`id`);;
ALTER TABLE `srkt_shipping_shipments`
            ADD CONSTRAINT `fk_cea041f7d0417677d0fb226537f19c57`
            FOREIGN KEY (`id_destination_country`)
            REFERENCES `srkt_shipping_destination_countries` (`id`);;
ALTER TABLE `srkt_shipping_prices`
            ADD CONSTRAINT `fk_3fabc80cee640260361c99bf622ee4d2`
            FOREIGN KEY (`id_shipment`)
            REFERENCES `srkt_shipping_shipments` (`id`);;
ALTER TABLE `srkt_web_menu_items`
            ADD CONSTRAINT `fk_066f1737b6e7d6bcfd455db92d581109`
            FOREIGN KEY (`id_menu`)
            REFERENCES `srkt_web_menu` (`id`);;
ALTER TABLE `srkt_web_menu_items`
            ADD CONSTRAINT `fk_d9d74c412a9368d3adc950b54cb110c6`
            FOREIGN KEY (`id_parent`)
            REFERENCES `srkt_web_menu_items` (`id`);;
commit;;
insert into `srkt_adios_roles` set `id`=null, name='Administrator';;
insert into `srkt_adios_roles` set `id`=null, name='Product manager';;
insert into `srkt_adios_roles` set `id`=null, name='Sales';;
insert into `srkt_adios_roles` set `id`=null, name='Online marketing';;
insert into `srkt_adios_roles` set `id`=null, name='Product manager + Sales';;
insert into `srkt_adios_roles` set `id`=null, name='Product manager + Online marketing';;
insert into `srkt_adios_roles` set `id`=null, name='Sales + Online marketing';;
insert into `srkt_adios_roles` set `id`=null, name='Product manager + Sales + Online marketing';;
insert into `srkt_adios_users` set `id`=null, name='Administrator', surname='Default', login='administrator', `password` = '$2y$10$IwfxCxzbP8OUricv/UMagOuoV/OdtwFpV2IU9wesJjMBIShm8tARS', id_role='1', active = 1;;
insert into `srkt_adios_users` set `id`=null, name='Product Manager', surname='Default', login='product.manager', `password` = '$2y$10$OxRBufxYqRSRfY39YQVJV.HvTYSXkW3ClhNTTcU5Mi2knXeXi7lrS', id_role='2', active = 1;;
insert into `srkt_adios_users` set `id`=null, name='Sales', surname='Default', login='sales', `password` = '$2y$10$Ubf0.uPM78v05dnRVYw0Q.KWg4maZCUd9K1KbhskkVjj9ifXe..iK', id_role='3', active = 1;;
insert into `srkt_adios_users` set `id`=null, name='Online marketing', surname='Default', login='online.marketing', `password` = '$2y$10$REu9elH.eDWCiC5QN2rpo.tMpH4eJUI7zPr1s/WYM4aE6pYy20x8i', id_role='4', active = 1;;
SET foreign_key_checks = 0;;
insert into `srkt_shipping_destination_countries` set `id`='1', name='Slovakia', is_enabled = 1;;
insert into `srkt_shipping_destination_countries` set `id`='2', name='France', is_enabled = 1;;
insert into `srkt_shipping_destination_countries` set `id`='3', name='United Kingdom', is_enabled = 1;;
insert into `srkt_shipping_destination_countries` set `id`='4', name='U.S.', is_enabled = 1;;
insert into `srkt_shipping_delivery_services` set `id`='1', name='UPS', description='Fast & Reliable Shipping', logo='ups.svg', is_enabled = 1, connected_plugin='WAI/Delivery/UPS';;
insert into `srkt_shipping_delivery_services` set `id`='2', name='DPD', description='', logo='', is_enabled = 1, connected_plugin='WAI/Delivery/DPD';;
insert into `srkt_shipping_delivery_services` set `id`='3', name='Slovenská pošta', description='', logo='posta.svg', is_enabled = 1, connected_plugin='';;
insert into `srkt_shipping_delivery_services` set `id`='4', name='Packeta', description='', logo='', is_enabled = 1, connected_plugin='';;
insert into `srkt_shipping_payment_services` set `id`='1', name='Tatra banka', description='', logo='tatrabanka.jpg', is_enabled = 1, connected_plugin='WAI/Proprietary/Payment/InternetBanking/Tatrabanka';;
insert into `srkt_shipping_payment_services` set `id`='2', name='CardPay', description='', logo='cardpay.jpg', is_enabled = 1, connected_plugin='WAI/Proprietary/Payment/Card';;
insert into `srkt_shipping_payment_services` set `id`='3', name='Payment on delivery', description='', logo='', is_enabled = 1, connected_plugin='';;
insert into `srkt_shipping_shipments` set `id`='1', id_delivery_service='1', id_payment_service='1', id_destination_country='1', name='UPS Tatra banka', `description` = '', is_enabled = 1, order_index=null;;
insert into `srkt_shipping_shipments` set `id`='2', id_delivery_service='1', id_payment_service='2', id_destination_country='1', name='UPS CardPay', `description` = '', is_enabled = 1, order_index=null;;
insert into `srkt_shipping_shipments` set `id`='3', id_delivery_service='1', id_payment_service='3', id_destination_country='1', name='UPS Cash on delivery', `description` = '', is_enabled = 1, order_index=null;;
insert into `srkt_shipping_prices` set `id`='1', id_shipment='1', delivery_fee_calculation_method='1', price_from='0', price_to='50', weight_from='0', weight_to='0', delivery_fee='3.25', payment_fee='1.15', name='11';;
insert into `srkt_shipping_prices` set `id`='2', id_shipment='2', delivery_fee_calculation_method='1', price_from='0', price_to='50', weight_from='0', weight_to='0', delivery_fee='3.25', payment_fee='2.1', name='12';;
insert into `srkt_shipping_prices` set `id`='3', id_shipment='3', delivery_fee_calculation_method='1', price_from='0', price_to='50', weight_from='0', weight_to='0', delivery_fee='3.25', payment_fee='3.11', name='13';;
insert into `srkt_shipping_prices` set `id`='9', id_shipment='1', delivery_fee_calculation_method='1', price_from='50', price_to='100000', weight_from='0', weight_to='0', delivery_fee='0', payment_fee='4.44', name='14';;
insert into `srkt_shipping_prices` set `id`='10', id_shipment='2', delivery_fee_calculation_method='1', price_from='50', price_to='100000', weight_from='0', weight_to='0', delivery_fee='0', payment_fee='0', name='15';;
insert into `srkt_shipping_prices` set `id`='11', id_shipment='3', delivery_fee_calculation_method='1', price_from='50', price_to='100000', weight_from='0', weight_to='0', delivery_fee='0', payment_fee='0.9', name='16';;
insert into `srkt_shipping_shipments` set `id`='4', id_delivery_service='3', id_payment_service='1', id_destination_country='1', name='Slovenská pošta Tatra banka', `description` = '', is_enabled = 1, order_index=null;;
insert into `srkt_shipping_shipments` set `id`='5', id_delivery_service='3', id_payment_service='3', id_destination_country='1', name='Slovenská pošta Cash on delivery', `description` = '', is_enabled = 1, order_index=null;;
insert into `srkt_shipping_prices` set `id`='4', id_shipment='4', delivery_fee_calculation_method='1', price_from='0', price_to='1000', weight_from='0', weight_to='0', delivery_fee='4.25', name='21';;
insert into `srkt_shipping_prices` set `id`='5', id_shipment='5', delivery_fee_calculation_method='1', price_from='0', price_to='1000', weight_from='0', weight_to='0', name='22';;
insert into `srkt_shipping_shipments` set `id`='6', id_delivery_service='4', id_payment_service='3', id_destination_country='1', name='Packeta Cash on delivery', `description` = '', is_enabled = 1, order_index=null;;
insert into `srkt_shipping_prices` set `id`='6', id_shipment='6', delivery_fee_calculation_method='1', price_from='0', price_to='1000', weight_from='0', weight_to='0', delivery_fee='2', name='31';;
insert into `srkt_shipping_shipments` set `id`='7', id_delivery_service='2', id_payment_service='1', id_destination_country='1', name='DPD Tatra banka', `description` = '', is_enabled = 1, order_index=null;;
insert into `srkt_shipping_shipments` set `id`='8', id_delivery_service='2', id_payment_service='2', id_destination_country='1', name='DPD CardPay', `description` = '', is_enabled = 1, order_index=null;;
insert into `srkt_shipping_prices` set `id`='7', id_shipment='7', delivery_fee_calculation_method='1', price_from='0', price_to='1000', weight_from='0', weight_to='0', delivery_fee='3.35', name='41';;
insert into `srkt_shipping_prices` set `id`='8', id_shipment='8', delivery_fee_calculation_method='1', price_from='0', price_to='1000', weight_from='0', weight_to='0', delivery_fee='3.99', name='42';;
insert into `srkt_units` set `id`='1', unit='N/A', name='no unit', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='2', unit='mm', name='milimeters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='3', unit='cm', name='centimeters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='4', unit='m', name='meters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='22', unit='km', name='kilometers', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='5', unit='ml', name='mililitres', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='6', unit='dl', name='decilitres', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='7', unit='l', name='litres', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='8', unit='mg', name='miligramms', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='9', unit='g', name='gramms', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='10', unit='kg', name='kilogramms', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='11', unit='t', name='tonnes', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='12', unit='mm2', name='square milimeters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='13', unit='cm2', name='square centimeters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='14', unit='m2', name='square meters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='15', unit='mm3', name='cubic milimeters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='16', unit='cm3', name='cubic centimeters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='17', unit='m3', name='cubic meters', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='18', unit='btl', name='bottles', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='19', unit='pcs', name='pieces', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='20', unit='pkg', name='packages', is_for_products = 1, is_for_features = 1;;
insert into `srkt_units` set `id`='21', unit='cnt', name='containers', is_for_products = 1, is_for_features = 1;;
insert into `srkt_suppliers` set `id`=null, name='Baumax';;
insert into `srkt_suppliers` set `id`=null, name='Amazon';;
insert into `srkt_suppliers` set `id`=null, name='Adidas';;
insert into `srkt_suppliers` set `id`=null, name='Bosch';;
insert into `srkt_suppliers` set `id`=null, name='SpaceX';;
insert into `srkt_brands` set `id`=null, name='Mercedes';;
insert into `srkt_brands` set `id`=null, name='Hyundai';;
insert into `srkt_brands` set `id`=null, name='Lenovo';;
insert into `srkt_brands` set `id`=null, name='Yves Rocher';;
insert into `srkt_brands` set `id`=null, name='Milsy';;
insert into `srkt_brands` set `id`=null, name='Tommy Hilgifer';;
insert into `srkt_brands` set `id`=null, name='Kia';;
insert into `srkt_brands` set `id`=null, name='ConnectIT';;
insert into `srkt_brands` set `id`=null, name='Samsung';;
insert into `srkt_brands` set `id`=null, name='IKAR';;
insert into `srkt_brands` set `id`=null, name='IKEA';;
insert into `srkt_services` set `id`=null, name_lang_1='Return within 30 days', name_lang_2='Vrátenie do 30 dní';;
insert into `srkt_services` set `id`=null, name_lang_1='Satisfaction guaranteed', name_lang_2='Garancia spokojnosti';;
insert into `srkt_services` set `id`=null, name_lang_1='Free shipping', name_lang_2='Doprava zdarma';;
insert into `srkt_services` set `id`=null, name_lang_1='Possible exchange', name_lang_2='Možná výmena';;
insert into `srkt_products_categories` set `id`='1', name_lang_1='Category_A (lng-1)', name_lang_2='Category_A (lng-2)', name_lang_3='Category_A (lng-3)', id_parent=null;;
insert into `srkt_products_categories` set `id`='2', name_lang_1='Category_B (lng-1)', name_lang_2='Category_B (lng-2)', name_lang_3='Category_B (lng-3)', id_parent=null;;
insert into `srkt_products_categories` set `id`='3', name_lang_1='Category_C (lng-1)', name_lang_2='Category_C (lng-2)', name_lang_3='Category_C (lng-3)', id_parent=null;;
insert into `srkt_products_categories` set `id`='4', name_lang_1='Category_A_A (lng-1)', name_lang_2='Category_A_A (lng-2)', name_lang_3='Category_A_A (lng-3)', id_parent='1';;
insert into `srkt_products_categories` set `id`='5', name_lang_1='Category_A_B (lng-1)', name_lang_2='Category_A_B (lng-2)', name_lang_3='Category_A_B (lng-3)', id_parent='1';;
insert into `srkt_products_categories` set `id`='6', name_lang_1='Category_A_C (lng-1)', name_lang_2='Category_A_C (lng-2)', name_lang_3='Category_A_C (lng-3)', id_parent='1';;
insert into `srkt_products_categories` set `id`='7', name_lang_1='Category_B_A (lng-1)', name_lang_2='Category_B_A (lng-2)', name_lang_3='Category_B_A (lng-3)', id_parent='2';;
insert into `srkt_products_features` set `id`='1', name_lang_1='Length', name_lang_2='Dĺžka', value_type='1', id_measurement_unit='1', entry_method='5', min='10000', order_index='1';;
insert into `srkt_products_features` set `id`='2', name_lang_1='Width', name_lang_2='Šírka', value_type='1', id_measurement_unit='1', entry_method='5', min='10000', order_index='2';;
insert into `srkt_products_features` set `id`='3', name_lang_1='Height', name_lang_2='Výška', value_type='1', id_measurement_unit='1', entry_method='5', min='10000', order_index='3';;
insert into `srkt_products_features` set `id`='4', name_lang_1='Achsen', name_lang_2='Nápravy', value_type='1', id_measurement_unit='1', entry_method='5', min='5', order_index='4';;
insert into `srkt_products_features` set `id`='5', name_lang_1='Gesamtgewicht', name_lang_2='Celková hmotnosť', value_type='1', id_measurement_unit='9', entry_method='5', min='10000', order_index='5';;
insert into `srkt_products_features` set `id`='6', name_lang_1='Nutzlast ca.', name_lang_2='Užitočné zaťaženie', value_type='1', id_measurement_unit='9', entry_method='5', min='10000', order_index='6';;
insert into `srkt_products_features` set `id`='7', name_lang_1='Rader', name_lang_2='Kolesá', value_type='2', id_measurement_unit='1', entry_method='5', min='10000', order_index='7';;
insert into `srkt_products_stock_states` set `id`='1', name_lang_1='Available in stock';;
insert into `srkt_products_stock_states` set `id`='2', name_lang_1='Currently unavailable';;
insert into `srkt_products_stock_states` set `id`='3', name_lang_1='Available upon request';;
start transaction;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 0 (lng-1)', brief_lang_1='Brief for RND Product 0 (lng-1)', `description_lang_1` = 'Description for RND Product 0 (lng-1)', name_lang_2='RND Product 0 (lng-2)', brief_lang_2='Brief for RND Product 0 (lng-2)', `description_lang_2` = 'Description for RND Product 0 (lng-2)', name_lang_3='RND Product 0 (lng-3)', brief_lang_3='Brief for RND Product 0 (lng-3)', `description_lang_3` = 'Description for RND Product 0 (lng-3)', number='RND.12.8277.0', ean='200RND.12.8277.01', weight='1927', price_calculation_method='1', full_price_excl_vat_custom='8.53', full_price_incl_vat_custom='10.236', sale_price_excl_vat_custom='8.53', sale_price_incl_vat_custom='10.236', sale_price_excl_vat_cached='8.53', full_price_excl_vat_cached='8.53', sale_price_incl_vat_cached='10.236', full_price_incl_vat_cached='10.236', id_delivery_unit='12', stock_quantity='9.7', extended_warranty='7', vat_percent='20', id_category='4', id_brand='7', image='products/2.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='1', id_feature='1', `value_text` = '1084', value_number='1084';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='1', id_feature='2', `value_text` = '1228', value_number='1228';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='1', id_feature='3', `value_text` = '261', value_number='261';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='1', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='1', id_feature='5', `value_text` = '860', value_number='860';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='1', id_feature='6', `value_text` = '520', value_number='520';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='1', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 1 (lng-1)', brief_lang_1='Brief for RND Product 1 (lng-1)', `description_lang_1` = 'Description for RND Product 1 (lng-1)', name_lang_2='RND Product 1 (lng-2)', brief_lang_2='Brief for RND Product 1 (lng-2)', `description_lang_2` = 'Description for RND Product 1 (lng-2)', name_lang_3='RND Product 1 (lng-3)', brief_lang_3='Brief for RND Product 1 (lng-3)', `description_lang_3` = 'Description for RND Product 1 (lng-3)', number='RND.16.3962.1', ean='200RND.16.3962.14', weight='1921', price_calculation_method='1', full_price_excl_vat_custom='8.43', full_price_incl_vat_custom='10.116', sale_price_excl_vat_custom='8.43', sale_price_incl_vat_custom='10.116', sale_price_excl_vat_cached='8.43', full_price_excl_vat_cached='8.43', sale_price_incl_vat_cached='10.116', full_price_incl_vat_cached='10.116', id_delivery_unit='19', stock_quantity='6.4', extended_warranty=null, vat_percent='20', id_category='5', id_brand='2', image='products/5.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='2', id_feature='1', `value_text` = '1074', value_number='1074';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='2', id_feature='2', `value_text` = '1242', value_number='1242';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='2', id_feature='3', `value_text` = '277', value_number='277';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='2', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='2', id_feature='5', `value_text` = '980', value_number='980';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='2', id_feature='6', `value_text` = '880', value_number='880';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='2', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 2 (lng-1)', brief_lang_1='Brief for RND Product 2 (lng-1)', `description_lang_1` = 'Description for RND Product 2 (lng-1)', name_lang_2='RND Product 2 (lng-2)', brief_lang_2='Brief for RND Product 2 (lng-2)', `description_lang_2` = 'Description for RND Product 2 (lng-2)', name_lang_3='RND Product 2 (lng-3)', brief_lang_3='Brief for RND Product 2 (lng-3)', `description_lang_3` = 'Description for RND Product 2 (lng-3)', number='RND.50.4712.2', ean='200RND.50.4712.25', weight='1334', price_calculation_method='1', full_price_excl_vat_custom='28.82', full_price_incl_vat_custom='34.584', sale_price_excl_vat_custom='28.82', sale_price_incl_vat_custom='34.584', sale_price_excl_vat_cached='28.82', full_price_excl_vat_cached='28.82', sale_price_incl_vat_cached='34.584', full_price_incl_vat_cached='34.584', id_delivery_unit='2', stock_quantity='6.5', extended_warranty='34', vat_percent='20', id_category='5', id_brand='4', image='products/3.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='3', id_feature='1', `value_text` = '1142', value_number='1142';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='3', id_feature='2', `value_text` = '1233', value_number='1233';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='3', id_feature='3', `value_text` = '297', value_number='297';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='3', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='3', id_feature='5', `value_text` = '920', value_number='920';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='3', id_feature='6', `value_text` = '940', value_number='940';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='3', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 3 (lng-1)', brief_lang_1='Brief for RND Product 3 (lng-1)', `description_lang_1` = 'Description for RND Product 3 (lng-1)', name_lang_2='RND Product 3 (lng-2)', brief_lang_2='Brief for RND Product 3 (lng-2)', `description_lang_2` = 'Description for RND Product 3 (lng-2)', name_lang_3='RND Product 3 (lng-3)', brief_lang_3='Brief for RND Product 3 (lng-3)', `description_lang_3` = 'Description for RND Product 3 (lng-3)', number='RND.80.8246.3', ean='200RND.80.8246.39', weight='1746', price_calculation_method='1', full_price_excl_vat_custom='33.64', full_price_incl_vat_custom='40.368', sale_price_excl_vat_custom='33.64', sale_price_incl_vat_custom='40.368', sale_price_excl_vat_cached='33.64', full_price_excl_vat_cached='33.64', sale_price_incl_vat_cached='40.368', full_price_incl_vat_cached='40.368', id_delivery_unit='8', stock_quantity='3.4', extended_warranty='7', vat_percent='20', id_category='5', id_brand='4', image='products/3.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='4', id_feature='1', `value_text` = '1143', value_number='1143';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='4', id_feature='2', `value_text` = '1216', value_number='1216';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='4', id_feature='3', `value_text` = '287', value_number='287';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='4', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='4', id_feature='5', `value_text` = '840', value_number='840';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='4', id_feature='6', `value_text` = '580', value_number='580';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='4', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 4 (lng-1)', brief_lang_1='Brief for RND Product 4 (lng-1)', `description_lang_1` = 'Description for RND Product 4 (lng-1)', name_lang_2='RND Product 4 (lng-2)', brief_lang_2='Brief for RND Product 4 (lng-2)', `description_lang_2` = 'Description for RND Product 4 (lng-2)', name_lang_3='RND Product 4 (lng-3)', brief_lang_3='Brief for RND Product 4 (lng-3)', `description_lang_3` = 'Description for RND Product 4 (lng-3)', number='RND.38.4401.4', ean='200RND.38.4401.40', weight='1911', price_calculation_method='1', full_price_excl_vat_custom='48.3', full_price_incl_vat_custom='57.96', sale_price_excl_vat_custom='38.64', sale_price_incl_vat_custom='46.368', sale_price_excl_vat_cached='38.64', full_price_excl_vat_cached='48.3', sale_price_incl_vat_cached='46.368', full_price_incl_vat_cached='57.96', id_delivery_unit='11', stock_quantity='5.3', extended_warranty='10', vat_percent='20', id_category='4', id_brand='1', image='products/5.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='5', id_feature='1', `value_text` = '1133', value_number='1133';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='5', id_feature='2', `value_text` = '1241', value_number='1241';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='5', id_feature='3', `value_text` = '265', value_number='265';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='5', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='5', id_feature='5', `value_text` = '1100', value_number='1100';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='5', id_feature='6', `value_text` = '790', value_number='790';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='5', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 5 (lng-1)', brief_lang_1='Brief for RND Product 5 (lng-1)', `description_lang_1` = 'Description for RND Product 5 (lng-1)', name_lang_2='RND Product 5 (lng-2)', brief_lang_2='Brief for RND Product 5 (lng-2)', `description_lang_2` = 'Description for RND Product 5 (lng-2)', name_lang_3='RND Product 5 (lng-3)', brief_lang_3='Brief for RND Product 5 (lng-3)', `description_lang_3` = 'Description for RND Product 5 (lng-3)', number='RND.32.9694.5', ean='200RND.32.9694.54', weight='1790', price_calculation_method='1', full_price_excl_vat_custom='22.0947', full_price_incl_vat_custom='26.51364', sale_price_excl_vat_custom='15.67', sale_price_incl_vat_custom='18.804', sale_price_excl_vat_cached='15.67', full_price_excl_vat_cached='22.0947', sale_price_incl_vat_cached='18.804', full_price_incl_vat_cached='26.51364', id_delivery_unit='21', stock_quantity='3', extended_warranty='18', vat_percent='20', id_category='4', id_brand='6', image='products/2.jpg', is_on_sale = 1, is_sale_out = 1, is_new = 0, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='6', id_feature='1', `value_text` = '1169', value_number='1169';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='6', id_feature='2', `value_text` = '1227', value_number='1227';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='6', id_feature='3', `value_text` = '293', value_number='293';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='6', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='6', id_feature='5', `value_text` = '1120', value_number='1120';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='6', id_feature='6', `value_text` = '750', value_number='750';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='6', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 6 (lng-1)', brief_lang_1='Brief for RND Product 6 (lng-1)', `description_lang_1` = 'Description for RND Product 6 (lng-1)', name_lang_2='RND Product 6 (lng-2)', brief_lang_2='Brief for RND Product 6 (lng-2)', `description_lang_2` = 'Description for RND Product 6 (lng-2)', name_lang_3='RND Product 6 (lng-3)', brief_lang_3='Brief for RND Product 6 (lng-3)', `description_lang_3` = 'Description for RND Product 6 (lng-3)', number='RND.17.8653.6', ean='200RND.17.8653.60', weight='1538', price_calculation_method='1', full_price_excl_vat_custom='20.51', full_price_incl_vat_custom='24.612', sale_price_excl_vat_custom='20.51', sale_price_incl_vat_custom='24.612', sale_price_excl_vat_cached='20.51', full_price_excl_vat_cached='20.51', sale_price_incl_vat_cached='24.612', full_price_incl_vat_cached='24.612', id_delivery_unit='6', stock_quantity='4', extended_warranty='32', vat_percent='20', id_category='3', id_brand='7', image='products/4.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='7', id_feature='1', `value_text` = '1079', value_number='1079';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='7', id_feature='2', `value_text` = '1227', value_number='1227';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='7', id_feature='3', `value_text` = '281', value_number='281';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='7', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='7', id_feature='5', `value_text` = '930', value_number='930';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='7', id_feature='6', `value_text` = '750', value_number='750';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='7', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 7 (lng-1)', brief_lang_1='Brief for RND Product 7 (lng-1)', `description_lang_1` = 'Description for RND Product 7 (lng-1)', name_lang_2='RND Product 7 (lng-2)', brief_lang_2='Brief for RND Product 7 (lng-2)', `description_lang_2` = 'Description for RND Product 7 (lng-2)', name_lang_3='RND Product 7 (lng-3)', brief_lang_3='Brief for RND Product 7 (lng-3)', `description_lang_3` = 'Description for RND Product 7 (lng-3)', number='RND.27.4995.7', ean='200RND.27.4995.79', weight='2277', price_calculation_method='1', full_price_excl_vat_custom='11.19', full_price_incl_vat_custom='13.428', sale_price_excl_vat_custom='11.19', sale_price_incl_vat_custom='13.428', sale_price_excl_vat_cached='11.19', full_price_excl_vat_cached='11.19', sale_price_incl_vat_cached='13.428', full_price_incl_vat_cached='13.428', id_delivery_unit='21', stock_quantity='8.9', extended_warranty='32', vat_percent='20', id_category='2', id_brand='7', image='products/4.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='8', id_feature='1', `value_text` = '1141', value_number='1141';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='8', id_feature='2', `value_text` = '1233', value_number='1233';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='8', id_feature='3', `value_text` = '252', value_number='252';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='8', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='8', id_feature='5', `value_text` = '1150', value_number='1150';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='8', id_feature='6', `value_text` = '910', value_number='910';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='8', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 8 (lng-1)', brief_lang_1='Brief for RND Product 8 (lng-1)', `description_lang_1` = 'Description for RND Product 8 (lng-1)', name_lang_2='RND Product 8 (lng-2)', brief_lang_2='Brief for RND Product 8 (lng-2)', `description_lang_2` = 'Description for RND Product 8 (lng-2)', name_lang_3='RND Product 8 (lng-3)', brief_lang_3='Brief for RND Product 8 (lng-3)', `description_lang_3` = 'Description for RND Product 8 (lng-3)', number='RND.53.8896.8', ean='200RND.53.8896.87', weight='1101', price_calculation_method='1', full_price_excl_vat_custom='40.81', full_price_incl_vat_custom='48.972', sale_price_excl_vat_custom='40.81', sale_price_incl_vat_custom='48.972', sale_price_excl_vat_cached='40.81', full_price_excl_vat_cached='40.81', sale_price_incl_vat_cached='48.972', full_price_incl_vat_cached='48.972', id_delivery_unit='16', stock_quantity='0.1', extended_warranty='24', vat_percent='20', id_category='2', id_brand='4', image='products/3.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='9', id_feature='1', `value_text` = '1092', value_number='1092';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='9', id_feature='2', `value_text` = '1211', value_number='1211';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='9', id_feature='3', `value_text` = '253', value_number='253';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='9', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='9', id_feature='5', `value_text` = '1050', value_number='1050';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='9', id_feature='6', `value_text` = '790', value_number='790';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='9', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 9 (lng-1)', brief_lang_1='Brief for RND Product 9 (lng-1)', `description_lang_1` = 'Description for RND Product 9 (lng-1)', name_lang_2='RND Product 9 (lng-2)', brief_lang_2='Brief for RND Product 9 (lng-2)', `description_lang_2` = 'Description for RND Product 9 (lng-2)', name_lang_3='RND Product 9 (lng-3)', brief_lang_3='Brief for RND Product 9 (lng-3)', `description_lang_3` = 'Description for RND Product 9 (lng-3)', number='RND.89.7964.9', ean='200RND.89.7964.96', weight='1634', price_calculation_method='1', full_price_excl_vat_custom='33.49', full_price_incl_vat_custom='40.188', sale_price_excl_vat_custom='33.49', sale_price_incl_vat_custom='40.188', sale_price_excl_vat_cached='33.49', full_price_excl_vat_cached='33.49', sale_price_incl_vat_cached='40.188', full_price_incl_vat_cached='40.188', id_delivery_unit='4', stock_quantity='6.1', extended_warranty='16', vat_percent='20', id_category='5', id_brand='6', image='products/4.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='10', id_feature='1', `value_text` = '1063', value_number='1063';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='10', id_feature='2', `value_text` = '1214', value_number='1214';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='10', id_feature='3', `value_text` = '280', value_number='280';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='10', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='10', id_feature='5', `value_text` = '1180', value_number='1180';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='10', id_feature='6', `value_text` = '880', value_number='880';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='10', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 10 (lng-1)', brief_lang_1='Brief for RND Product 10 (lng-1)', `description_lang_1` = 'Description for RND Product 10 (lng-1)', name_lang_2='RND Product 10 (lng-2)', brief_lang_2='Brief for RND Product 10 (lng-2)', `description_lang_2` = 'Description for RND Product 10 (lng-2)', name_lang_3='RND Product 10 (lng-3)', brief_lang_3='Brief for RND Product 10 (lng-3)', `description_lang_3` = 'Description for RND Product 10 (lng-3)', number='RND.50.6054.10', ean='200RND.50.6054.101', weight='617', price_calculation_method='1', full_price_excl_vat_custom='26.81', full_price_incl_vat_custom='32.172', sale_price_excl_vat_custom='26.81', sale_price_incl_vat_custom='32.172', sale_price_excl_vat_cached='26.81', full_price_excl_vat_cached='26.81', sale_price_incl_vat_cached='32.172', full_price_incl_vat_cached='32.172', id_delivery_unit='19', stock_quantity='0', extended_warranty='29', vat_percent='20', id_category='2', id_brand='6', image='products/3.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='11', id_feature='1', `value_text` = '1078', value_number='1078';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='11', id_feature='2', `value_text` = '1220', value_number='1220';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='11', id_feature='3', `value_text` = '251', value_number='251';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='11', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='11', id_feature='5', `value_text` = '1070', value_number='1070';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='11', id_feature='6', `value_text` = '580', value_number='580';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='11', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 11 (lng-1)', brief_lang_1='Brief for RND Product 11 (lng-1)', `description_lang_1` = 'Description for RND Product 11 (lng-1)', name_lang_2='RND Product 11 (lng-2)', brief_lang_2='Brief for RND Product 11 (lng-2)', `description_lang_2` = 'Description for RND Product 11 (lng-2)', name_lang_3='RND Product 11 (lng-3)', brief_lang_3='Brief for RND Product 11 (lng-3)', `description_lang_3` = 'Description for RND Product 11 (lng-3)', number='RND.30.5718.11', ean='200RND.30.5718.114', weight='1347', price_calculation_method='1', full_price_excl_vat_custom='24.19', full_price_incl_vat_custom='29.028', sale_price_excl_vat_custom='24.19', sale_price_incl_vat_custom='29.028', sale_price_excl_vat_cached='24.19', full_price_excl_vat_cached='24.19', sale_price_incl_vat_cached='29.028', full_price_incl_vat_cached='29.028', id_delivery_unit='17', stock_quantity='5.3', extended_warranty='29', vat_percent='20', id_category='7', id_brand='7', image='products/6.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='12', id_feature='1', `value_text` = '1071', value_number='1071';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='12', id_feature='2', `value_text` = '1237', value_number='1237';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='12', id_feature='3', `value_text` = '260', value_number='260';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='12', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='12', id_feature='5', `value_text` = '850', value_number='850';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='12', id_feature='6', `value_text` = '940', value_number='940';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='12', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 12 (lng-1)', brief_lang_1='Brief for RND Product 12 (lng-1)', `description_lang_1` = 'Description for RND Product 12 (lng-1)', name_lang_2='RND Product 12 (lng-2)', brief_lang_2='Brief for RND Product 12 (lng-2)', `description_lang_2` = 'Description for RND Product 12 (lng-2)', name_lang_3='RND Product 12 (lng-3)', brief_lang_3='Brief for RND Product 12 (lng-3)', `description_lang_3` = 'Description for RND Product 12 (lng-3)', number='RND.43.2285.12', ean='200RND.43.2285.127', weight='1680', price_calculation_method='1', full_price_excl_vat_custom='13.65', full_price_incl_vat_custom='16.38', sale_price_excl_vat_custom='13.65', sale_price_incl_vat_custom='16.38', sale_price_excl_vat_cached='13.65', full_price_excl_vat_cached='13.65', sale_price_incl_vat_cached='16.38', full_price_incl_vat_cached='16.38', id_delivery_unit='17', stock_quantity='8.7', extended_warranty='24', vat_percent='20', id_category='5', id_brand='4', image='products/5.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='13', id_feature='1', `value_text` = '1164', value_number='1164';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='13', id_feature='2', `value_text` = '1230', value_number='1230';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='13', id_feature='3', `value_text` = '297', value_number='297';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='13', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='13', id_feature='5', `value_text` = '1070', value_number='1070';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='13', id_feature='6', `value_text` = '690', value_number='690';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='13', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 13 (lng-1)', brief_lang_1='Brief for RND Product 13 (lng-1)', `description_lang_1` = 'Description for RND Product 13 (lng-1)', name_lang_2='RND Product 13 (lng-2)', brief_lang_2='Brief for RND Product 13 (lng-2)', `description_lang_2` = 'Description for RND Product 13 (lng-2)', name_lang_3='RND Product 13 (lng-3)', brief_lang_3='Brief for RND Product 13 (lng-3)', `description_lang_3` = 'Description for RND Product 13 (lng-3)', number='RND.40.9077.13', ean='200RND.40.9077.135', weight='1658', price_calculation_method='1', full_price_excl_vat_custom='30.39', full_price_incl_vat_custom='36.468', sale_price_excl_vat_custom='30.39', sale_price_incl_vat_custom='36.468', sale_price_excl_vat_cached='30.39', full_price_excl_vat_cached='30.39', sale_price_incl_vat_cached='36.468', full_price_incl_vat_cached='36.468', id_delivery_unit='13', stock_quantity='5', extended_warranty='14', vat_percent='20', id_category='4', id_brand='2', image='products/6.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='14', id_feature='1', `value_text` = '1156', value_number='1156';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='14', id_feature='2', `value_text` = '1209', value_number='1209';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='14', id_feature='3', `value_text` = '252', value_number='252';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='14', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='14', id_feature='5', `value_text` = '840', value_number='840';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='14', id_feature='6', `value_text` = '770', value_number='770';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='14', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 14 (lng-1)', brief_lang_1='Brief for RND Product 14 (lng-1)', `description_lang_1` = 'Description for RND Product 14 (lng-1)', name_lang_2='RND Product 14 (lng-2)', brief_lang_2='Brief for RND Product 14 (lng-2)', `description_lang_2` = 'Description for RND Product 14 (lng-2)', name_lang_3='RND Product 14 (lng-3)', brief_lang_3='Brief for RND Product 14 (lng-3)', `description_lang_3` = 'Description for RND Product 14 (lng-3)', number='RND.51.2324.14', ean='200RND.51.2324.144', weight='2386', price_calculation_method='1', full_price_excl_vat_custom='36.33', full_price_incl_vat_custom='43.596', sale_price_excl_vat_custom='36.33', sale_price_incl_vat_custom='43.596', sale_price_excl_vat_cached='36.33', full_price_excl_vat_cached='36.33', sale_price_incl_vat_cached='43.596', full_price_incl_vat_cached='43.596', id_delivery_unit='19', stock_quantity='7.8', extended_warranty='20', vat_percent='20', id_category='6', id_brand='2', image='products/2.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='15', id_feature='1', `value_text` = '1145', value_number='1145';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='15', id_feature='2', `value_text` = '1209', value_number='1209';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='15', id_feature='3', `value_text` = '284', value_number='284';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='15', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='15', id_feature='5', `value_text` = '1030', value_number='1030';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='15', id_feature='6', `value_text` = '650', value_number='650';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='15', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 15 (lng-1)', brief_lang_1='Brief for RND Product 15 (lng-1)', `description_lang_1` = 'Description for RND Product 15 (lng-1)', name_lang_2='RND Product 15 (lng-2)', brief_lang_2='Brief for RND Product 15 (lng-2)', `description_lang_2` = 'Description for RND Product 15 (lng-2)', name_lang_3='RND Product 15 (lng-3)', brief_lang_3='Brief for RND Product 15 (lng-3)', `description_lang_3` = 'Description for RND Product 15 (lng-3)', number='RND.91.8184.15', ean='200RND.91.8184.153', weight='1902', price_calculation_method='1', full_price_excl_vat_custom='19.02', full_price_incl_vat_custom='22.824', sale_price_excl_vat_custom='19.02', sale_price_incl_vat_custom='22.824', sale_price_excl_vat_cached='19.02', full_price_excl_vat_cached='19.02', sale_price_incl_vat_cached='22.824', full_price_incl_vat_cached='22.824', id_delivery_unit='11', stock_quantity='5.3', extended_warranty='14', vat_percent='20', id_category='1', id_brand='3', image='products/6.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 1, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='16', id_feature='1', `value_text` = '1069', value_number='1069';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='16', id_feature='2', `value_text` = '1235', value_number='1235';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='16', id_feature='3', `value_text` = '276', value_number='276';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='16', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='16', id_feature='5', `value_text` = '870', value_number='870';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='16', id_feature='6', `value_text` = '640', value_number='640';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='16', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 16 (lng-1)', brief_lang_1='Brief for RND Product 16 (lng-1)', `description_lang_1` = 'Description for RND Product 16 (lng-1)', name_lang_2='RND Product 16 (lng-2)', brief_lang_2='Brief for RND Product 16 (lng-2)', `description_lang_2` = 'Description for RND Product 16 (lng-2)', name_lang_3='RND Product 16 (lng-3)', brief_lang_3='Brief for RND Product 16 (lng-3)', `description_lang_3` = 'Description for RND Product 16 (lng-3)', number='RND.55.9060.16', ean='200RND.55.9060.160', weight='1561', price_calculation_method='1', full_price_excl_vat_custom='12.03', full_price_incl_vat_custom='14.436', sale_price_excl_vat_custom='12.03', sale_price_incl_vat_custom='14.436', sale_price_excl_vat_cached='12.03', full_price_excl_vat_cached='12.03', sale_price_incl_vat_cached='14.436', full_price_incl_vat_cached='14.436', id_delivery_unit='16', stock_quantity='9.2', extended_warranty='27', vat_percent='20', id_category='2', id_brand='3', image='products/5.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='17', id_feature='1', `value_text` = '1104', value_number='1104';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='17', id_feature='2', `value_text` = '1212', value_number='1212';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='17', id_feature='3', `value_text` = '262', value_number='262';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='17', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='17', id_feature='5', `value_text` = '870', value_number='870';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='17', id_feature='6', `value_text` = '590', value_number='590';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='17', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 17 (lng-1)', brief_lang_1='Brief for RND Product 17 (lng-1)', `description_lang_1` = 'Description for RND Product 17 (lng-1)', name_lang_2='RND Product 17 (lng-2)', brief_lang_2='Brief for RND Product 17 (lng-2)', `description_lang_2` = 'Description for RND Product 17 (lng-2)', name_lang_3='RND Product 17 (lng-3)', brief_lang_3='Brief for RND Product 17 (lng-3)', `description_lang_3` = 'Description for RND Product 17 (lng-3)', number='RND.80.5269.17', ean='200RND.80.5269.170', weight='1716', price_calculation_method='1', full_price_excl_vat_custom='19.11', full_price_incl_vat_custom='22.932', sale_price_excl_vat_custom='19.11', sale_price_incl_vat_custom='22.932', sale_price_excl_vat_cached='19.11', full_price_excl_vat_cached='19.11', sale_price_incl_vat_cached='22.932', full_price_incl_vat_cached='22.932', id_delivery_unit='9', stock_quantity='1.4', extended_warranty='16', vat_percent='20', id_category='3', id_brand='1', image='products/4.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='18', id_feature='1', `value_text` = '1008', value_number='1008';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='18', id_feature='2', `value_text` = '1229', value_number='1229';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='18', id_feature='3', `value_text` = '252', value_number='252';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='18', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='18', id_feature='5', `value_text` = '990', value_number='990';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='18', id_feature='6', `value_text` = '610', value_number='610';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='18', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 18 (lng-1)', brief_lang_1='Brief for RND Product 18 (lng-1)', `description_lang_1` = 'Description for RND Product 18 (lng-1)', name_lang_2='RND Product 18 (lng-2)', brief_lang_2='Brief for RND Product 18 (lng-2)', `description_lang_2` = 'Description for RND Product 18 (lng-2)', name_lang_3='RND Product 18 (lng-3)', brief_lang_3='Brief for RND Product 18 (lng-3)', `description_lang_3` = 'Description for RND Product 18 (lng-3)', number='RND.73.8260.18', ean='200RND.73.8260.189', weight='2028', price_calculation_method='1', full_price_excl_vat_custom='44.0946', full_price_incl_vat_custom='52.91352', sale_price_excl_vat_custom='43.23', sale_price_incl_vat_custom='51.876', sale_price_excl_vat_cached='43.23', full_price_excl_vat_cached='44.0946', sale_price_incl_vat_cached='51.876', full_price_incl_vat_cached='52.91352', id_delivery_unit='2', stock_quantity='3.8', extended_warranty='35', vat_percent='20', id_category='7', id_brand='6', image='products/4.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 0, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='19', id_feature='1', `value_text` = '1173', value_number='1173';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='19', id_feature='2', `value_text` = '1237', value_number='1237';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='19', id_feature='3', `value_text` = '250', value_number='250';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='19', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='19', id_feature='5', `value_text` = '1030', value_number='1030';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='19', id_feature='6', `value_text` = '820', value_number='820';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='19', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 19 (lng-1)', brief_lang_1='Brief for RND Product 19 (lng-1)', `description_lang_1` = 'Description for RND Product 19 (lng-1)', name_lang_2='RND Product 19 (lng-2)', brief_lang_2='Brief for RND Product 19 (lng-2)', `description_lang_2` = 'Description for RND Product 19 (lng-2)', name_lang_3='RND Product 19 (lng-3)', brief_lang_3='Brief for RND Product 19 (lng-3)', `description_lang_3` = 'Description for RND Product 19 (lng-3)', number='RND.15.4174.19', ean='200RND.15.4174.192', weight='2253', price_calculation_method='1', full_price_excl_vat_custom='40.71', full_price_incl_vat_custom='48.852', sale_price_excl_vat_custom='40.71', sale_price_incl_vat_custom='48.852', sale_price_excl_vat_cached='40.71', full_price_excl_vat_cached='40.71', sale_price_incl_vat_cached='48.852', full_price_incl_vat_cached='48.852', id_delivery_unit='17', stock_quantity='7.4', extended_warranty='23', vat_percent='20', id_category='7', id_brand='4', image='products/3.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='20', id_feature='1', `value_text` = '1195', value_number='1195';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='20', id_feature='2', `value_text` = '1223', value_number='1223';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='20', id_feature='3', `value_text` = '277', value_number='277';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='20', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='20', id_feature='5', `value_text` = '870', value_number='870';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='20', id_feature='6', `value_text` = '700', value_number='700';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='20', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 20 (lng-1)', brief_lang_1='Brief for RND Product 20 (lng-1)', `description_lang_1` = 'Description for RND Product 20 (lng-1)', name_lang_2='RND Product 20 (lng-2)', brief_lang_2='Brief for RND Product 20 (lng-2)', `description_lang_2` = 'Description for RND Product 20 (lng-2)', name_lang_3='RND Product 20 (lng-3)', brief_lang_3='Brief for RND Product 20 (lng-3)', `description_lang_3` = 'Description for RND Product 20 (lng-3)', number='RND.95.3784.20', ean='200RND.95.3784.204', weight='770', price_calculation_method='1', full_price_excl_vat_custom='13.34', full_price_incl_vat_custom='16.008', sale_price_excl_vat_custom='13.34', sale_price_incl_vat_custom='16.008', sale_price_excl_vat_cached='13.34', full_price_excl_vat_cached='13.34', sale_price_incl_vat_cached='16.008', full_price_incl_vat_cached='16.008', id_delivery_unit='3', stock_quantity='0.9', extended_warranty='35', vat_percent='20', id_category='1', id_brand='4', image='products/1.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 0, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='21', id_feature='1', `value_text` = '1015', value_number='1015';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='21', id_feature='2', `value_text` = '1221', value_number='1221';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='21', id_feature='3', `value_text` = '275', value_number='275';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='21', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='21', id_feature='5', `value_text` = '890', value_number='890';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='21', id_feature='6', `value_text` = '960', value_number='960';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='21', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 21 (lng-1)', brief_lang_1='Brief for RND Product 21 (lng-1)', `description_lang_1` = 'Description for RND Product 21 (lng-1)', name_lang_2='RND Product 21 (lng-2)', brief_lang_2='Brief for RND Product 21 (lng-2)', `description_lang_2` = 'Description for RND Product 21 (lng-2)', name_lang_3='RND Product 21 (lng-3)', brief_lang_3='Brief for RND Product 21 (lng-3)', `description_lang_3` = 'Description for RND Product 21 (lng-3)', number='RND.20.1224.21', ean='200RND.20.1224.212', weight='1421', price_calculation_method='1', full_price_excl_vat_custom='29.14', full_price_incl_vat_custom='34.968', sale_price_excl_vat_custom='29.14', sale_price_incl_vat_custom='34.968', sale_price_excl_vat_cached='29.14', full_price_excl_vat_cached='29.14', sale_price_incl_vat_cached='34.968', full_price_incl_vat_cached='34.968', id_delivery_unit='20', stock_quantity='9', extended_warranty='10', vat_percent='20', id_category='7', id_brand='2', image='products/7.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 0, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='22', id_feature='1', `value_text` = '1166', value_number='1166';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='22', id_feature='2', `value_text` = '1210', value_number='1210';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='22', id_feature='3', `value_text` = '296', value_number='296';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='22', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='22', id_feature='5', `value_text` = '1070', value_number='1070';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='22', id_feature='6', `value_text` = '710', value_number='710';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='22', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 22 (lng-1)', brief_lang_1='Brief for RND Product 22 (lng-1)', `description_lang_1` = 'Description for RND Product 22 (lng-1)', name_lang_2='RND Product 22 (lng-2)', brief_lang_2='Brief for RND Product 22 (lng-2)', `description_lang_2` = 'Description for RND Product 22 (lng-2)', name_lang_3='RND Product 22 (lng-3)', brief_lang_3='Brief for RND Product 22 (lng-3)', `description_lang_3` = 'Description for RND Product 22 (lng-3)', number='RND.13.4908.22', ean='200RND.13.4908.227', weight='2428', price_calculation_method='1', full_price_excl_vat_custom='7.12', full_price_incl_vat_custom='8.544', sale_price_excl_vat_custom='7.12', sale_price_incl_vat_custom='8.544', sale_price_excl_vat_cached='7.12', full_price_excl_vat_cached='7.12', sale_price_incl_vat_cached='8.544', full_price_incl_vat_cached='8.544', id_delivery_unit='7', stock_quantity='2.3', extended_warranty='5', vat_percent='20', id_category='7', id_brand='3', image='products/7.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='23', id_feature='1', `value_text` = '1087', value_number='1087';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='23', id_feature='2', `value_text` = '1229', value_number='1229';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='23', id_feature='3', `value_text` = '297', value_number='297';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='23', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='23', id_feature='5', `value_text` = '890', value_number='890';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='23', id_feature='6', `value_text` = '840', value_number='840';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='23', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 23 (lng-1)', brief_lang_1='Brief for RND Product 23 (lng-1)', `description_lang_1` = 'Description for RND Product 23 (lng-1)', name_lang_2='RND Product 23 (lng-2)', brief_lang_2='Brief for RND Product 23 (lng-2)', `description_lang_2` = 'Description for RND Product 23 (lng-2)', name_lang_3='RND Product 23 (lng-3)', brief_lang_3='Brief for RND Product 23 (lng-3)', `description_lang_3` = 'Description for RND Product 23 (lng-3)', number='RND.31.1313.23', ean='200RND.31.1313.235', weight='702', price_calculation_method='1', full_price_excl_vat_custom='37.2589', full_price_incl_vat_custom='44.71068', sale_price_excl_vat_custom='31.31', sale_price_incl_vat_custom='37.572', sale_price_excl_vat_cached='31.31', full_price_excl_vat_cached='37.2589', sale_price_incl_vat_cached='37.572', full_price_incl_vat_cached='44.71068', id_delivery_unit='8', stock_quantity='4.1', extended_warranty='19', vat_percent='20', id_category='4', id_brand='6', image='products/4.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='24', id_feature='1', `value_text` = '1147', value_number='1147';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='24', id_feature='2', `value_text` = '1215', value_number='1215';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='24', id_feature='3', `value_text` = '273', value_number='273';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='24', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='24', id_feature='5', `value_text` = '790', value_number='790';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='24', id_feature='6', `value_text` = '610', value_number='610';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='24', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 24 (lng-1)', brief_lang_1='Brief for RND Product 24 (lng-1)', `description_lang_1` = 'Description for RND Product 24 (lng-1)', name_lang_2='RND Product 24 (lng-2)', brief_lang_2='Brief for RND Product 24 (lng-2)', `description_lang_2` = 'Description for RND Product 24 (lng-2)', name_lang_3='RND Product 24 (lng-3)', brief_lang_3='Brief for RND Product 24 (lng-3)', `description_lang_3` = 'Description for RND Product 24 (lng-3)', number='RND.71.3395.24', ean='200RND.71.3395.246', weight='1423', price_calculation_method='1', full_price_excl_vat_custom='12.23', full_price_incl_vat_custom='14.676', sale_price_excl_vat_custom='12.23', sale_price_incl_vat_custom='14.676', sale_price_excl_vat_cached='12.23', full_price_excl_vat_cached='12.23', sale_price_incl_vat_cached='14.676', full_price_incl_vat_cached='14.676', id_delivery_unit='5', stock_quantity='2.8', extended_warranty='28', vat_percent='20', id_category='3', id_brand='1', image='products/3.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='25', id_feature='1', `value_text` = '1106', value_number='1106';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='25', id_feature='2', `value_text` = '1230', value_number='1230';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='25', id_feature='3', `value_text` = '265', value_number='265';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='25', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='25', id_feature='5', `value_text` = '980', value_number='980';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='25', id_feature='6', `value_text` = '660', value_number='660';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='25', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 25 (lng-1)', brief_lang_1='Brief for RND Product 25 (lng-1)', `description_lang_1` = 'Description for RND Product 25 (lng-1)', name_lang_2='RND Product 25 (lng-2)', brief_lang_2='Brief for RND Product 25 (lng-2)', `description_lang_2` = 'Description for RND Product 25 (lng-2)', name_lang_3='RND Product 25 (lng-3)', brief_lang_3='Brief for RND Product 25 (lng-3)', `description_lang_3` = 'Description for RND Product 25 (lng-3)', number='RND.72.2583.25', ean='200RND.72.2583.256', weight='968', price_calculation_method='1', full_price_excl_vat_custom='13.14', full_price_incl_vat_custom='15.768', sale_price_excl_vat_custom='13.14', sale_price_incl_vat_custom='15.768', sale_price_excl_vat_cached='13.14', full_price_excl_vat_cached='13.14', sale_price_incl_vat_cached='15.768', full_price_incl_vat_cached='15.768', id_delivery_unit='5', stock_quantity='6.2', extended_warranty='4', vat_percent='20', id_category='4', id_brand='6', image='products/2.jpg', is_on_sale = 1, is_sale_out = 1, is_new = 0, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='26', id_feature='1', `value_text` = '1180', value_number='1180';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='26', id_feature='2', `value_text` = '1214', value_number='1214';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='26', id_feature='3', `value_text` = '296', value_number='296';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='26', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='26', id_feature='5', `value_text` = '1090', value_number='1090';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='26', id_feature='6', `value_text` = '650', value_number='650';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='26', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 26 (lng-1)', brief_lang_1='Brief for RND Product 26 (lng-1)', `description_lang_1` = 'Description for RND Product 26 (lng-1)', name_lang_2='RND Product 26 (lng-2)', brief_lang_2='Brief for RND Product 26 (lng-2)', `description_lang_2` = 'Description for RND Product 26 (lng-2)', name_lang_3='RND Product 26 (lng-3)', brief_lang_3='Brief for RND Product 26 (lng-3)', `description_lang_3` = 'Description for RND Product 26 (lng-3)', number='RND.51.8371.26', ean='200RND.51.8371.267', weight='2088', price_calculation_method='1', full_price_excl_vat_custom='20.52', full_price_incl_vat_custom='24.624', sale_price_excl_vat_custom='20.52', sale_price_incl_vat_custom='24.624', sale_price_excl_vat_cached='20.52', full_price_excl_vat_cached='20.52', sale_price_incl_vat_cached='24.624', full_price_incl_vat_cached='24.624', id_delivery_unit='20', stock_quantity='5.8', extended_warranty='12', vat_percent='20', id_category='2', id_brand='6', image='products/1.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='27', id_feature='1', `value_text` = '1167', value_number='1167';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='27', id_feature='2', `value_text` = '1212', value_number='1212';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='27', id_feature='3', `value_text` = '257', value_number='257';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='27', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='27', id_feature='5', `value_text` = '1180', value_number='1180';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='27', id_feature='6', `value_text` = '660', value_number='660';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='27', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 27 (lng-1)', brief_lang_1='Brief for RND Product 27 (lng-1)', `description_lang_1` = 'Description for RND Product 27 (lng-1)', name_lang_2='RND Product 27 (lng-2)', brief_lang_2='Brief for RND Product 27 (lng-2)', `description_lang_2` = 'Description for RND Product 27 (lng-2)', name_lang_3='RND Product 27 (lng-3)', brief_lang_3='Brief for RND Product 27 (lng-3)', `description_lang_3` = 'Description for RND Product 27 (lng-3)', number='RND.87.6097.27', ean='200RND.87.6097.270', weight='1601', price_calculation_method='1', full_price_excl_vat_custom='5.34', full_price_incl_vat_custom='6.408', sale_price_excl_vat_custom='5.34', sale_price_incl_vat_custom='6.408', sale_price_excl_vat_cached='5.34', full_price_excl_vat_cached='5.34', sale_price_incl_vat_cached='6.408', full_price_incl_vat_cached='6.408', id_delivery_unit='9', stock_quantity='9.7', extended_warranty='15', vat_percent='20', id_category='5', id_brand='1', image='products/4.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='28', id_feature='1', `value_text` = '1116', value_number='1116';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='28', id_feature='2', `value_text` = '1217', value_number='1217';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='28', id_feature='3', `value_text` = '287', value_number='287';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='28', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='28', id_feature='5', `value_text` = '900', value_number='900';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='28', id_feature='6', `value_text` = '880', value_number='880';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='28', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 28 (lng-1)', brief_lang_1='Brief for RND Product 28 (lng-1)', `description_lang_1` = 'Description for RND Product 28 (lng-1)', name_lang_2='RND Product 28 (lng-2)', brief_lang_2='Brief for RND Product 28 (lng-2)', `description_lang_2` = 'Description for RND Product 28 (lng-2)', name_lang_3='RND Product 28 (lng-3)', brief_lang_3='Brief for RND Product 28 (lng-3)', `description_lang_3` = 'Description for RND Product 28 (lng-3)', number='RND.56.6877.28', ean='200RND.56.6877.281', weight='2495', price_calculation_method='1', full_price_excl_vat_custom='13.31', full_price_incl_vat_custom='15.972', sale_price_excl_vat_custom='13.31', sale_price_incl_vat_custom='15.972', sale_price_excl_vat_cached='13.31', full_price_excl_vat_cached='13.31', sale_price_incl_vat_cached='15.972', full_price_incl_vat_cached='15.972', id_delivery_unit='10', stock_quantity='9.9', extended_warranty='18', vat_percent='20', id_category='1', id_brand='2', image='products/4.jpg', is_on_sale = 1, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='29', id_feature='1', `value_text` = '1091', value_number='1091';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='29', id_feature='2', `value_text` = '1203', value_number='1203';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='29', id_feature='3', `value_text` = '273', value_number='273';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='29', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='29', id_feature='5', `value_text` = '1140', value_number='1140';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='29', id_feature='6', `value_text` = '820', value_number='820';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='29', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 29 (lng-1)', brief_lang_1='Brief for RND Product 29 (lng-1)', `description_lang_1` = 'Description for RND Product 29 (lng-1)', name_lang_2='RND Product 29 (lng-2)', brief_lang_2='Brief for RND Product 29 (lng-2)', `description_lang_2` = 'Description for RND Product 29 (lng-2)', name_lang_3='RND Product 29 (lng-3)', brief_lang_3='Brief for RND Product 29 (lng-3)', `description_lang_3` = 'Description for RND Product 29 (lng-3)', number='RND.70.5132.29', ean='200RND.70.5132.291', weight='552', price_calculation_method='1', full_price_excl_vat_custom='28.51', full_price_incl_vat_custom='34.212', sale_price_excl_vat_custom='28.51', sale_price_incl_vat_custom='34.212', sale_price_excl_vat_cached='28.51', full_price_excl_vat_cached='28.51', sale_price_incl_vat_cached='34.212', full_price_incl_vat_cached='34.212', id_delivery_unit='7', stock_quantity='7.2', extended_warranty='33', vat_percent='20', id_category='4', id_brand='6', image='products/3.jpg', is_on_sale = 1, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='30', id_feature='1', `value_text` = '1112', value_number='1112';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='30', id_feature='2', `value_text` = '1248', value_number='1248';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='30', id_feature='3', `value_text` = '262', value_number='262';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='30', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='30', id_feature='5', `value_text` = '1190', value_number='1190';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='30', id_feature='6', `value_text` = '710', value_number='710';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='30', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 30 (lng-1)', brief_lang_1='Brief for RND Product 30 (lng-1)', `description_lang_1` = 'Description for RND Product 30 (lng-1)', name_lang_2='RND Product 30 (lng-2)', brief_lang_2='Brief for RND Product 30 (lng-2)', `description_lang_2` = 'Description for RND Product 30 (lng-2)', name_lang_3='RND Product 30 (lng-3)', brief_lang_3='Brief for RND Product 30 (lng-3)', `description_lang_3` = 'Description for RND Product 30 (lng-3)', number='RND.45.6319.30', ean='200RND.45.6319.309', weight='1367', price_calculation_method='1', full_price_excl_vat_custom='41.68', full_price_incl_vat_custom='50.016', sale_price_excl_vat_custom='41.68', sale_price_incl_vat_custom='50.016', sale_price_excl_vat_cached='41.68', full_price_excl_vat_cached='41.68', sale_price_incl_vat_cached='50.016', full_price_incl_vat_cached='50.016', id_delivery_unit='10', stock_quantity='1.9', extended_warranty='9', vat_percent='20', id_category='7', id_brand='1', image='products/3.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='31', id_feature='1', `value_text` = '1027', value_number='1027';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='31', id_feature='2', `value_text` = '1217', value_number='1217';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='31', id_feature='3', `value_text` = '273', value_number='273';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='31', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='31', id_feature='5', `value_text` = '800', value_number='800';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='31', id_feature='6', `value_text` = '890', value_number='890';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='31', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 31 (lng-1)', brief_lang_1='Brief for RND Product 31 (lng-1)', `description_lang_1` = 'Description for RND Product 31 (lng-1)', name_lang_2='RND Product 31 (lng-2)', brief_lang_2='Brief for RND Product 31 (lng-2)', `description_lang_2` = 'Description for RND Product 31 (lng-2)', name_lang_3='RND Product 31 (lng-3)', brief_lang_3='Brief for RND Product 31 (lng-3)', `description_lang_3` = 'Description for RND Product 31 (lng-3)', number='RND.65.5058.31', ean='200RND.65.5058.319', weight='609', price_calculation_method='1', full_price_excl_vat_custom='35.72', full_price_incl_vat_custom='42.864', sale_price_excl_vat_custom='35.72', sale_price_incl_vat_custom='42.864', sale_price_excl_vat_cached='35.72', full_price_excl_vat_cached='35.72', sale_price_incl_vat_cached='42.864', full_price_incl_vat_cached='42.864', id_delivery_unit='7', stock_quantity='1.2', extended_warranty='20', vat_percent='20', id_category='7', id_brand='6', image='products/7.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='32', id_feature='1', `value_text` = '1084', value_number='1084';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='32', id_feature='2', `value_text` = '1240', value_number='1240';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='32', id_feature='3', `value_text` = '292', value_number='292';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='32', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='32', id_feature='5', `value_text` = '840', value_number='840';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='32', id_feature='6', `value_text` = '530', value_number='530';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='32', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 32 (lng-1)', brief_lang_1='Brief for RND Product 32 (lng-1)', `description_lang_1` = 'Description for RND Product 32 (lng-1)', name_lang_2='RND Product 32 (lng-2)', brief_lang_2='Brief for RND Product 32 (lng-2)', `description_lang_2` = 'Description for RND Product 32 (lng-2)', name_lang_3='RND Product 32 (lng-3)', brief_lang_3='Brief for RND Product 32 (lng-3)', `description_lang_3` = 'Description for RND Product 32 (lng-3)', number='RND.79.6087.32', ean='200RND.79.6087.322', weight='1708', price_calculation_method='1', full_price_excl_vat_custom='32.97', full_price_incl_vat_custom='39.564', sale_price_excl_vat_custom='32.97', sale_price_incl_vat_custom='39.564', sale_price_excl_vat_cached='32.97', full_price_excl_vat_cached='32.97', sale_price_incl_vat_cached='39.564', full_price_incl_vat_cached='39.564', id_delivery_unit='12', stock_quantity='0.5', extended_warranty='3', vat_percent='20', id_category='1', id_brand='6', image='products/3.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='33', id_feature='1', `value_text` = '1149', value_number='1149';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='33', id_feature='2', `value_text` = '1219', value_number='1219';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='33', id_feature='3', `value_text` = '279', value_number='279';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='33', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='33', id_feature='5', `value_text` = '1090', value_number='1090';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='33', id_feature='6', `value_text` = '690', value_number='690';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='33', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 33 (lng-1)', brief_lang_1='Brief for RND Product 33 (lng-1)', `description_lang_1` = 'Description for RND Product 33 (lng-1)', name_lang_2='RND Product 33 (lng-2)', brief_lang_2='Brief for RND Product 33 (lng-2)', `description_lang_2` = 'Description for RND Product 33 (lng-2)', name_lang_3='RND Product 33 (lng-3)', brief_lang_3='Brief for RND Product 33 (lng-3)', `description_lang_3` = 'Description for RND Product 33 (lng-3)', number='RND.91.4566.33', ean='200RND.91.4566.339', weight='867', price_calculation_method='1', full_price_excl_vat_custom='26.35', full_price_incl_vat_custom='31.62', sale_price_excl_vat_custom='26.35', sale_price_incl_vat_custom='31.62', sale_price_excl_vat_cached='26.35', full_price_excl_vat_cached='26.35', sale_price_incl_vat_cached='31.62', full_price_incl_vat_cached='31.62', id_delivery_unit='9', stock_quantity='1.9', extended_warranty='2', vat_percent='20', id_category='7', id_brand='1', image='products/6.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='34', id_feature='1', `value_text` = '1101', value_number='1101';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='34', id_feature='2', `value_text` = '1207', value_number='1207';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='34', id_feature='3', `value_text` = '282', value_number='282';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='34', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='34', id_feature='5', `value_text` = '1150', value_number='1150';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='34', id_feature='6', `value_text` = '760', value_number='760';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='34', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 34 (lng-1)', brief_lang_1='Brief for RND Product 34 (lng-1)', `description_lang_1` = 'Description for RND Product 34 (lng-1)', name_lang_2='RND Product 34 (lng-2)', brief_lang_2='Brief for RND Product 34 (lng-2)', `description_lang_2` = 'Description for RND Product 34 (lng-2)', name_lang_3='RND Product 34 (lng-3)', brief_lang_3='Brief for RND Product 34 (lng-3)', `description_lang_3` = 'Description for RND Product 34 (lng-3)', number='RND.70.7104.34', ean='200RND.70.7104.346', weight='2333', price_calculation_method='1', full_price_excl_vat_custom='40.94', full_price_incl_vat_custom='49.128', sale_price_excl_vat_custom='40.94', sale_price_incl_vat_custom='49.128', sale_price_excl_vat_cached='40.94', full_price_excl_vat_cached='40.94', sale_price_incl_vat_cached='49.128', full_price_incl_vat_cached='49.128', id_delivery_unit='21', stock_quantity='1.7', extended_warranty='1', vat_percent='20', id_category='7', id_brand='3', image='products/3.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='35', id_feature='1', `value_text` = '1184', value_number='1184';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='35', id_feature='2', `value_text` = '1200', value_number='1200';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='35', id_feature='3', `value_text` = '275', value_number='275';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='35', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='35', id_feature='5', `value_text` = '900', value_number='900';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='35', id_feature='6', `value_text` = '660', value_number='660';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='35', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 35 (lng-1)', brief_lang_1='Brief for RND Product 35 (lng-1)', `description_lang_1` = 'Description for RND Product 35 (lng-1)', name_lang_2='RND Product 35 (lng-2)', brief_lang_2='Brief for RND Product 35 (lng-2)', `description_lang_2` = 'Description for RND Product 35 (lng-2)', name_lang_3='RND Product 35 (lng-3)', brief_lang_3='Brief for RND Product 35 (lng-3)', `description_lang_3` = 'Description for RND Product 35 (lng-3)', number='RND.51.9738.35', ean='200RND.51.9738.357', weight='2001', price_calculation_method='1', full_price_excl_vat_custom='27.27', full_price_incl_vat_custom='32.724', sale_price_excl_vat_custom='27.27', sale_price_incl_vat_custom='32.724', sale_price_excl_vat_cached='27.27', full_price_excl_vat_cached='27.27', sale_price_incl_vat_cached='32.724', full_price_incl_vat_cached='32.724', id_delivery_unit='2', stock_quantity='8', extended_warranty='15', vat_percent='20', id_category='3', id_brand='2', image='products/5.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 0, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='36', id_feature='1', `value_text` = '1084', value_number='1084';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='36', id_feature='2', `value_text` = '1211', value_number='1211';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='36', id_feature='3', `value_text` = '277', value_number='277';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='36', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='36', id_feature='5', `value_text` = '760', value_number='760';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='36', id_feature='6', `value_text` = '620', value_number='620';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='36', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 36 (lng-1)', brief_lang_1='Brief for RND Product 36 (lng-1)', `description_lang_1` = 'Description for RND Product 36 (lng-1)', name_lang_2='RND Product 36 (lng-2)', brief_lang_2='Brief for RND Product 36 (lng-2)', `description_lang_2` = 'Description for RND Product 36 (lng-2)', name_lang_3='RND Product 36 (lng-3)', brief_lang_3='Brief for RND Product 36 (lng-3)', `description_lang_3` = 'Description for RND Product 36 (lng-3)', number='RND.25.3546.36', ean='200RND.25.3546.364', weight='1100', price_calculation_method='1', full_price_excl_vat_custom='48.95', full_price_incl_vat_custom='58.74', sale_price_excl_vat_custom='48.95', sale_price_incl_vat_custom='58.74', sale_price_excl_vat_cached='48.95', full_price_excl_vat_cached='48.95', sale_price_incl_vat_cached='58.74', full_price_incl_vat_cached='58.74', id_delivery_unit='7', stock_quantity='8.8', extended_warranty='1', vat_percent='20', id_category='2', id_brand='4', image='products/4.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='37', id_feature='1', `value_text` = '1166', value_number='1166';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='37', id_feature='2', `value_text` = '1240', value_number='1240';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='37', id_feature='3', `value_text` = '251', value_number='251';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='37', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='37', id_feature='5', `value_text` = '1070', value_number='1070';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='37', id_feature='6', `value_text` = '790', value_number='790';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='37', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 37 (lng-1)', brief_lang_1='Brief for RND Product 37 (lng-1)', `description_lang_1` = 'Description for RND Product 37 (lng-1)', name_lang_2='RND Product 37 (lng-2)', brief_lang_2='Brief for RND Product 37 (lng-2)', `description_lang_2` = 'Description for RND Product 37 (lng-2)', name_lang_3='RND Product 37 (lng-3)', brief_lang_3='Brief for RND Product 37 (lng-3)', `description_lang_3` = 'Description for RND Product 37 (lng-3)', number='RND.86.7529.37', ean='200RND.86.7529.373', weight='1758', price_calculation_method='1', full_price_excl_vat_custom='12.22', full_price_incl_vat_custom='14.664', sale_price_excl_vat_custom='12.22', sale_price_incl_vat_custom='14.664', sale_price_excl_vat_cached='12.22', full_price_excl_vat_cached='12.22', sale_price_incl_vat_cached='14.664', full_price_incl_vat_cached='14.664', id_delivery_unit='17', stock_quantity='4.7', extended_warranty='15', vat_percent='20', id_category='3', id_brand='7', image='products/2.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='38', id_feature='1', `value_text` = '1155', value_number='1155';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='38', id_feature='2', `value_text` = '1214', value_number='1214';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='38', id_feature='3', `value_text` = '290', value_number='290';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='38', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='38', id_feature='5', `value_text` = '1080', value_number='1080';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='38', id_feature='6', `value_text` = '740', value_number='740';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='38', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 38 (lng-1)', brief_lang_1='Brief for RND Product 38 (lng-1)', `description_lang_1` = 'Description for RND Product 38 (lng-1)', name_lang_2='RND Product 38 (lng-2)', brief_lang_2='Brief for RND Product 38 (lng-2)', `description_lang_2` = 'Description for RND Product 38 (lng-2)', name_lang_3='RND Product 38 (lng-3)', brief_lang_3='Brief for RND Product 38 (lng-3)', `description_lang_3` = 'Description for RND Product 38 (lng-3)', number='RND.59.9678.38', ean='200RND.59.9678.383', weight='1285', price_calculation_method='1', full_price_excl_vat_custom='25.48', full_price_incl_vat_custom='30.576', sale_price_excl_vat_custom='25.48', sale_price_incl_vat_custom='30.576', sale_price_excl_vat_cached='25.48', full_price_excl_vat_cached='25.48', sale_price_incl_vat_cached='30.576', full_price_incl_vat_cached='30.576', id_delivery_unit='6', stock_quantity='6', extended_warranty='19', vat_percent='20', id_category='1', id_brand='5', image='products/2.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='39', id_feature='1', `value_text` = '1054', value_number='1054';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='39', id_feature='2', `value_text` = '1206', value_number='1206';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='39', id_feature='3', `value_text` = '266', value_number='266';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='39', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='39', id_feature='5', `value_text` = '1160', value_number='1160';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='39', id_feature='6', `value_text` = '940', value_number='940';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='39', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 39 (lng-1)', brief_lang_1='Brief for RND Product 39 (lng-1)', `description_lang_1` = 'Description for RND Product 39 (lng-1)', name_lang_2='RND Product 39 (lng-2)', brief_lang_2='Brief for RND Product 39 (lng-2)', `description_lang_2` = 'Description for RND Product 39 (lng-2)', name_lang_3='RND Product 39 (lng-3)', brief_lang_3='Brief for RND Product 39 (lng-3)', `description_lang_3` = 'Description for RND Product 39 (lng-3)', number='RND.80.1449.39', ean='200RND.80.1449.398', weight='2498', price_calculation_method='1', full_price_excl_vat_custom='40.75', full_price_incl_vat_custom='48.9', sale_price_excl_vat_custom='40.75', sale_price_incl_vat_custom='48.9', sale_price_excl_vat_cached='40.75', full_price_excl_vat_cached='40.75', sale_price_incl_vat_cached='48.9', full_price_incl_vat_cached='48.9', id_delivery_unit='4', stock_quantity='5.7', extended_warranty='10', vat_percent='20', id_category='2', id_brand='6', image='products/6.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 0, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='40', id_feature='1', `value_text` = '1113', value_number='1113';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='40', id_feature='2', `value_text` = '1219', value_number='1219';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='40', id_feature='3', `value_text` = '254', value_number='254';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='40', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='40', id_feature='5', `value_text` = '790', value_number='790';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='40', id_feature='6', `value_text` = '680', value_number='680';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='40', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 40 (lng-1)', brief_lang_1='Brief for RND Product 40 (lng-1)', `description_lang_1` = 'Description for RND Product 40 (lng-1)', name_lang_2='RND Product 40 (lng-2)', brief_lang_2='Brief for RND Product 40 (lng-2)', `description_lang_2` = 'Description for RND Product 40 (lng-2)', name_lang_3='RND Product 40 (lng-3)', brief_lang_3='Brief for RND Product 40 (lng-3)', `description_lang_3` = 'Description for RND Product 40 (lng-3)', number='RND.35.9866.40', ean='200RND.35.9866.403', weight='822', price_calculation_method='1', full_price_excl_vat_custom='46.16', full_price_incl_vat_custom='55.392', sale_price_excl_vat_custom='46.16', sale_price_incl_vat_custom='55.392', sale_price_excl_vat_cached='46.16', full_price_excl_vat_cached='46.16', sale_price_incl_vat_cached='55.392', full_price_incl_vat_cached='55.392', id_delivery_unit='3', stock_quantity='4.1', extended_warranty='3', vat_percent='20', id_category='7', id_brand='2', image='products/4.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='41', id_feature='1', `value_text` = '1155', value_number='1155';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='41', id_feature='2', `value_text` = '1223', value_number='1223';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='41', id_feature='3', `value_text` = '290', value_number='290';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='41', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='41', id_feature='5', `value_text` = '1040', value_number='1040';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='41', id_feature='6', `value_text` = '590', value_number='590';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='41', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 41 (lng-1)', brief_lang_1='Brief for RND Product 41 (lng-1)', `description_lang_1` = 'Description for RND Product 41 (lng-1)', name_lang_2='RND Product 41 (lng-2)', brief_lang_2='Brief for RND Product 41 (lng-2)', `description_lang_2` = 'Description for RND Product 41 (lng-2)', name_lang_3='RND Product 41 (lng-3)', brief_lang_3='Brief for RND Product 41 (lng-3)', `description_lang_3` = 'Description for RND Product 41 (lng-3)', number='RND.23.9716.41', ean='200RND.23.9716.413', weight='899', price_calculation_method='1', full_price_excl_vat_custom='28.1', full_price_incl_vat_custom='33.72', sale_price_excl_vat_custom='28.1', sale_price_incl_vat_custom='33.72', sale_price_excl_vat_cached='28.1', full_price_excl_vat_cached='28.1', sale_price_incl_vat_cached='33.72', full_price_incl_vat_cached='33.72', id_delivery_unit='14', stock_quantity='2.9', extended_warranty='25', vat_percent='20', id_category='7', id_brand='4', image='products/4.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 0, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='42', id_feature='1', `value_text` = '1065', value_number='1065';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='42', id_feature='2', `value_text` = '1217', value_number='1217';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='42', id_feature='3', `value_text` = '287', value_number='287';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='42', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='42', id_feature='5', `value_text` = '1190', value_number='1190';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='42', id_feature='6', `value_text` = '760', value_number='760';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='42', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 42 (lng-1)', brief_lang_1='Brief for RND Product 42 (lng-1)', `description_lang_1` = 'Description for RND Product 42 (lng-1)', name_lang_2='RND Product 42 (lng-2)', brief_lang_2='Brief for RND Product 42 (lng-2)', `description_lang_2` = 'Description for RND Product 42 (lng-2)', name_lang_3='RND Product 42 (lng-3)', brief_lang_3='Brief for RND Product 42 (lng-3)', `description_lang_3` = 'Description for RND Product 42 (lng-3)', number='RND.27.9906.42', ean='200RND.27.9906.429', weight='979', price_calculation_method='1', full_price_excl_vat_custom='21.85', full_price_incl_vat_custom='26.22', sale_price_excl_vat_custom='17.48', sale_price_incl_vat_custom='20.976', sale_price_excl_vat_cached='17.48', full_price_excl_vat_cached='21.85', sale_price_incl_vat_cached='20.976', full_price_incl_vat_cached='26.22', id_delivery_unit='14', stock_quantity='3.9', extended_warranty='12', vat_percent='20', id_category='4', id_brand='7', image='products/2.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='43', id_feature='1', `value_text` = '1068', value_number='1068';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='43', id_feature='2', `value_text` = '1201', value_number='1201';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='43', id_feature='3', `value_text` = '258', value_number='258';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='43', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='43', id_feature='5', `value_text` = '1150', value_number='1150';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='43', id_feature='6', `value_text` = '530', value_number='530';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='43', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 43 (lng-1)', brief_lang_1='Brief for RND Product 43 (lng-1)', `description_lang_1` = 'Description for RND Product 43 (lng-1)', name_lang_2='RND Product 43 (lng-2)', brief_lang_2='Brief for RND Product 43 (lng-2)', `description_lang_2` = 'Description for RND Product 43 (lng-2)', name_lang_3='RND Product 43 (lng-3)', brief_lang_3='Brief for RND Product 43 (lng-3)', `description_lang_3` = 'Description for RND Product 43 (lng-3)', number='RND.52.7545.43', ean='200RND.52.7545.437', weight='1317', price_calculation_method='1', full_price_excl_vat_custom='45.96', full_price_incl_vat_custom='55.152', sale_price_excl_vat_custom='45.96', sale_price_incl_vat_custom='55.152', sale_price_excl_vat_cached='45.96', full_price_excl_vat_cached='45.96', sale_price_incl_vat_cached='55.152', full_price_incl_vat_cached='55.152', id_delivery_unit='13', stock_quantity='1.5', extended_warranty='11', vat_percent='20', id_category='6', id_brand='5', image='products/1.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='44', id_feature='1', `value_text` = '1035', value_number='1035';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='44', id_feature='2', `value_text` = '1240', value_number='1240';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='44', id_feature='3', `value_text` = '256', value_number='256';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='44', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='44', id_feature='5', `value_text` = '1160', value_number='1160';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='44', id_feature='6', `value_text` = '540', value_number='540';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='44', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 44 (lng-1)', brief_lang_1='Brief for RND Product 44 (lng-1)', `description_lang_1` = 'Description for RND Product 44 (lng-1)', name_lang_2='RND Product 44 (lng-2)', brief_lang_2='Brief for RND Product 44 (lng-2)', `description_lang_2` = 'Description for RND Product 44 (lng-2)', name_lang_3='RND Product 44 (lng-3)', brief_lang_3='Brief for RND Product 44 (lng-3)', `description_lang_3` = 'Description for RND Product 44 (lng-3)', number='RND.29.7221.44', ean='200RND.29.7221.449', weight='1904', price_calculation_method='1', full_price_excl_vat_custom='49.66', full_price_incl_vat_custom='59.592', sale_price_excl_vat_custom='49.66', sale_price_incl_vat_custom='59.592', sale_price_excl_vat_cached='49.66', full_price_excl_vat_cached='49.66', sale_price_incl_vat_cached='59.592', full_price_incl_vat_cached='59.592', id_delivery_unit='7', stock_quantity='0.9', extended_warranty='18', vat_percent='20', id_category='1', id_brand='7', image='products/4.jpg', is_on_sale = 0, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='45', id_feature='1', `value_text` = '1034', value_number='1034';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='45', id_feature='2', `value_text` = '1224', value_number='1224';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='45', id_feature='3', `value_text` = '272', value_number='272';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='45', id_feature='4', `value_text` = '1', value_number='1';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='45', id_feature='5', `value_text` = '850', value_number='850';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='45', id_feature='6', `value_text` = '840', value_number='840';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='45', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 45 (lng-1)', brief_lang_1='Brief for RND Product 45 (lng-1)', `description_lang_1` = 'Description for RND Product 45 (lng-1)', name_lang_2='RND Product 45 (lng-2)', brief_lang_2='Brief for RND Product 45 (lng-2)', `description_lang_2` = 'Description for RND Product 45 (lng-2)', name_lang_3='RND Product 45 (lng-3)', brief_lang_3='Brief for RND Product 45 (lng-3)', `description_lang_3` = 'Description for RND Product 45 (lng-3)', number='RND.24.2290.45', ean='200RND.24.2290.456', weight='2374', price_calculation_method='1', full_price_excl_vat_custom='15.04', full_price_incl_vat_custom='18.048', sale_price_excl_vat_custom='15.04', sale_price_incl_vat_custom='18.048', sale_price_excl_vat_cached='15.04', full_price_excl_vat_cached='15.04', sale_price_incl_vat_cached='18.048', full_price_incl_vat_cached='18.048', id_delivery_unit='17', stock_quantity='9', extended_warranty='4', vat_percent='20', id_category='2', id_brand='1', image='products/6.jpg', is_on_sale = 1, is_sale_out = 1, is_new = 1, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='46', id_feature='1', `value_text` = '1160', value_number='1160';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='46', id_feature='2', `value_text` = '1243', value_number='1243';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='46', id_feature='3', `value_text` = '280', value_number='280';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='46', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='46', id_feature='5', `value_text` = '910', value_number='910';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='46', id_feature='6', `value_text` = '770', value_number='770';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='46', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 46 (lng-1)', brief_lang_1='Brief for RND Product 46 (lng-1)', `description_lang_1` = 'Description for RND Product 46 (lng-1)', name_lang_2='RND Product 46 (lng-2)', brief_lang_2='Brief for RND Product 46 (lng-2)', `description_lang_2` = 'Description for RND Product 46 (lng-2)', name_lang_3='RND Product 46 (lng-3)', brief_lang_3='Brief for RND Product 46 (lng-3)', `description_lang_3` = 'Description for RND Product 46 (lng-3)', number='RND.82.9623.46', ean='200RND.82.9623.466', weight='1230', price_calculation_method='1', full_price_excl_vat_custom='6.96', full_price_incl_vat_custom='8.352', sale_price_excl_vat_custom='6.96', sale_price_incl_vat_custom='8.352', sale_price_excl_vat_cached='6.96', full_price_excl_vat_cached='6.96', sale_price_incl_vat_cached='8.352', full_price_incl_vat_cached='8.352', id_delivery_unit='12', stock_quantity='6.3', extended_warranty='22', vat_percent='20', id_category='1', id_brand='3', image='products/4.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 0, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='47', id_feature='1', `value_text` = '1160', value_number='1160';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='47', id_feature='2', `value_text` = '1229', value_number='1229';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='47', id_feature='3', `value_text` = '269', value_number='269';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='47', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='47', id_feature='5', `value_text` = '790', value_number='790';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='47', id_feature='6', `value_text` = '900', value_number='900';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='47', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 47 (lng-1)', brief_lang_1='Brief for RND Product 47 (lng-1)', `description_lang_1` = 'Description for RND Product 47 (lng-1)', name_lang_2='RND Product 47 (lng-2)', brief_lang_2='Brief for RND Product 47 (lng-2)', `description_lang_2` = 'Description for RND Product 47 (lng-2)', name_lang_3='RND Product 47 (lng-3)', brief_lang_3='Brief for RND Product 47 (lng-3)', `description_lang_3` = 'Description for RND Product 47 (lng-3)', number='RND.96.1055.47', ean='200RND.96.1055.479', weight='1516', price_calculation_method='1', full_price_excl_vat_custom='10.22', full_price_incl_vat_custom='12.264', sale_price_excl_vat_custom='10.22', sale_price_incl_vat_custom='12.264', sale_price_excl_vat_cached='10.22', full_price_excl_vat_cached='10.22', sale_price_incl_vat_cached='12.264', full_price_incl_vat_cached='12.264', id_delivery_unit='7', stock_quantity='0.3', extended_warranty='19', vat_percent='20', id_category='6', id_brand='7', image='products/4.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 0, is_recommended = 1, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='48', id_feature='1', `value_text` = '1108', value_number='1108';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='48', id_feature='2', `value_text` = '1212', value_number='1212';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='48', id_feature='3', `value_text` = '282', value_number='282';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='48', id_feature='4', `value_text` = '2', value_number='2';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='48', id_feature='5', `value_text` = '1120', value_number='1120';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='48', id_feature='6', `value_text` = '570', value_number='570';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='48', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 48 (lng-1)', brief_lang_1='Brief for RND Product 48 (lng-1)', `description_lang_1` = 'Description for RND Product 48 (lng-1)', name_lang_2='RND Product 48 (lng-2)', brief_lang_2='Brief for RND Product 48 (lng-2)', `description_lang_2` = 'Description for RND Product 48 (lng-2)', name_lang_3='RND Product 48 (lng-3)', brief_lang_3='Brief for RND Product 48 (lng-3)', `description_lang_3` = 'Description for RND Product 48 (lng-3)', number='RND.59.7734.48', ean='200RND.59.7734.483', weight='1367', price_calculation_method='1', full_price_excl_vat_custom='15.28', full_price_incl_vat_custom='18.336', sale_price_excl_vat_custom='15.28', sale_price_incl_vat_custom='18.336', sale_price_excl_vat_cached='15.28', full_price_excl_vat_cached='15.28', sale_price_incl_vat_cached='18.336', full_price_incl_vat_cached='18.336', id_delivery_unit='7', stock_quantity='0.4', extended_warranty='23', vat_percent='20', id_category='3', id_brand='3', image='products/7.jpg', is_on_sale = 1, is_sale_out = 0, is_new = 1, is_recommended = 0, is_top = 0;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='49', id_feature='1', `value_text` = '1168', value_number='1168';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='49', id_feature='2', `value_text` = '1208', value_number='1208';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='49', id_feature='3', `value_text` = '287', value_number='287';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='49', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='49', id_feature='5', `value_text` = '820', value_number='820';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='49', id_feature='6', `value_text` = '640', value_number='640';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='49', id_feature='7', `value_text` = '155 R13', value_number=null;;
insert into `srkt_products` set `id`=null, name_lang_1='RND Product 49 (lng-1)', brief_lang_1='Brief for RND Product 49 (lng-1)', `description_lang_1` = 'Description for RND Product 49 (lng-1)', name_lang_2='RND Product 49 (lng-2)', brief_lang_2='Brief for RND Product 49 (lng-2)', `description_lang_2` = 'Description for RND Product 49 (lng-2)', name_lang_3='RND Product 49 (lng-3)', brief_lang_3='Brief for RND Product 49 (lng-3)', `description_lang_3` = 'Description for RND Product 49 (lng-3)', number='RND.57.1166.49', ean='200RND.57.1166.499', weight='676', price_calculation_method='1', full_price_excl_vat_custom='22.55', full_price_incl_vat_custom='27.06', sale_price_excl_vat_custom='22.55', sale_price_incl_vat_custom='27.06', sale_price_excl_vat_cached='22.55', full_price_excl_vat_cached='22.55', sale_price_incl_vat_cached='27.06', full_price_incl_vat_cached='27.06', id_delivery_unit='10', stock_quantity='3.3', extended_warranty='5', vat_percent='20', id_category='2', id_brand='2', image='products/2.jpg', is_on_sale = 0, is_sale_out = 1, is_new = 1, is_recommended = 1, is_top = 1;;
insert into `srkt_products_features_assignment` set `id`=null, id_product='50', id_feature='1', `value_text` = '1067', value_number='1067';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='50', id_feature='2', `value_text` = '1221', value_number='1221';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='50', id_feature='3', `value_text` = '296', value_number='296';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='50', id_feature='4', `value_text` = '3', value_number='3';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='50', id_feature='5', `value_text` = '1120', value_number='1120';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='50', id_feature='6', `value_text` = '890', value_number='890';;
insert into `srkt_products_features_assignment` set `id`=null, id_product='50', id_feature='7', `value_text` = '155 R13', value_number=null;;
commit;;
start transaction;;
insert into `srkt_products_gallery` set `id`=null, id_product='1', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='1', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='1', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='1', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='1', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='1', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='1', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='1', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='2', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='2', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='2', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='2', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='2', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='2', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='2', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='2', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='3', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='3', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='3', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='3', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='3', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='3', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='3', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='3', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='4', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='4', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='4', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='4', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='4', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='4', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='4', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='4', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='5', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='5', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='5', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='5', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='5', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='5', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='5', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='5', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='6', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='6', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='6', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='6', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='6', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='6', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='6', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='6', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='7', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='7', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='7', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='7', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='7', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='7', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='7', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='7', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='8', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='8', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='8', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='8', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='8', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='8', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='8', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='8', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='9', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='9', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='9', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='9', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='9', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='9', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='9', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='9', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='10', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='10', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='10', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='10', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='10', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='10', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='10', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='10', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='11', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='11', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='11', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='11', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='11', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='11', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='11', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='11', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='12', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='12', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='12', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='12', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='12', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='12', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='12', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='12', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='13', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='13', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='13', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='13', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='13', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='13', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='13', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='13', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='14', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='14', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='14', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='14', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='14', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='14', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='14', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='14', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='15', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='15', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='15', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='15', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='15', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='15', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='15', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='15', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='16', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='16', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='16', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='16', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='16', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='16', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='16', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='16', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='17', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='17', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='17', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='17', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='17', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='17', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='17', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='17', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='18', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='18', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='18', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='18', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='18', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='18', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='18', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='18', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='19', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='19', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='19', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='19', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='19', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='19', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='19', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='19', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='20', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='20', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='20', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='20', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='20', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='20', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='20', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='20', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='21', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='21', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='21', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='21', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='21', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='21', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='21', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='21', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='22', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='22', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='22', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='22', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='22', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='22', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='22', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='22', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='23', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='23', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='23', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='23', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='23', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='23', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='23', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='23', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='24', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='24', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='24', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='24', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='24', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='24', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='24', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='24', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='25', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='25', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='25', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='25', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='25', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='25', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='25', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='25', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='26', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='26', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='26', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='26', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='26', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='26', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='26', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='26', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='27', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='27', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='27', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='27', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='27', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='27', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='27', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='27', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='28', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='28', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='28', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='28', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='28', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='28', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='28', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='28', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='29', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='29', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='29', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='29', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='29', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='29', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='29', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='29', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='30', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='30', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='30', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='30', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='30', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='30', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='30', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='30', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='31', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='31', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='31', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='31', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='31', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='31', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='31', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='31', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='32', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='32', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='32', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='32', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='32', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='32', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='32', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='32', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='33', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='33', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='33', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='33', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='33', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='33', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='33', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='33', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='34', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='34', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='34', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='34', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='34', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='34', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='34', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='34', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='35', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='35', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='35', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='35', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='35', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='35', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='35', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='35', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='36', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='36', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='36', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='36', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='36', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='36', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='36', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='36', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='37', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='37', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='37', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='37', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='37', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='37', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='37', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='37', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='38', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='38', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='38', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='38', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='38', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='38', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='38', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='38', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='39', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='39', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='39', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='39', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='39', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='39', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='39', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='39', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='40', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='40', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='40', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='40', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='40', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='40', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='40', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='40', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='41', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='41', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='41', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='41', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='41', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='41', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='41', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='41', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='42', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='42', image='products/product_3.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='42', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='42', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='42', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='42', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='42', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='42', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='43', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='43', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='43', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='43', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='43', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='43', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='43', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='43', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='44', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='44', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='44', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='44', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='44', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='44', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='44', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='44', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='45', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='45', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='45', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='45', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='45', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='45', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='45', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='45', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='46', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='46', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='46', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='46', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='46', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='46', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='46', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='46', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='47', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='47', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='47', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='47', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='47', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='47', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='47', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='47', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='48', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='48', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='48', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='48', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='48', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='48', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='48', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='48', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='49', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='49', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='49', image='products/product_4.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='49', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='49', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='49', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='49', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='49', image='products/product_8.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='50', image='products/product_2.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='50', image='products/product_10.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='50', image='products/product_1.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='50', image='products/product_6.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='50', image='products/product_7.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='50', image='products/product_9.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='50', image='products/product_5.jpg';;
insert into `srkt_products_gallery` set `id`=null, id_product='50', image='products/product_6.jpg';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='1', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='1', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='2', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='2', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='3', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='3', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='4', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='4', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='5', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='5', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='6', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='6', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='7', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='7', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='8', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='8', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='9', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='9', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='10', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='10', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='11', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='11', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='12', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='12', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='13', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='13', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='14', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='14', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='15', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='15', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='16', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='16', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='17', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='17', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='18', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='18', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='19', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='19', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='20', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='20', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='21', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='21', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='22', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='22', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='23', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='23', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='24', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='24', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='25', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='25', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='26', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='26', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='27', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='27', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='28', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='28', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='29', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='29', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='30', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='30', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='31', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='31', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='32', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='32', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='33', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='33', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='34', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='34', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='35', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='35', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='36', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='36', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='37', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='37', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='38', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='38', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='39', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='39', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='40', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='40', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='41', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='41', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='42', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='42', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='43', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='43', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='44', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='44', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='45', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='45', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='46', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='46', id_service='2';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='47', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='47', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='48', id_service=null;;
insert into `srkt_products_services_assignment` set `id`=null, id_product='48', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='49', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='49', id_service='3';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='50', id_service='1';;
insert into `srkt_products_services_assignment` set `id`=null, id_product='50', id_service='3';;
commit;;
start transaction;;
insert into `srkt_products_related` set `id`=null, id_product='1', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='1', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='1', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='1', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='1', id_related='13';;
insert into `srkt_products_related` set `id`=null, id_product='1', id_related='32';;
insert into `srkt_products_related` set `id`=null, id_product='1', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='1', id_related='28';;
insert into `srkt_products_related` set `id`=null, id_product='2', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='2', id_related='10';;
insert into `srkt_products_related` set `id`=null, id_product='2', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='2', id_related='28';;
insert into `srkt_products_related` set `id`=null, id_product='2', id_related='11';;
insert into `srkt_products_related` set `id`=null, id_product='2', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='2', id_related='4';;
insert into `srkt_products_related` set `id`=null, id_product='2', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='3', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='3', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='3', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='3', id_related='11';;
insert into `srkt_products_related` set `id`=null, id_product='3', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='3', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='3', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='3', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='4', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='4', id_related='37';;
insert into `srkt_products_related` set `id`=null, id_product='4', id_related='43';;
insert into `srkt_products_related` set `id`=null, id_product='4', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='4', id_related='46';;
insert into `srkt_products_related` set `id`=null, id_product='4', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='4', id_related='15';;
insert into `srkt_products_related` set `id`=null, id_product='4', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='5', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='5', id_related='33';;
insert into `srkt_products_related` set `id`=null, id_product='5', id_related='1';;
insert into `srkt_products_related` set `id`=null, id_product='5', id_related='18';;
insert into `srkt_products_related` set `id`=null, id_product='5', id_related='6';;
insert into `srkt_products_related` set `id`=null, id_product='5', id_related='37';;
insert into `srkt_products_related` set `id`=null, id_product='5', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='5', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='6', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='6', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='6', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='6', id_related='43';;
insert into `srkt_products_related` set `id`=null, id_product='6', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='6', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='6', id_related='37';;
insert into `srkt_products_related` set `id`=null, id_product='6', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='7', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='7', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='7', id_related='45';;
insert into `srkt_products_related` set `id`=null, id_product='7', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='7', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='7', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='7', id_related='32';;
insert into `srkt_products_related` set `id`=null, id_product='7', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='8', id_related='18';;
insert into `srkt_products_related` set `id`=null, id_product='8', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='8', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='8', id_related='23';;
insert into `srkt_products_related` set `id`=null, id_product='8', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='8', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='8', id_related='23';;
insert into `srkt_products_related` set `id`=null, id_product='8', id_related='2';;
insert into `srkt_products_related` set `id`=null, id_product='9', id_related='37';;
insert into `srkt_products_related` set `id`=null, id_product='9', id_related='43';;
insert into `srkt_products_related` set `id`=null, id_product='9', id_related='13';;
insert into `srkt_products_related` set `id`=null, id_product='9', id_related='3';;
insert into `srkt_products_related` set `id`=null, id_product='9', id_related='14';;
insert into `srkt_products_related` set `id`=null, id_product='9', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='9', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='9', id_related='39';;
insert into `srkt_products_related` set `id`=null, id_product='10', id_related='50';;
insert into `srkt_products_related` set `id`=null, id_product='10', id_related='3';;
insert into `srkt_products_related` set `id`=null, id_product='10', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='10', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='10', id_related='24';;
insert into `srkt_products_related` set `id`=null, id_product='10', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='10', id_related='4';;
insert into `srkt_products_related` set `id`=null, id_product='10', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='11', id_related='28';;
insert into `srkt_products_related` set `id`=null, id_product='11', id_related='24';;
insert into `srkt_products_related` set `id`=null, id_product='11', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='11', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='11', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='11', id_related='27';;
insert into `srkt_products_related` set `id`=null, id_product='11', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='11', id_related='12';;
insert into `srkt_products_related` set `id`=null, id_product='12', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='12', id_related='27';;
insert into `srkt_products_related` set `id`=null, id_product='12', id_related='6';;
insert into `srkt_products_related` set `id`=null, id_product='12', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='12', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='12', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='12', id_related='3';;
insert into `srkt_products_related` set `id`=null, id_product='12', id_related='46';;
insert into `srkt_products_related` set `id`=null, id_product='13', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='13', id_related='4';;
insert into `srkt_products_related` set `id`=null, id_product='13', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='13', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='13', id_related='44';;
insert into `srkt_products_related` set `id`=null, id_product='13', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='13', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='13', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='14', id_related='45';;
insert into `srkt_products_related` set `id`=null, id_product='14', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='14', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='14', id_related='27';;
insert into `srkt_products_related` set `id`=null, id_product='14', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='14', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='14', id_related='1';;
insert into `srkt_products_related` set `id`=null, id_product='14', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='15', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='15', id_related='39';;
insert into `srkt_products_related` set `id`=null, id_product='15', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='15', id_related='37';;
insert into `srkt_products_related` set `id`=null, id_product='15', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='15', id_related='40';;
insert into `srkt_products_related` set `id`=null, id_product='15', id_related='45';;
insert into `srkt_products_related` set `id`=null, id_product='15', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='16', id_related='2';;
insert into `srkt_products_related` set `id`=null, id_product='16', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='16', id_related='1';;
insert into `srkt_products_related` set `id`=null, id_product='16', id_related='27';;
insert into `srkt_products_related` set `id`=null, id_product='16', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='16', id_related='45';;
insert into `srkt_products_related` set `id`=null, id_product='16', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='16', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='17', id_related='40';;
insert into `srkt_products_related` set `id`=null, id_product='17', id_related='37';;
insert into `srkt_products_related` set `id`=null, id_product='17', id_related='50';;
insert into `srkt_products_related` set `id`=null, id_product='17', id_related='12';;
insert into `srkt_products_related` set `id`=null, id_product='17', id_related='15';;
insert into `srkt_products_related` set `id`=null, id_product='17', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='17', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='17', id_related='43';;
insert into `srkt_products_related` set `id`=null, id_product='18', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='18', id_related='13';;
insert into `srkt_products_related` set `id`=null, id_product='18', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='18', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='18', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='18', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='18', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='18', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='19', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='19', id_related='10';;
insert into `srkt_products_related` set `id`=null, id_product='19', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='19', id_related='31';;
insert into `srkt_products_related` set `id`=null, id_product='19', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='19', id_related='14';;
insert into `srkt_products_related` set `id`=null, id_product='19', id_related='40';;
insert into `srkt_products_related` set `id`=null, id_product='19', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='20', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='20', id_related='10';;
insert into `srkt_products_related` set `id`=null, id_product='20', id_related='50';;
insert into `srkt_products_related` set `id`=null, id_product='20', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='20', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='20', id_related='18';;
insert into `srkt_products_related` set `id`=null, id_product='20', id_related='46';;
insert into `srkt_products_related` set `id`=null, id_product='20', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='21', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='21', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='21', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='21', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='21', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='21', id_related='45';;
insert into `srkt_products_related` set `id`=null, id_product='21', id_related='39';;
insert into `srkt_products_related` set `id`=null, id_product='21', id_related='46';;
insert into `srkt_products_related` set `id`=null, id_product='22', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='22', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='22', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='22', id_related='50';;
insert into `srkt_products_related` set `id`=null, id_product='22', id_related='24';;
insert into `srkt_products_related` set `id`=null, id_product='22', id_related='34';;
insert into `srkt_products_related` set `id`=null, id_product='22', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='22', id_related='23';;
insert into `srkt_products_related` set `id`=null, id_product='23', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='23', id_related='43';;
insert into `srkt_products_related` set `id`=null, id_product='23', id_related='31';;
insert into `srkt_products_related` set `id`=null, id_product='23', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='23', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='23', id_related='46';;
insert into `srkt_products_related` set `id`=null, id_product='23', id_related='21';;
insert into `srkt_products_related` set `id`=null, id_product='23', id_related='6';;
insert into `srkt_products_related` set `id`=null, id_product='24', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='24', id_related='32';;
insert into `srkt_products_related` set `id`=null, id_product='24', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='24', id_related='4';;
insert into `srkt_products_related` set `id`=null, id_product='24', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='24', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='24', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='24', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='25', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='25', id_related='34';;
insert into `srkt_products_related` set `id`=null, id_product='25', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='25', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='25', id_related='40';;
insert into `srkt_products_related` set `id`=null, id_product='25', id_related='30';;
insert into `srkt_products_related` set `id`=null, id_product='25', id_related='15';;
insert into `srkt_products_related` set `id`=null, id_product='25', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='26', id_related='15';;
insert into `srkt_products_related` set `id`=null, id_product='26', id_related='34';;
insert into `srkt_products_related` set `id`=null, id_product='26', id_related='4';;
insert into `srkt_products_related` set `id`=null, id_product='26', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='26', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='26', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='26', id_related='27';;
insert into `srkt_products_related` set `id`=null, id_product='26', id_related='1';;
insert into `srkt_products_related` set `id`=null, id_product='27', id_related='46';;
insert into `srkt_products_related` set `id`=null, id_product='27', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='27', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='27', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='27', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='27', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='27', id_related='24';;
insert into `srkt_products_related` set `id`=null, id_product='27', id_related='11';;
insert into `srkt_products_related` set `id`=null, id_product='28', id_related='27';;
insert into `srkt_products_related` set `id`=null, id_product='28', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='28', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='28', id_related='44';;
insert into `srkt_products_related` set `id`=null, id_product='28', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='28', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='28', id_related='32';;
insert into `srkt_products_related` set `id`=null, id_product='28', id_related='14';;
insert into `srkt_products_related` set `id`=null, id_product='29', id_related='33';;
insert into `srkt_products_related` set `id`=null, id_product='29', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='29', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='29', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='29', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='29', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='29', id_related='4';;
insert into `srkt_products_related` set `id`=null, id_product='29', id_related='22';;
insert into `srkt_products_related` set `id`=null, id_product='30', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='30', id_related='43';;
insert into `srkt_products_related` set `id`=null, id_product='30', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='30', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='30', id_related='22';;
insert into `srkt_products_related` set `id`=null, id_product='30', id_related='33';;
insert into `srkt_products_related` set `id`=null, id_product='30', id_related='14';;
insert into `srkt_products_related` set `id`=null, id_product='30', id_related='28';;
insert into `srkt_products_related` set `id`=null, id_product='31', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='31', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='31', id_related='12';;
insert into `srkt_products_related` set `id`=null, id_product='31', id_related='33';;
insert into `srkt_products_related` set `id`=null, id_product='31', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='31', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='31', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='31', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='32', id_related='12';;
insert into `srkt_products_related` set `id`=null, id_product='32', id_related='11';;
insert into `srkt_products_related` set `id`=null, id_product='32', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='32', id_related='46';;
insert into `srkt_products_related` set `id`=null, id_product='32', id_related='1';;
insert into `srkt_products_related` set `id`=null, id_product='32', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='32', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='32', id_related='40';;
insert into `srkt_products_related` set `id`=null, id_product='33', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='33', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='33', id_related='3';;
insert into `srkt_products_related` set `id`=null, id_product='33', id_related='39';;
insert into `srkt_products_related` set `id`=null, id_product='33', id_related='24';;
insert into `srkt_products_related` set `id`=null, id_product='33', id_related='28';;
insert into `srkt_products_related` set `id`=null, id_product='33', id_related='43';;
insert into `srkt_products_related` set `id`=null, id_product='33', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='34', id_related='15';;
insert into `srkt_products_related` set `id`=null, id_product='34', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='34', id_related='44';;
insert into `srkt_products_related` set `id`=null, id_product='34', id_related='39';;
insert into `srkt_products_related` set `id`=null, id_product='34', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='34', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='34', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='34', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='35', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='35', id_related='13';;
insert into `srkt_products_related` set `id`=null, id_product='35', id_related='12';;
insert into `srkt_products_related` set `id`=null, id_product='35', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='35', id_related='10';;
insert into `srkt_products_related` set `id`=null, id_product='35', id_related='40';;
insert into `srkt_products_related` set `id`=null, id_product='35', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='35', id_related='6';;
insert into `srkt_products_related` set `id`=null, id_product='36', id_related='32';;
insert into `srkt_products_related` set `id`=null, id_product='36', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='36', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='36', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='36', id_related='23';;
insert into `srkt_products_related` set `id`=null, id_product='36', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='36', id_related='13';;
insert into `srkt_products_related` set `id`=null, id_product='36', id_related='44';;
insert into `srkt_products_related` set `id`=null, id_product='37', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='37', id_related='2';;
insert into `srkt_products_related` set `id`=null, id_product='37', id_related='6';;
insert into `srkt_products_related` set `id`=null, id_product='37', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='37', id_related='23';;
insert into `srkt_products_related` set `id`=null, id_product='37', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='37', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='37', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='38', id_related='35';;
insert into `srkt_products_related` set `id`=null, id_product='38', id_related='2';;
insert into `srkt_products_related` set `id`=null, id_product='38', id_related='32';;
insert into `srkt_products_related` set `id`=null, id_product='38', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='38', id_related='21';;
insert into `srkt_products_related` set `id`=null, id_product='38', id_related='48';;
insert into `srkt_products_related` set `id`=null, id_product='38', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='38', id_related='11';;
insert into `srkt_products_related` set `id`=null, id_product='39', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='39', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='39', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='39', id_related='33';;
insert into `srkt_products_related` set `id`=null, id_product='39', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='39', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='39', id_related='15';;
insert into `srkt_products_related` set `id`=null, id_product='39', id_related='27';;
insert into `srkt_products_related` set `id`=null, id_product='40', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='40', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='40', id_related='21';;
insert into `srkt_products_related` set `id`=null, id_product='40', id_related='16';;
insert into `srkt_products_related` set `id`=null, id_product='40', id_related='25';;
insert into `srkt_products_related` set `id`=null, id_product='40', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='40', id_related='43';;
insert into `srkt_products_related` set `id`=null, id_product='40', id_related='22';;
insert into `srkt_products_related` set `id`=null, id_product='41', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='41', id_related='1';;
insert into `srkt_products_related` set `id`=null, id_product='41', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='41', id_related='3';;
insert into `srkt_products_related` set `id`=null, id_product='41', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='41', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='41', id_related='33';;
insert into `srkt_products_related` set `id`=null, id_product='41', id_related='8';;
insert into `srkt_products_related` set `id`=null, id_product='42', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='42', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='42', id_related='49';;
insert into `srkt_products_related` set `id`=null, id_product='42', id_related='22';;
insert into `srkt_products_related` set `id`=null, id_product='42', id_related='33';;
insert into `srkt_products_related` set `id`=null, id_product='42', id_related='31';;
insert into `srkt_products_related` set `id`=null, id_product='42', id_related='39';;
insert into `srkt_products_related` set `id`=null, id_product='42', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='43', id_related='1';;
insert into `srkt_products_related` set `id`=null, id_product='43', id_related='28';;
insert into `srkt_products_related` set `id`=null, id_product='43', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='43', id_related='40';;
insert into `srkt_products_related` set `id`=null, id_product='43', id_related='15';;
insert into `srkt_products_related` set `id`=null, id_product='43', id_related='34';;
insert into `srkt_products_related` set `id`=null, id_product='43', id_related='28';;
insert into `srkt_products_related` set `id`=null, id_product='43', id_related='45';;
insert into `srkt_products_related` set `id`=null, id_product='44', id_related='31';;
insert into `srkt_products_related` set `id`=null, id_product='44', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='44', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='44', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='44', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='44', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='44', id_related='5';;
insert into `srkt_products_related` set `id`=null, id_product='44', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='45', id_related='40';;
insert into `srkt_products_related` set `id`=null, id_product='45', id_related='27';;
insert into `srkt_products_related` set `id`=null, id_product='45', id_related='39';;
insert into `srkt_products_related` set `id`=null, id_product='45', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='45', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='45', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='45', id_related='34';;
insert into `srkt_products_related` set `id`=null, id_product='45', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='46', id_related='26';;
insert into `srkt_products_related` set `id`=null, id_product='46', id_related='4';;
insert into `srkt_products_related` set `id`=null, id_product='46', id_related='9';;
insert into `srkt_products_related` set `id`=null, id_product='46', id_related='7';;
insert into `srkt_products_related` set `id`=null, id_product='46', id_related='14';;
insert into `srkt_products_related` set `id`=null, id_product='46', id_related='22';;
insert into `srkt_products_related` set `id`=null, id_product='46', id_related='29';;
insert into `srkt_products_related` set `id`=null, id_product='46', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='47', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='47', id_related='20';;
insert into `srkt_products_related` set `id`=null, id_product='47', id_related='34';;
insert into `srkt_products_related` set `id`=null, id_product='47', id_related='17';;
insert into `srkt_products_related` set `id`=null, id_product='47', id_related='44';;
insert into `srkt_products_related` set `id`=null, id_product='47', id_related='11';;
insert into `srkt_products_related` set `id`=null, id_product='47', id_related='2';;
insert into `srkt_products_related` set `id`=null, id_product='47', id_related='50';;
insert into `srkt_products_related` set `id`=null, id_product='48', id_related='3';;
insert into `srkt_products_related` set `id`=null, id_product='48', id_related='21';;
insert into `srkt_products_related` set `id`=null, id_product='48', id_related='11';;
insert into `srkt_products_related` set `id`=null, id_product='48', id_related='11';;
insert into `srkt_products_related` set `id`=null, id_product='48', id_related='28';;
insert into `srkt_products_related` set `id`=null, id_product='48', id_related='18';;
insert into `srkt_products_related` set `id`=null, id_product='48', id_related='50';;
insert into `srkt_products_related` set `id`=null, id_product='48', id_related='44';;
insert into `srkt_products_related` set `id`=null, id_product='49', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='49', id_related='47';;
insert into `srkt_products_related` set `id`=null, id_product='49', id_related='38';;
insert into `srkt_products_related` set `id`=null, id_product='49', id_related='10';;
insert into `srkt_products_related` set `id`=null, id_product='49', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='49', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='49', id_related='21';;
insert into `srkt_products_related` set `id`=null, id_product='49', id_related='31';;
insert into `srkt_products_related` set `id`=null, id_product='50', id_related='42';;
insert into `srkt_products_related` set `id`=null, id_product='50', id_related='41';;
insert into `srkt_products_related` set `id`=null, id_product='50', id_related='19';;
insert into `srkt_products_related` set `id`=null, id_product='50', id_related='21';;
insert into `srkt_products_related` set `id`=null, id_product='50', id_related='18';;
insert into `srkt_products_related` set `id`=null, id_product='50', id_related='13';;
insert into `srkt_products_related` set `id`=null, id_product='50', id_related='36';;
insert into `srkt_products_related` set `id`=null, id_product='50', id_related='9';;
commit;;
start transaction;;
insert into `srkt_products_accessories` set `id`=null, id_product='1', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='1', id_accessory='33';;
insert into `srkt_products_accessories` set `id`=null, id_product='1', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='1', id_accessory='24';;
insert into `srkt_products_accessories` set `id`=null, id_product='1', id_accessory='8';;
insert into `srkt_products_accessories` set `id`=null, id_product='1', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='1', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='1', id_accessory='39';;
insert into `srkt_products_accessories` set `id`=null, id_product='2', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='2', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='2', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='2', id_accessory='35';;
insert into `srkt_products_accessories` set `id`=null, id_product='2', id_accessory='35';;
insert into `srkt_products_accessories` set `id`=null, id_product='2', id_accessory='8';;
insert into `srkt_products_accessories` set `id`=null, id_product='2', id_accessory='20';;
insert into `srkt_products_accessories` set `id`=null, id_product='2', id_accessory='36';;
insert into `srkt_products_accessories` set `id`=null, id_product='3', id_accessory='42';;
insert into `srkt_products_accessories` set `id`=null, id_product='3', id_accessory='34';;
insert into `srkt_products_accessories` set `id`=null, id_product='3', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='3', id_accessory='14';;
insert into `srkt_products_accessories` set `id`=null, id_product='3', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='3', id_accessory='32';;
insert into `srkt_products_accessories` set `id`=null, id_product='3', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='3', id_accessory='14';;
insert into `srkt_products_accessories` set `id`=null, id_product='4', id_accessory='20';;
insert into `srkt_products_accessories` set `id`=null, id_product='4', id_accessory='9';;
insert into `srkt_products_accessories` set `id`=null, id_product='4', id_accessory='5';;
insert into `srkt_products_accessories` set `id`=null, id_product='4', id_accessory='19';;
insert into `srkt_products_accessories` set `id`=null, id_product='4', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='4', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='4', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='4', id_accessory='38';;
insert into `srkt_products_accessories` set `id`=null, id_product='5', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='5', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='5', id_accessory='34';;
insert into `srkt_products_accessories` set `id`=null, id_product='5', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='5', id_accessory='1';;
insert into `srkt_products_accessories` set `id`=null, id_product='5', id_accessory='29';;
insert into `srkt_products_accessories` set `id`=null, id_product='5', id_accessory='9';;
insert into `srkt_products_accessories` set `id`=null, id_product='5', id_accessory='11';;
insert into `srkt_products_accessories` set `id`=null, id_product='6', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='6', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='6', id_accessory='31';;
insert into `srkt_products_accessories` set `id`=null, id_product='6', id_accessory='34';;
insert into `srkt_products_accessories` set `id`=null, id_product='6', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='6', id_accessory='5';;
insert into `srkt_products_accessories` set `id`=null, id_product='6', id_accessory='46';;
insert into `srkt_products_accessories` set `id`=null, id_product='6', id_accessory='32';;
insert into `srkt_products_accessories` set `id`=null, id_product='7', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='7', id_accessory='49';;
insert into `srkt_products_accessories` set `id`=null, id_product='7', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='7', id_accessory='32';;
insert into `srkt_products_accessories` set `id`=null, id_product='7', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='7', id_accessory='27';;
insert into `srkt_products_accessories` set `id`=null, id_product='7', id_accessory='38';;
insert into `srkt_products_accessories` set `id`=null, id_product='7', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='8', id_accessory='18';;
insert into `srkt_products_accessories` set `id`=null, id_product='8', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='8', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='8', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='8', id_accessory='49';;
insert into `srkt_products_accessories` set `id`=null, id_product='8', id_accessory='1';;
insert into `srkt_products_accessories` set `id`=null, id_product='8', id_accessory='2';;
insert into `srkt_products_accessories` set `id`=null, id_product='8', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='9', id_accessory='39';;
insert into `srkt_products_accessories` set `id`=null, id_product='9', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='9', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='9', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='9', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='9', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='9', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='9', id_accessory='18';;
insert into `srkt_products_accessories` set `id`=null, id_product='10', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='10', id_accessory='31';;
insert into `srkt_products_accessories` set `id`=null, id_product='10', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='10', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='10', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='10', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='10', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='10', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='11', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='11', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='11', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='11', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='11', id_accessory='31';;
insert into `srkt_products_accessories` set `id`=null, id_product='11', id_accessory='23';;
insert into `srkt_products_accessories` set `id`=null, id_product='11', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='11', id_accessory='18';;
insert into `srkt_products_accessories` set `id`=null, id_product='12', id_accessory='8';;
insert into `srkt_products_accessories` set `id`=null, id_product='12', id_accessory='27';;
insert into `srkt_products_accessories` set `id`=null, id_product='12', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='12', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='12', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='12', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='12', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='12', id_accessory='22';;
insert into `srkt_products_accessories` set `id`=null, id_product='13', id_accessory='32';;
insert into `srkt_products_accessories` set `id`=null, id_product='13', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='13', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='13', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='13', id_accessory='38';;
insert into `srkt_products_accessories` set `id`=null, id_product='13', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='13', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='13', id_accessory='14';;
insert into `srkt_products_accessories` set `id`=null, id_product='14', id_accessory='23';;
insert into `srkt_products_accessories` set `id`=null, id_product='14', id_accessory='22';;
insert into `srkt_products_accessories` set `id`=null, id_product='14', id_accessory='40';;
insert into `srkt_products_accessories` set `id`=null, id_product='14', id_accessory='31';;
insert into `srkt_products_accessories` set `id`=null, id_product='14', id_accessory='40';;
insert into `srkt_products_accessories` set `id`=null, id_product='14', id_accessory='19';;
insert into `srkt_products_accessories` set `id`=null, id_product='14', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='14', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='15', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='15', id_accessory='36';;
insert into `srkt_products_accessories` set `id`=null, id_product='15', id_accessory='36';;
insert into `srkt_products_accessories` set `id`=null, id_product='15', id_accessory='2';;
insert into `srkt_products_accessories` set `id`=null, id_product='15', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='15', id_accessory='29';;
insert into `srkt_products_accessories` set `id`=null, id_product='15', id_accessory='48';;
insert into `srkt_products_accessories` set `id`=null, id_product='15', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='16', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='16', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='16', id_accessory='33';;
insert into `srkt_products_accessories` set `id`=null, id_product='16', id_accessory='31';;
insert into `srkt_products_accessories` set `id`=null, id_product='16', id_accessory='20';;
insert into `srkt_products_accessories` set `id`=null, id_product='16', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='16', id_accessory='1';;
insert into `srkt_products_accessories` set `id`=null, id_product='16', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='17', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='17', id_accessory='11';;
insert into `srkt_products_accessories` set `id`=null, id_product='17', id_accessory='26';;
insert into `srkt_products_accessories` set `id`=null, id_product='17', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='17', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='17', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='17', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='17', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='18', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='18', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='18', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='18', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='18', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='18', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='18', id_accessory='17';;
insert into `srkt_products_accessories` set `id`=null, id_product='18', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='19', id_accessory='24';;
insert into `srkt_products_accessories` set `id`=null, id_product='19', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='19', id_accessory='35';;
insert into `srkt_products_accessories` set `id`=null, id_product='19', id_accessory='12';;
insert into `srkt_products_accessories` set `id`=null, id_product='19', id_accessory='17';;
insert into `srkt_products_accessories` set `id`=null, id_product='19', id_accessory='2';;
insert into `srkt_products_accessories` set `id`=null, id_product='19', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='19', id_accessory='48';;
insert into `srkt_products_accessories` set `id`=null, id_product='20', id_accessory='41';;
insert into `srkt_products_accessories` set `id`=null, id_product='20', id_accessory='46';;
insert into `srkt_products_accessories` set `id`=null, id_product='20', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='20', id_accessory='33';;
insert into `srkt_products_accessories` set `id`=null, id_product='20', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='20', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='20', id_accessory='49';;
insert into `srkt_products_accessories` set `id`=null, id_product='20', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='21', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='21', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='21', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='21', id_accessory='12';;
insert into `srkt_products_accessories` set `id`=null, id_product='21', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='21', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='21', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='21', id_accessory='46';;
insert into `srkt_products_accessories` set `id`=null, id_product='22', id_accessory='32';;
insert into `srkt_products_accessories` set `id`=null, id_product='22', id_accessory='27';;
insert into `srkt_products_accessories` set `id`=null, id_product='22', id_accessory='33';;
insert into `srkt_products_accessories` set `id`=null, id_product='22', id_accessory='17';;
insert into `srkt_products_accessories` set `id`=null, id_product='22', id_accessory='5';;
insert into `srkt_products_accessories` set `id`=null, id_product='22', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='22', id_accessory='16';;
insert into `srkt_products_accessories` set `id`=null, id_product='22', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='23', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='23', id_accessory='36';;
insert into `srkt_products_accessories` set `id`=null, id_product='23', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='23', id_accessory='22';;
insert into `srkt_products_accessories` set `id`=null, id_product='23', id_accessory='16';;
insert into `srkt_products_accessories` set `id`=null, id_product='23', id_accessory='14';;
insert into `srkt_products_accessories` set `id`=null, id_product='23', id_accessory='32';;
insert into `srkt_products_accessories` set `id`=null, id_product='23', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='24', id_accessory='1';;
insert into `srkt_products_accessories` set `id`=null, id_product='24', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='24', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='24', id_accessory='11';;
insert into `srkt_products_accessories` set `id`=null, id_product='24', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='24', id_accessory='41';;
insert into `srkt_products_accessories` set `id`=null, id_product='24', id_accessory='9';;
insert into `srkt_products_accessories` set `id`=null, id_product='24', id_accessory='11';;
insert into `srkt_products_accessories` set `id`=null, id_product='25', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='25', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='25', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='25', id_accessory='27';;
insert into `srkt_products_accessories` set `id`=null, id_product='25', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='25', id_accessory='23';;
insert into `srkt_products_accessories` set `id`=null, id_product='25', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='25', id_accessory='34';;
insert into `srkt_products_accessories` set `id`=null, id_product='26', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='26', id_accessory='5';;
insert into `srkt_products_accessories` set `id`=null, id_product='26', id_accessory='12';;
insert into `srkt_products_accessories` set `id`=null, id_product='26', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='26', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='26', id_accessory='14';;
insert into `srkt_products_accessories` set `id`=null, id_product='26', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='26', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='27', id_accessory='9';;
insert into `srkt_products_accessories` set `id`=null, id_product='27', id_accessory='17';;
insert into `srkt_products_accessories` set `id`=null, id_product='27', id_accessory='14';;
insert into `srkt_products_accessories` set `id`=null, id_product='27', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='27', id_accessory='9';;
insert into `srkt_products_accessories` set `id`=null, id_product='27', id_accessory='34';;
insert into `srkt_products_accessories` set `id`=null, id_product='27', id_accessory='40';;
insert into `srkt_products_accessories` set `id`=null, id_product='27', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='28', id_accessory='5';;
insert into `srkt_products_accessories` set `id`=null, id_product='28', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='28', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='28', id_accessory='41';;
insert into `srkt_products_accessories` set `id`=null, id_product='28', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='28', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='28', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='28', id_accessory='1';;
insert into `srkt_products_accessories` set `id`=null, id_product='29', id_accessory='22';;
insert into `srkt_products_accessories` set `id`=null, id_product='29', id_accessory='32';;
insert into `srkt_products_accessories` set `id`=null, id_product='29', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='29', id_accessory='35';;
insert into `srkt_products_accessories` set `id`=null, id_product='29', id_accessory='20';;
insert into `srkt_products_accessories` set `id`=null, id_product='29', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='29', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='29', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='30', id_accessory='20';;
insert into `srkt_products_accessories` set `id`=null, id_product='30', id_accessory='36';;
insert into `srkt_products_accessories` set `id`=null, id_product='30', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='30', id_accessory='41';;
insert into `srkt_products_accessories` set `id`=null, id_product='30', id_accessory='27';;
insert into `srkt_products_accessories` set `id`=null, id_product='30', id_accessory='24';;
insert into `srkt_products_accessories` set `id`=null, id_product='30', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='30', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='31', id_accessory='26';;
insert into `srkt_products_accessories` set `id`=null, id_product='31', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='31', id_accessory='42';;
insert into `srkt_products_accessories` set `id`=null, id_product='31', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='31', id_accessory='38';;
insert into `srkt_products_accessories` set `id`=null, id_product='31', id_accessory='33';;
insert into `srkt_products_accessories` set `id`=null, id_product='31', id_accessory='2';;
insert into `srkt_products_accessories` set `id`=null, id_product='31', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='32', id_accessory='38';;
insert into `srkt_products_accessories` set `id`=null, id_product='32', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='32', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='32', id_accessory='2';;
insert into `srkt_products_accessories` set `id`=null, id_product='32', id_accessory='27';;
insert into `srkt_products_accessories` set `id`=null, id_product='32', id_accessory='24';;
insert into `srkt_products_accessories` set `id`=null, id_product='32', id_accessory='9';;
insert into `srkt_products_accessories` set `id`=null, id_product='32', id_accessory='41';;
insert into `srkt_products_accessories` set `id`=null, id_product='33', id_accessory='39';;
insert into `srkt_products_accessories` set `id`=null, id_product='33', id_accessory='20';;
insert into `srkt_products_accessories` set `id`=null, id_product='33', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='33', id_accessory='14';;
insert into `srkt_products_accessories` set `id`=null, id_product='33', id_accessory='26';;
insert into `srkt_products_accessories` set `id`=null, id_product='33', id_accessory='35';;
insert into `srkt_products_accessories` set `id`=null, id_product='33', id_accessory='34';;
insert into `srkt_products_accessories` set `id`=null, id_product='33', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='34', id_accessory='1';;
insert into `srkt_products_accessories` set `id`=null, id_product='34', id_accessory='48';;
insert into `srkt_products_accessories` set `id`=null, id_product='34', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='34', id_accessory='5';;
insert into `srkt_products_accessories` set `id`=null, id_product='34', id_accessory='29';;
insert into `srkt_products_accessories` set `id`=null, id_product='34', id_accessory='42';;
insert into `srkt_products_accessories` set `id`=null, id_product='34', id_accessory='43';;
insert into `srkt_products_accessories` set `id`=null, id_product='34', id_accessory='2';;
insert into `srkt_products_accessories` set `id`=null, id_product='35', id_accessory='48';;
insert into `srkt_products_accessories` set `id`=null, id_product='35', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='35', id_accessory='38';;
insert into `srkt_products_accessories` set `id`=null, id_product='35', id_accessory='12';;
insert into `srkt_products_accessories` set `id`=null, id_product='35', id_accessory='31';;
insert into `srkt_products_accessories` set `id`=null, id_product='35', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='35', id_accessory='38';;
insert into `srkt_products_accessories` set `id`=null, id_product='35', id_accessory='37';;
insert into `srkt_products_accessories` set `id`=null, id_product='36', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='36', id_accessory='20';;
insert into `srkt_products_accessories` set `id`=null, id_product='36', id_accessory='42';;
insert into `srkt_products_accessories` set `id`=null, id_product='36', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='36', id_accessory='18';;
insert into `srkt_products_accessories` set `id`=null, id_product='36', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='36', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='36', id_accessory='23';;
insert into `srkt_products_accessories` set `id`=null, id_product='37', id_accessory='31';;
insert into `srkt_products_accessories` set `id`=null, id_product='37', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='37', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='37', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='37', id_accessory='20';;
insert into `srkt_products_accessories` set `id`=null, id_product='37', id_accessory='34';;
insert into `srkt_products_accessories` set `id`=null, id_product='37', id_accessory='48';;
insert into `srkt_products_accessories` set `id`=null, id_product='37', id_accessory='1';;
insert into `srkt_products_accessories` set `id`=null, id_product='38', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='38', id_accessory='17';;
insert into `srkt_products_accessories` set `id`=null, id_product='38', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='38', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='38', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='38', id_accessory='2';;
insert into `srkt_products_accessories` set `id`=null, id_product='38', id_accessory='49';;
insert into `srkt_products_accessories` set `id`=null, id_product='38', id_accessory='43';;
insert into `srkt_products_accessories` set `id`=null, id_product='39', id_accessory='16';;
insert into `srkt_products_accessories` set `id`=null, id_product='39', id_accessory='49';;
insert into `srkt_products_accessories` set `id`=null, id_product='39', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='39', id_accessory='26';;
insert into `srkt_products_accessories` set `id`=null, id_product='39', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='39', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='39', id_accessory='24';;
insert into `srkt_products_accessories` set `id`=null, id_product='39', id_accessory='36';;
insert into `srkt_products_accessories` set `id`=null, id_product='40', id_accessory='36';;
insert into `srkt_products_accessories` set `id`=null, id_product='40', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='40', id_accessory='23';;
insert into `srkt_products_accessories` set `id`=null, id_product='40', id_accessory='12';;
insert into `srkt_products_accessories` set `id`=null, id_product='40', id_accessory='46';;
insert into `srkt_products_accessories` set `id`=null, id_product='40', id_accessory='13';;
insert into `srkt_products_accessories` set `id`=null, id_product='40', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='40', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='41', id_accessory='14';;
insert into `srkt_products_accessories` set `id`=null, id_product='41', id_accessory='19';;
insert into `srkt_products_accessories` set `id`=null, id_product='41', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='41', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='41', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='41', id_accessory='24';;
insert into `srkt_products_accessories` set `id`=null, id_product='41', id_accessory='38';;
insert into `srkt_products_accessories` set `id`=null, id_product='41', id_accessory='2';;
insert into `srkt_products_accessories` set `id`=null, id_product='42', id_accessory='12';;
insert into `srkt_products_accessories` set `id`=null, id_product='42', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='42', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='42', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='42', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='42', id_accessory='31';;
insert into `srkt_products_accessories` set `id`=null, id_product='42', id_accessory='49';;
insert into `srkt_products_accessories` set `id`=null, id_product='42', id_accessory='5';;
insert into `srkt_products_accessories` set `id`=null, id_product='43', id_accessory='29';;
insert into `srkt_products_accessories` set `id`=null, id_product='43', id_accessory='22';;
insert into `srkt_products_accessories` set `id`=null, id_product='43', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='43', id_accessory='45';;
insert into `srkt_products_accessories` set `id`=null, id_product='43', id_accessory='40';;
insert into `srkt_products_accessories` set `id`=null, id_product='43', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='43', id_accessory='49';;
insert into `srkt_products_accessories` set `id`=null, id_product='43', id_accessory='10';;
insert into `srkt_products_accessories` set `id`=null, id_product='44', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='44', id_accessory='22';;
insert into `srkt_products_accessories` set `id`=null, id_product='44', id_accessory='19';;
insert into `srkt_products_accessories` set `id`=null, id_product='44', id_accessory='46';;
insert into `srkt_products_accessories` set `id`=null, id_product='44', id_accessory='40';;
insert into `srkt_products_accessories` set `id`=null, id_product='44', id_accessory='22';;
insert into `srkt_products_accessories` set `id`=null, id_product='44', id_accessory='16';;
insert into `srkt_products_accessories` set `id`=null, id_product='44', id_accessory='8';;
insert into `srkt_products_accessories` set `id`=null, id_product='45', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='45', id_accessory='39';;
insert into `srkt_products_accessories` set `id`=null, id_product='45', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='45', id_accessory='12';;
insert into `srkt_products_accessories` set `id`=null, id_product='45', id_accessory='29';;
insert into `srkt_products_accessories` set `id`=null, id_product='45', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='45', id_accessory='34';;
insert into `srkt_products_accessories` set `id`=null, id_product='45', id_accessory='23';;
insert into `srkt_products_accessories` set `id`=null, id_product='46', id_accessory='24';;
insert into `srkt_products_accessories` set `id`=null, id_product='46', id_accessory='5';;
insert into `srkt_products_accessories` set `id`=null, id_product='46', id_accessory='35';;
insert into `srkt_products_accessories` set `id`=null, id_product='46', id_accessory='12';;
insert into `srkt_products_accessories` set `id`=null, id_product='46', id_accessory='9';;
insert into `srkt_products_accessories` set `id`=null, id_product='46', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='46', id_accessory='19';;
insert into `srkt_products_accessories` set `id`=null, id_product='46', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='47', id_accessory='43';;
insert into `srkt_products_accessories` set `id`=null, id_product='47', id_accessory='15';;
insert into `srkt_products_accessories` set `id`=null, id_product='47', id_accessory='1';;
insert into `srkt_products_accessories` set `id`=null, id_product='47', id_accessory='44';;
insert into `srkt_products_accessories` set `id`=null, id_product='47', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='47', id_accessory='11';;
insert into `srkt_products_accessories` set `id`=null, id_product='47', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='47', id_accessory='19';;
insert into `srkt_products_accessories` set `id`=null, id_product='48', id_accessory='50';;
insert into `srkt_products_accessories` set `id`=null, id_product='48', id_accessory='4';;
insert into `srkt_products_accessories` set `id`=null, id_product='48', id_accessory='25';;
insert into `srkt_products_accessories` set `id`=null, id_product='48', id_accessory='11';;
insert into `srkt_products_accessories` set `id`=null, id_product='48', id_accessory='6';;
insert into `srkt_products_accessories` set `id`=null, id_product='48', id_accessory='7';;
insert into `srkt_products_accessories` set `id`=null, id_product='48', id_accessory='27';;
insert into `srkt_products_accessories` set `id`=null, id_product='48', id_accessory='41';;
insert into `srkt_products_accessories` set `id`=null, id_product='49', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='49', id_accessory='21';;
insert into `srkt_products_accessories` set `id`=null, id_product='49', id_accessory='30';;
insert into `srkt_products_accessories` set `id`=null, id_product='49', id_accessory='40';;
insert into `srkt_products_accessories` set `id`=null, id_product='49', id_accessory='3';;
insert into `srkt_products_accessories` set `id`=null, id_product='49', id_accessory='11';;
insert into `srkt_products_accessories` set `id`=null, id_product='49', id_accessory='46';;
insert into `srkt_products_accessories` set `id`=null, id_product='49', id_accessory='41';;
insert into `srkt_products_accessories` set `id`=null, id_product='50', id_accessory='47';;
insert into `srkt_products_accessories` set `id`=null, id_product='50', id_accessory='28';;
insert into `srkt_products_accessories` set `id`=null, id_product='50', id_accessory='33';;
insert into `srkt_products_accessories` set `id`=null, id_product='50', id_accessory='18';;
insert into `srkt_products_accessories` set `id`=null, id_product='50', id_accessory='41';;
insert into `srkt_products_accessories` set `id`=null, id_product='50', id_accessory='24';;
insert into `srkt_products_accessories` set `id`=null, id_product='50', id_accessory='36';;
insert into `srkt_products_accessories` set `id`=null, id_product='50', id_accessory='21';;
start transaction;;
insert into `srkt_product_prices` set `id`=null, id_product='1', purchase_price='111', recommended_price='24.5';;
insert into `srkt_product_prices` set `id`=null, id_product='2', purchase_price='46.5', recommended_price='330.5';;
insert into `srkt_product_prices` set `id`=null, id_product='3', purchase_price='282.5', recommended_price='267';;
insert into `srkt_product_prices` set `id`=null, id_product='4', purchase_price='410', recommended_price='433';;
insert into `srkt_product_prices` set `id`=null, id_product='5', purchase_price='349.5', recommended_price='291.5';;
insert into `srkt_product_prices` set `id`=null, id_product='6', purchase_price='249', recommended_price='159';;
insert into `srkt_product_prices` set `id`=null, id_product='7', purchase_price='348.5', recommended_price='56';;
insert into `srkt_product_prices` set `id`=null, id_product='8', purchase_price='102.5', recommended_price='208';;
insert into `srkt_product_prices` set `id`=null, id_product='9', purchase_price='456', recommended_price='288';;
insert into `srkt_product_prices` set `id`=null, id_product='10', purchase_price='293.5', recommended_price='79';;
insert into `srkt_product_prices` set `id`=null, id_product='11', purchase_price='375.5', recommended_price='195.5';;
insert into `srkt_product_prices` set `id`=null, id_product='12', purchase_price='212', recommended_price='140';;
insert into `srkt_product_prices` set `id`=null, id_product='13', purchase_price='217.5', recommended_price='40';;
insert into `srkt_product_prices` set `id`=null, id_product='14', purchase_price='120', recommended_price='412';;
insert into `srkt_product_prices` set `id`=null, id_product='15', purchase_price='230.5', recommended_price='436.5';;
insert into `srkt_product_prices` set `id`=null, id_product='16', purchase_price='452.5', recommended_price='73.5';;
insert into `srkt_product_prices` set `id`=null, id_product='17', purchase_price='309', recommended_price='282.5';;
insert into `srkt_product_prices` set `id`=null, id_product='18', purchase_price='143.5', recommended_price='161';;
insert into `srkt_product_prices` set `id`=null, id_product='19', purchase_price='441.5', recommended_price='57';;
insert into `srkt_product_prices` set `id`=null, id_product='20', purchase_price='472.5', recommended_price='77';;
insert into `srkt_product_prices` set `id`=null, id_product='21', purchase_price='151.5', recommended_price='44.5';;
insert into `srkt_product_prices` set `id`=null, id_product='22', purchase_price='334.5', recommended_price='237';;
insert into `srkt_product_prices` set `id`=null, id_product='23', purchase_price='173', recommended_price='498';;
insert into `srkt_product_prices` set `id`=null, id_product='24', purchase_price='459.5', recommended_price='310';;
insert into `srkt_product_prices` set `id`=null, id_product='25', purchase_price='67', recommended_price='473.5';;
insert into `srkt_product_prices` set `id`=null, id_product='26', purchase_price='137', recommended_price='495';;
insert into `srkt_product_prices` set `id`=null, id_product='27', purchase_price='401.5', recommended_price='179';;
insert into `srkt_product_prices` set `id`=null, id_product='28', purchase_price='108.5', recommended_price='465.5';;
insert into `srkt_product_prices` set `id`=null, id_product='29', purchase_price='163.5', recommended_price='500';;
insert into `srkt_product_prices` set `id`=null, id_product='30', purchase_price='159.5', recommended_price='179';;
insert into `srkt_product_prices` set `id`=null, id_product='31', purchase_price='48', recommended_price='449';;
insert into `srkt_product_prices` set `id`=null, id_product='32', purchase_price='163', recommended_price='138.5';;
insert into `srkt_product_prices` set `id`=null, id_product='33', purchase_price='298.5', recommended_price='433.5';;
insert into `srkt_product_prices` set `id`=null, id_product='34', purchase_price='442.5', recommended_price='336.5';;
insert into `srkt_product_prices` set `id`=null, id_product='35', purchase_price='432', recommended_price='285.5';;
insert into `srkt_product_prices` set `id`=null, id_product='36', purchase_price='317', recommended_price='383.5';;
insert into `srkt_product_prices` set `id`=null, id_product='37', purchase_price='193.5', recommended_price='196';;
insert into `srkt_product_prices` set `id`=null, id_product='38', purchase_price='421', recommended_price='168';;
insert into `srkt_product_prices` set `id`=null, id_product='39', purchase_price='474.5', recommended_price='209';;
insert into `srkt_product_prices` set `id`=null, id_product='40', purchase_price='340', recommended_price='445';;
insert into `srkt_product_prices` set `id`=null, id_product='41', purchase_price='251', recommended_price='206';;
insert into `srkt_product_prices` set `id`=null, id_product='42', purchase_price='102.5', recommended_price='388';;
insert into `srkt_product_prices` set `id`=null, id_product='43', purchase_price='388.5', recommended_price='26';;
insert into `srkt_product_prices` set `id`=null, id_product='44', purchase_price='381', recommended_price='484';;
insert into `srkt_product_prices` set `id`=null, id_product='45', purchase_price='422', recommended_price='254';;
insert into `srkt_product_prices` set `id`=null, id_product='46', purchase_price='90', recommended_price='257.5';;
insert into `srkt_product_prices` set `id`=null, id_product='47', purchase_price='137.5', recommended_price='332';;
insert into `srkt_product_prices` set `id`=null, id_product='48', purchase_price='204', recommended_price='68.5';;
insert into `srkt_product_prices` set `id`=null, id_product='49', purchase_price='194', recommended_price='200';;
insert into `srkt_product_prices` set `id`=null, id_product='50', purchase_price='179.5', recommended_price='119.5';;
commit;;
insert into `srkt_customers_categories` set `id`='1', code='G', name='Golden';;
insert into `srkt_customers_categories` set `id`='2', code='S', name='Silver';;
insert into `srkt_customers_categories` set `id`='3', code='B', name='Bronze';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.1@example.com', given_name='Assunta', family_name='1 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$ABuil/sSH0/4GUTcPfrOiuW8MXuba6ORxdUYb/Fz/mVCYLGMaykSy', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='1', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='1', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='1', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='1', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='1', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='1', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='1', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.1@example.com', given_name='Christine', family_name='1 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$KT4o1TvsO5spgJrFvJyw3.AP7zHaTYhLcCeFg91AMhIOdErG88aUO', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='2', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='2', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='2', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='2', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='2', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='2', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='2', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.1@example.com', given_name='Carol', family_name='1 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$KaLrklR5oQqHIkpLkZUiwuQeRNyZ3MEETVmB5wKQcK7C1XtpB0POu', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='3', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='3', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='3', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='3', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='3', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='3', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='3', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.1@example.com', given_name='Steven', family_name='1 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$/nAbSF/FVN4WxAmM9MWMrO0GU00EZmWsfHi5rOnJToZ5iQPRu/zkG', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='4', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='4', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='4', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='4', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='4', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='4', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='4', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.1@example.com', given_name='Miriam', family_name='1 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$jsEtIvbkR54X8nuTVcaipOOZdOc.XyqCJ6sW5vuA1GyKdlJ5CHfIe', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='5', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='5', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='5', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='5', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='5', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='5', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='5', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.2@example.com', given_name='Assunta', family_name='2 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$5CU58v62W0wr95pZlh5OTud18IHifXm1oSUnak749a5xAkkcGkdoi', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='6', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='6', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='6', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='6', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='6', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='6', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='6', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.2@example.com', given_name='Christine', family_name='2 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$EJkE4iZ/8yURHEz7z1G1zeT7PUYXjeHdyi5E1Za7gN.f/2fvWuWKq', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='7', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='7', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='7', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='7', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='7', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='7', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='7', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.2@example.com', given_name='Carol', family_name='2 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$0JfrabHo76OpSXgy2F9O7ufxs9kg.OXcjNoheTnUqHN02e1HF/UBK', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='8', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='8', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='8', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='8', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='8', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='8', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='8', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.2@example.com', given_name='Steven', family_name='2 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$wPjlo0M9YlVCiwK6DUz6z.BnE32xVOr/SkJin4i.B0LNvAWhvn76u', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='9', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='9', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='9', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='9', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='9', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='9', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='9', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.2@example.com', given_name='Miriam', family_name='2 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$GVhk8yrMaxrrNihRu3ws.OZ/YyH.EyZhPdS.yjDhCYx2a/dGpDSYG', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='10', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='10', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='10', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='10', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='10', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='10', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='10', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.3@example.com', given_name='Assunta', family_name='3 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$oirgij/3uO9ADoDrWF1lz.GFMd2VckP0WrlPm.LgGQU3Lqby2gU.S', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='11', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='11', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='11', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='11', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='11', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='11', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='11', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.3@example.com', given_name='Christine', family_name='3 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$kc8DpSn.FZ0XguSpHE.fgeOEaMuWWmpu3TrqJ.ALH.Vi2rN1l3sU2', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='12', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='12', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='12', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='12', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='12', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='12', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='12', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.3@example.com', given_name='Carol', family_name='3 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$PYus2bZzf4NrTRONiaaVPuIUFLyiLkqWXsnEPvTI3FfmWTm7u3dz2', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='13', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='13', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='13', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='13', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='13', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='13', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='13', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.3@example.com', given_name='Steven', family_name='3 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$P7jlzSC6DpVmOX/FhXSWpugkNeJf//Dzx.QaQTtPMHc7/sPEvzPHq', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='14', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='14', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='14', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='14', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='14', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='14', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='14', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.3@example.com', given_name='Miriam', family_name='3 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$1dHiOKVW72YC9Bt1NF4v9e/dsB3VJjBJsQwgLGYVIB9JJ3.072el.', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='15', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='15', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='15', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='15', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='15', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='15', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='15', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.4@example.com', given_name='Assunta', family_name='4 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$G9cIC/n6RuClLgY6Z.RypuG5RbotGE0CtR3iDuM.4UjIiieEvU8Rq', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='16', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='16', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='16', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='16', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='16', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='16', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='16', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.4@example.com', given_name='Christine', family_name='4 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$NSCb9wnM2tQ.g9FbJc.5fe6PCQIgTNvy8lV1pBqTWzLFay7KyMVli', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='17', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='17', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='17', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='17', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='17', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='17', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='17', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.4@example.com', given_name='Carol', family_name='4 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$VZ2gAdO9TufC.2I.RMGRcOkNuYrw4SFAFCKZljQq26w.lNYtAi3TK', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='18', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='18', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='18', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='18', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='18', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='18', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='18', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.4@example.com', given_name='Steven', family_name='4 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$VKlOwrX/nblPHSt/xI9FkuRbH6xcMpIT98pzrlIgEYDxeidAYke6S', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='19', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='19', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='19', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='19', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='19', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='19', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='19', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.4@example.com', given_name='Miriam', family_name='4 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$QUvM0THvm48x3ezBtmifH.GxF0eqnWG2zVHs/ly78GBW1OyevhHNC', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='20', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='20', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='20', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='20', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='20', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='20', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='20', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.5@example.com', given_name='Assunta', family_name='5 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$srDdciofDsbWYz5Fh0tkqOvDxbDXgwpcp/rcrMQ0hRUJ1AqbS3N4K', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='21', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='21', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='21', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='21', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='21', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='21', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='21', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.5@example.com', given_name='Christine', family_name='5 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$65n/ScBOzHye64RULfMj1eobXsvyCKRAgDTYrh9kTKgF.9h3JW2LW', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='22', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='22', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='22', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='22', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='22', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='22', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='22', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.5@example.com', given_name='Carol', family_name='5 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$NHSAfvq/bYgBLg5D.EitDuqzkP.lC.bzcUH8ncb2CFXVDQMlK9D..', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='23', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='23', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='23', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='23', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='23', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='23', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='23', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.5@example.com', given_name='Steven', family_name='5 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$sqjQtZUF.B6feiz1zBItnOlhw0U7G77x9oCTI57x1DgFWcBm4Bclu', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='24', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='24', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='24', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='24', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='24', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='24', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='24', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.5@example.com', given_name='Miriam', family_name='5 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$qfEA8mv7mdcd4n..3YvfwORDzSc.y1QkrCUVyYuUffLbMOwpvWYIm', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='25', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='25', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='25', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='25', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='25', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='25', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='25', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.6@example.com', given_name='Assunta', family_name='6 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$EFPJ7hCBNa/zMqEAhGwv6.D4W23vVTVM19Xcl/xLUusjjOSpLcDzi', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='26', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='26', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='26', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='26', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='26', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='26', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='26', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.6@example.com', given_name='Christine', family_name='6 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$MXwjxro7TjFBEBpeG6IgzuB2FIN0giWy5Cns7Hy4MbmkzaqZQeC62', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='27', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='27', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='27', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='27', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='27', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='27', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='27', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.6@example.com', given_name='Carol', family_name='6 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$Jr7UuevXp0Oe2k4CM.W7LuHFHykFW19loZWSqNQ/PrqjCumnMqYtu', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='28', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='28', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='28', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='28', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='28', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='28', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='28', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.6@example.com', given_name='Steven', family_name='6 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$N8x2ihgVTJSEnRiLxYU1I.5a4.7Ylp3sCyeuCccpNZm1hK..5l1ue', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='29', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='29', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='29', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='29', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='29', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='29', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='29', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.6@example.com', given_name='Miriam', family_name='6 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$w5ZsCLJwo5Hi.gRdkWRyyeJggmQWCJhfgwHP91liIMWwAeKtoICG6', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='30', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='30', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='30', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='30', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='30', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='30', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='30', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.7@example.com', given_name='Assunta', family_name='7 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$jTzUMpPFOk2M8sfCQuYAj.qNwQrW9cBjRkkLRo6ig3RSvo11WCiUy', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='31', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='31', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='31', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='31', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='31', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='31', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='31', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.7@example.com', given_name='Christine', family_name='7 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$/3YvzB7LY5xCKo.pvPUgnOXHvcTG3TuwhpDzwf/tosGHNKv5dkOZa', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='32', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='32', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='32', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='32', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='32', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='32', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='32', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.7@example.com', given_name='Carol', family_name='7 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$PGYdqazCGWbsQa2UGWchCekn1Fbg/HbStJ2R5WZo.kR.xzNCl909W', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='33', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='33', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='33', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='33', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='33', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='33', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='33', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.7@example.com', given_name='Steven', family_name='7 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$9jhXJUCQnhTKKN2j6xXyMeZT57Y1rSxn9pRqc1eK2.veLj9TMnzcO', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='34', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='34', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='34', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='34', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='34', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='34', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='34', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.7@example.com', given_name='Miriam', family_name='7 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$WZpwLEH3TLo97c.LumduueeQg0TJo9BMPGXoxav57S8jXL5CeXcq6', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='35', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='35', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='35', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='35', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='35', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='35', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='35', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.8@example.com', given_name='Assunta', family_name='8 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$./YjLCfbLW0URCrEfcv2B.UjomC8a/9KMMwTTv3mmhU/l1ouuk8I.', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='36', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='36', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='36', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='36', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='36', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='36', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='36', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.8@example.com', given_name='Christine', family_name='8 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$5uy420gsCQJVTGkWDSI8mu2G.BJ2wFtzLvnnMpXai2a7f7/KUA7KC', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='37', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='37', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='37', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='37', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='37', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='37', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='37', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.8@example.com', given_name='Carol', family_name='8 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$ctrvquk90pNIr2pMu61/ju.cxkrw2FyrmicPFnRFRaf50gUssvoCu', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='38', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='38', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='38', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='38', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='38', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='38', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='38', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.8@example.com', given_name='Steven', family_name='8 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$ZgKoAy7VzEiLFvKZEjkznuo4bdk7uvDJRLUMb7x/qTxFBvPcumk0a', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='39', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='39', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='39', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='39', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='39', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='39', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='39', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.8@example.com', given_name='Miriam', family_name='8 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$WsBx9dpONuWGiLBni3Xid.TxGHSrr5Yg1hntRTIwrvW2.FOHRqP6i', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='40', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='40', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='40', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='40', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='40', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='40', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='40', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.9@example.com', given_name='Assunta', family_name='9 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$85n1glvdRF83u0sbwr3t0.NZ2hrCdrvnGvaU.p7sJsW4n/91bn4jm', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='41', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='41', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='41', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='41', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='41', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='41', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='41', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.9@example.com', given_name='Christine', family_name='9 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$7S8ZBb2Vai5.0pnISiZ69O8ah/rxWbrQi2OOsSE/Roex4WBCxWL.S', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='42', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='42', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='42', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='42', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='42', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='42', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='42', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.9@example.com', given_name='Carol', family_name='9 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$kIlXy1tGiVeaw0FynpRb9u4OrgL81ksKOWLUhmdcY92XBx5aS1vdC', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='43', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='43', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='43', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='43', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='43', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='43', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='43', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.9@example.com', given_name='Steven', family_name='9 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$7fAKD87thmGQwqKe3/WNIerJ8tt26rjT5vbD8UgQVub4WObscopI6', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='44', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='44', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='44', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='44', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='44', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='44', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='44', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.9@example.com', given_name='Miriam', family_name='9 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$9dtBf9gOdqJJJNdZPZTH4.q9iBZoSPELM9nXWDyOXbmsIteVAGfIe', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='45', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='45', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='45', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='45', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='45', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='45', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='45', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='assunta.johnson.10@example.com', given_name='Assunta', family_name='10 Johnson', inv_given_name='Assunta', inv_family_name='Johnson', inv_street_1='3411 Yorkie Lane', inv_city='Blackshear', inv_zip='31516', inv_country='Georgia', `password` = '$2y$10$comkNc2NzgDqe7wjkfzZDuG73S47..LAmJA6wgWE89aacXDUkZSY6', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='46', del_given_name='Assunta', del_family_name='Johnson', del_street_1='3411 Yorkie Lane', del_city='Blackshear', del_zip='31516', del_country='Georgia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='46', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='46', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='46', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='46', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='46', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='46', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='christine.duffy.10@example.com', given_name='Christine', family_name='10 Duffy', inv_given_name='Christine', inv_family_name='Duffy', inv_street_1='728  Nelm Street', inv_city='Leesburg', inv_zip='20176', inv_country='Virginia', `password` = '$2y$10$Z6WqdzcPNePqG1DbBEEYsOIwdzrAU6BpPaTyInp/EWpljBVYWhqei', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='47', del_given_name='Christine', del_family_name='Duffy', del_street_1='728  Nelm Street', del_city='Leesburg', del_zip='20176', del_country='Virginia', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='47', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='47', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='47', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='47', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='47', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='47', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='carol.quinn.10@example.com', given_name='Carol', family_name='10 Quinn', inv_given_name='Carol', inv_family_name='Quinn', inv_street_1='2967  Stratford Drive', inv_city='Waipahu', inv_zip='96797', inv_country='Hawaii', `password` = '$2y$10$huOJLaN2GPZIfwy4vPVjduRc6oxvzAcRlIpMkBcnbKfro0WgfIH6e', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='48', del_given_name='Carol', del_family_name='Quinn', del_street_1='2967  Stratford Drive', del_city='Waipahu', del_zip='96797', del_country='Hawaii', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='48', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='48', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='48', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='48', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='48', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='48', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='steven.white.10@example.com', given_name='Steven', family_name='10 White', inv_given_name='Steven', inv_family_name='White', inv_street_1='3174  Boggess Street', inv_city='Hillsboro', inv_zip='45133', inv_country='Ohio', `password` = '$2y$10$M4SqkwnsIqK/5Eim/WenZ.YHYucikz5WahrUjpKM9v17LH7B3AaH6', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='49', del_given_name='Steven', del_family_name='White', del_street_1='3174  Boggess Street', del_city='Hillsboro', del_zip='45133', del_country='Ohio', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='49', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='49', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='49', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='49', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='49', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='49', id_product='2';;
insert into `srkt_customers` set `id`=null, id_category='1', email='miriam.evans.10@example.com', given_name='Miriam', family_name='10 Evans', inv_given_name='Miriam', inv_family_name='Evans', inv_street_1='2313  Horner Street', inv_city='Montgomery', inv_zip='36107', inv_country='Alabama', `password` = '$2y$10$2UECAHrutDpE3M/ZPrdnjOEeo1q41mvRetqE.hqnG/ne.0PBujMzi', is_validated = 1;;
insert into `srkt_customers_addresses` set `id`=null, id_customer='50', del_given_name='Miriam', del_family_name='Evans', del_street_1='2313  Horner Street', del_city='Montgomery', del_zip='36107', del_country='Alabama', phone_number='+1 123 456 789', email='example@email.com';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='50', id_product='1';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='50', id_product='2';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='50', id_product='3';;
insert into `srkt_customers_wishlist` set `id`=null, id_customer='50', id_product='4';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='50', id_product='1';;
insert into `srkt_customers_watchdog` set `id`=null, id_customer='50', id_product='2';;
insert into `srkt_invoice_numeric_series` set `id`='1', name='Regular invoices', pattern='YYMMDDNNNN';;
insert into `srkt_invoice_numeric_series` set `id`='2', name='Advance invoices', pattern='YYMMDDNNNN';;
insert into `srkt_orders_tags` set `id`=null, tag='good client', color='#11009A';;
insert into `srkt_orders_tags` set `id`=null, tag='bad client', color='#DFDFDF';;
insert into `srkt_orders_tags` set `id`=null, tag='discount on services', color='#141414';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 31
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 31
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='1';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 27
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 27
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='1', id_product='27', quantity='1', unit_price='20.5200', added_on='2021-11-23 13:22:35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 7
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 7
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='1', id_product='7', quantity='9', unit_price='20.5100', added_on='2021-11-23 13:22:35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 8
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 8
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='1', id_product='8', quantity='5', unit_price='11.1900', added_on='2021-11-23 13:22:35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 7
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 7
;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 31
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 31
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-09-16 13:22:35')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-09-16 13:22:35')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210916', lpad(@serial_number, 4, '0'))
      ), id_customer='31', id_customer_uid='1', del_given_name='Assunta', del_family_name='Johnson', del_company_name='', del_street_1='3411 Yorkie Lane', del_street_2='', del_floor='', del_city='Blackshear', del_zip='31516', del_country='Georgia', inv_given_name='Assunta', inv_family_name='Johnson', inv_company_name='', inv_street_1='3411 Yorkie Lane', inv_street_2='', inv_city='Blackshear', inv_zip='31516', inv_region='', inv_country='Georgia', confirmation_time='2021-09-16 13:22:35', id_delivery_service='3', id_payment_service='1', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='1', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='1', id_product='27', quantity='1', id_delivery_unit='20', unit_price='20.5200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='1', id_product='7', quantity='17', id_delivery_unit='6', unit_price='20.5100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='1', id_product='8', quantity='5', id_delivery_unit='21', unit_price='11.1900', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 1
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 1
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 31
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='4.25', payment_fee='0' where id=1;;
update srkt_orders set price_total_excl_vat='425.14', price_total_incl_vat='510.14', weight_total='39619' where id=1;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 1
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 1
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 31
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-09-16 13:22:35')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-09-16 13:22:35')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210916', lpad(@serial_number, 4, '0'))
      ), id_customer='31', id_order='1', customer_street_1='3411 Yorkie Lane', customer_street_2='', customer_city='Blackshear', customer_zip='31516', customer_country='Georgia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-09-16 13:22:35', delivery_time='2021-09-16 13:22:35', payment_due_time='2021-11-23 13:22:35', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2109160001', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='1', item='RND.51.8371.26 RND Product 26 (lng-1)', quantity='1.00', id_delivery_unit='20', unit_price='20.5200', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='1', item='RND.17.8653.6 RND Product 6 (lng-1)', quantity='17.00', id_delivery_unit='6', unit_price='20.5100', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='1', item='RND.27.4995.7 RND Product 7 (lng-1)', quantity='5.00', id_delivery_unit='21', unit_price='11.1900', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='1', item='Shipping', quantity='1', unit_price='3.5416666666667', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 1
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 1
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 1
;;
update srkt_invoices set price_total_excl_vat='428.68', price_total_incl_vat='514.39' where id=1;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 1
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 1
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 1
;;
update srkt_orders set state='2', id_invoice='1' where id=1;;
update srkt_orders set state='2' where id=1;;
insert into `srkt_orders_history` set `id`=null, id_order='1', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='1', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 48
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 48
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='2';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 33
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 33
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='2', id_product='33', quantity='7', unit_price='32.9700', added_on='2021-11-23 13:22:35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 50
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 50
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='2', id_product='50', quantity='2', unit_price='22.5500', added_on='2021-11-23 13:22:35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 19
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 19
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='2', id_product='19', quantity='1', unit_price='43.2300', added_on='2021-11-23 13:22:35';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 48
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 48
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-02-16 13:22:35')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-02-16 13:22:35')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210216', lpad(@serial_number, 4, '0'))
      ), id_customer='48', id_customer_uid='2', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2021-02-16 13:22:35', id_delivery_service='2', id_payment_service='3', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='2', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='2', id_product='33', quantity='7', id_delivery_unit='12', unit_price='32.9700', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='2', id_product='50', quantity='2', id_delivery_unit='10', unit_price='22.5500', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='2', id_product='19', quantity='1', id_delivery_unit='2', unit_price='43.2300', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 2
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 2
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 48
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=2;;
update srkt_orders set price_total_excl_vat='319.12', price_total_incl_vat='382.92', weight_total='15336' where id=2;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 40
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 40
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='3';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 33
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 33
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='3', id_product='33', quantity='9', unit_price='32.9700', added_on='2021-11-23 13:22:35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 9
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 9
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='3', id_product='9', quantity='3', unit_price='40.8100', added_on='2021-11-23 13:22:35';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 40
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 40
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-08-09 13:22:35')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-08-09 13:22:35')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210809', lpad(@serial_number, 4, '0'))
      ), id_customer='40', id_customer_uid='3', del_given_name='Miriam', del_family_name='Evans', del_company_name='', del_street_1='2313  Horner Street', del_street_2='', del_floor='', del_city='Montgomery', del_zip='36107', del_country='Alabama', inv_given_name='Miriam', inv_family_name='Evans', inv_company_name='', inv_street_1='2313  Horner Street', inv_street_2='', inv_city='Montgomery', inv_zip='36107', inv_region='', inv_country='Alabama', confirmation_time='2021-08-09 13:22:35', id_delivery_service='1', id_payment_service='3', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='3', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='3', id_product='33', quantity='9', id_delivery_unit='12', unit_price='32.9700', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='3', id_product='9', quantity='3', id_delivery_unit='16', unit_price='40.8100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 3
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 3
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 40
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0.9' where id=3;;
update srkt_orders set price_total_excl_vat='419.16', price_total_incl_vat='502.95', weight_total='18675' where id=3;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 3
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 3
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 40
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-08-09 13:22:35')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-08-09 13:22:35')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210809', lpad(@serial_number, 4, '0'))
      ), id_customer='40', id_order='3', customer_street_1='2313  Horner Street', customer_street_2='', customer_city='Montgomery', customer_zip='36107', customer_country='Alabama', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-08-09 13:22:35', delivery_time='2021-08-09 13:22:35', payment_due_time='2021-11-23 13:22:35', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2108090003', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='2', item='RND.79.6087.32 RND Product 32 (lng-1)', quantity='9.00', id_delivery_unit='12', unit_price='32.9700', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='2', item='RND.53.8896.8 RND Product 8 (lng-1)', quantity='3.00', id_delivery_unit='16', unit_price='40.8100', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='2', item='Payment', quantity='1', unit_price='0.75', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 2
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 2
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 2
;;
update srkt_invoices set price_total_excl_vat='419.91', price_total_incl_vat='503.85' where id=2;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 2
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 2
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 2
;;
update srkt_orders set state='2', id_invoice='2' where id=3;;
update srkt_orders set state='2' where id=3;;
insert into `srkt_orders_history` set `id`=null, id_order='3', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='3', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 21
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 21
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='4';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 39
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 39
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='4', id_product='39', quantity='1', unit_price='25.4800', added_on='2021-11-23 13:22:35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 27
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 27
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='4', id_product='27', quantity='3', unit_price='20.5200', added_on='2021-11-23 13:22:35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 34
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 34
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='4', id_product='34', quantity='1', unit_price='26.3500', added_on='2021-11-23 13:22:35';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 21
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 21
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-01-17 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-01-17 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210117', lpad(@serial_number, 4, '0'))
      ), id_customer='21', id_customer_uid='4', del_given_name='Assunta', del_family_name='Johnson', del_company_name='', del_street_1='3411 Yorkie Lane', del_street_2='', del_floor='', del_city='Blackshear', del_zip='31516', del_country='Georgia', inv_given_name='Assunta', inv_family_name='Johnson', inv_company_name='', inv_street_1='3411 Yorkie Lane', inv_street_2='', inv_city='Blackshear', inv_zip='31516', inv_region='', inv_country='Georgia', confirmation_time='2021-01-17 13:22:36', id_delivery_service='2', id_payment_service='2', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='4', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='4', id_product='39', quantity='1', id_delivery_unit='6', unit_price='25.4800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='4', id_product='27', quantity='3', id_delivery_unit='20', unit_price='20.5200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='4', id_product='34', quantity='1', id_delivery_unit='9', unit_price='26.3500', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 4
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 4
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 21
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=4;;
update srkt_orders set price_total_excl_vat='113.39', price_total_incl_vat='136.06', weight_total='8416' where id=4;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 17
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 17
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='5';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 26
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 26
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='5', id_product='26', quantity='9', unit_price='13.1400', added_on='2021-11-23 13:22:36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 11
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 11
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='5', id_product='11', quantity='3', unit_price='26.8100', added_on='2021-11-23 13:22:36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 21
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 21
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='5', id_product='21', quantity='8', unit_price='13.3400', added_on='2021-11-23 13:22:36';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 17
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 17
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-05-31 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-05-31 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210531', lpad(@serial_number, 4, '0'))
      ), id_customer='17', id_customer_uid='5', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-05-31 13:22:36', id_delivery_service='2', id_payment_service='1', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='5', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='5', id_product='26', quantity='9', id_delivery_unit='5', unit_price='13.1400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='5', id_product='11', quantity='3', id_delivery_unit='19', unit_price='26.8100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='5', id_product='21', quantity='8', id_delivery_unit='3', unit_price='13.3400', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 5
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 5
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 17
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='3.35', payment_fee='0' where id=5;;
update srkt_orders set price_total_excl_vat='305.41', price_total_incl_vat='366.52', weight_total='16723' where id=5;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 5
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 5
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 17
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-05-31 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-05-31 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210531', lpad(@serial_number, 4, '0'))
      ), id_customer='17', id_order='5', customer_street_1='728  Nelm Street', customer_street_2='', customer_city='Leesburg', customer_zip='20176', customer_country='Virginia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-05-31 13:22:36', delivery_time='2021-05-31 13:22:36', payment_due_time='2021-11-23 13:22:36', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2105310005', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='3', item='RND.72.2583.25 RND Product 25 (lng-1)', quantity='9.00', id_delivery_unit='5', unit_price='13.1400', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='3', item='RND.50.6054.10 RND Product 10 (lng-1)', quantity='3.00', id_delivery_unit='19', unit_price='26.8100', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='3', item='RND.95.3784.20 RND Product 20 (lng-1)', quantity='8.00', id_delivery_unit='3', unit_price='13.3400', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='3', item='Shipping', quantity='1', unit_price='2.7916666666667', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 3
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 3
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 3
;;
update srkt_invoices set price_total_excl_vat='308.2', price_total_incl_vat='369.87' where id=3;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 3
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 3
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 3
;;
update srkt_orders set state='2', id_invoice='3' where id=5;;
update srkt_orders set state='2' where id=5;;
insert into `srkt_orders_history` set `id`=null, id_order='5', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='5', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 11
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 11
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='6';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 13
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 13
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='6', id_product='13', quantity='3', unit_price='13.6500', added_on='2021-11-23 13:22:36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 48
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 48
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='6', id_product='48', quantity='3', unit_price='10.2200', added_on='2021-11-23 13:22:36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 33
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 33
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='6', id_product='33', quantity='8', unit_price='32.9700', added_on='2021-11-23 13:22:36';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 11
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 11
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-01-29 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-01-29 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210129', lpad(@serial_number, 4, '0'))
      ), id_customer='11', id_customer_uid='6', del_given_name='Assunta', del_family_name='Johnson', del_company_name='', del_street_1='3411 Yorkie Lane', del_street_2='', del_floor='', del_city='Blackshear', del_zip='31516', del_country='Georgia', inv_given_name='Assunta', inv_family_name='Johnson', inv_company_name='', inv_street_1='3411 Yorkie Lane', inv_street_2='', inv_city='Blackshear', inv_zip='31516', inv_region='', inv_country='Georgia', confirmation_time='2021-01-29 13:22:36', id_delivery_service='2', id_payment_service='3', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='6', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='6', id_product='13', quantity='3', id_delivery_unit='17', unit_price='13.6500', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='6', id_product='48', quantity='3', id_delivery_unit='7', unit_price='10.2200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='6', id_product='33', quantity='8', id_delivery_unit='12', unit_price='32.9700', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 6
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 6
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 11
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=6;;
update srkt_orders set price_total_excl_vat='335.37', price_total_incl_vat='402.4', weight_total='23252' where id=6;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 6
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 6
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 11
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-01-29 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-01-29 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210129', lpad(@serial_number, 4, '0'))
      ), id_customer='11', id_order='6', customer_street_1='3411 Yorkie Lane', customer_street_2='', customer_city='Blackshear', customer_zip='31516', customer_country='Georgia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-01-29 13:22:36', delivery_time='2021-01-29 13:22:36', payment_due_time='2021-11-23 13:22:36', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2101290006', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='4', item='RND.43.2285.12 RND Product 12 (lng-1)', quantity='3.00', id_delivery_unit='17', unit_price='13.6500', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='4', item='RND.96.1055.47 RND Product 47 (lng-1)', quantity='3.00', id_delivery_unit='7', unit_price='10.2200', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='4', item='RND.79.6087.32 RND Product 32 (lng-1)', quantity='8.00', id_delivery_unit='12', unit_price='32.9700', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 4
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 4
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 4
;;
update srkt_invoices set price_total_excl_vat='335.37', price_total_incl_vat='402.4' where id=4;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 4
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 4
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 4
;;
update srkt_orders set state='2', id_invoice='4' where id=6;;
update srkt_orders set state='2' where id=6;;
insert into `srkt_orders_history` set `id`=null, id_order='6', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='6', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 10
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 10
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='7';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 43
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 43
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='7', id_product='43', quantity='8', unit_price='17.4800', added_on='2021-11-23 13:22:36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 29
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 29
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='7', id_product='29', quantity='8', unit_price='13.3100', added_on='2021-11-23 13:22:36';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 10
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 10
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2020-12-02 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2020-12-02 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201202', lpad(@serial_number, 4, '0'))
      ), id_customer='10', id_customer_uid='7', del_given_name='Miriam', del_family_name='Evans', del_company_name='', del_street_1='2313  Horner Street', del_street_2='', del_floor='', del_city='Montgomery', del_zip='36107', del_country='Alabama', inv_given_name='Miriam', inv_family_name='Evans', inv_company_name='', inv_street_1='2313  Horner Street', inv_street_2='', inv_city='Montgomery', inv_zip='36107', inv_region='', inv_country='Alabama', confirmation_time='2020-12-02 13:22:36', id_delivery_service='2', id_payment_service='3', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='7', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='7', id_product='43', quantity='8', id_delivery_unit='14', unit_price='17.4800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='7', id_product='29', quantity='8', id_delivery_unit='10', unit_price='13.3100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 7
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 7
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 10
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=7;;
update srkt_orders set price_total_excl_vat='246.32', price_total_incl_vat='295.6', weight_total='27792' where id=7;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 7
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 7
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 10
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2020-12-02 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2020-12-02 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201202', lpad(@serial_number, 4, '0'))
      ), id_customer='10', id_order='7', customer_street_1='2313  Horner Street', customer_street_2='', customer_city='Montgomery', customer_zip='36107', customer_country='Alabama', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2020-12-02 13:22:36', delivery_time='2020-12-02 13:22:36', payment_due_time='2021-11-23 13:22:36', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2012020001', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='5', item='RND.27.9906.42 RND Product 42 (lng-1)', quantity='8.00', id_delivery_unit='14', unit_price='17.4800', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='5', item='RND.56.6877.28 RND Product 28 (lng-1)', quantity='8.00', id_delivery_unit='10', unit_price='13.3100', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 5
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 5
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 5
;;
update srkt_invoices set price_total_excl_vat='246.32', price_total_incl_vat='295.6' where id=5;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 5
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 5
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 5
;;
update srkt_orders set state='2', id_invoice='5' where id=7;;
update srkt_orders set state='2' where id=7;;
insert into `srkt_orders_history` set `id`=null, id_order='7', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='7', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 33
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 33
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='8';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 17
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 17
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='8', id_product='17', quantity='6', unit_price='12.0300', added_on='2021-11-23 13:22:36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 25
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 25
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='8', id_product='25', quantity='8', unit_price='12.2300', added_on='2021-11-23 13:22:36';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 33
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 33
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2020-12-18 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2020-12-18 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201218', lpad(@serial_number, 4, '0'))
      ), id_customer='33', id_customer_uid='8', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2020-12-18 13:22:36', id_delivery_service='3', id_payment_service='1', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='8', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='8', id_product='17', quantity='6', id_delivery_unit='16', unit_price='12.0300', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='8', id_product='25', quantity='8', id_delivery_unit='5', unit_price='12.2300', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 8
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 8
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 33
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=8;;
update srkt_orders set price_total_excl_vat='170.02', price_total_incl_vat='204.08', weight_total='20750' where id=8;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 38
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 38
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='9';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 6
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 6
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='9', id_product='6', quantity='5', unit_price='15.6700', added_on='2021-11-23 13:22:36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 5
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 5
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='9', id_product='5', quantity='8', unit_price='38.6400', added_on='2021-11-23 13:22:36';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 38
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 38
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-01-29 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-01-29 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210129', lpad(@serial_number, 4, '0'))
      ), id_customer='38', id_customer_uid='9', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2021-01-29 13:22:36', id_delivery_service='4', id_payment_service='3', id_destination_country='4', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='9', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='9', id_product='6', quantity='5', id_delivery_unit='21', unit_price='15.6700', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='9', id_product='5', quantity='8', id_delivery_unit='11', unit_price='38.6400', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 9
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 9
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 38
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=9;;
update srkt_orders set price_total_excl_vat='387.47', price_total_incl_vat='464.96', weight_total='24238' where id=9;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 9
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 9
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 38
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-01-29 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-01-29 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210129', lpad(@serial_number, 4, '0'))
      ), id_customer='38', id_order='9', customer_street_1='2967  Stratford Drive', customer_street_2='', customer_city='Waipahu', customer_zip='96797', customer_country='Hawaii', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-01-29 13:22:36', delivery_time='2021-01-29 13:22:36', payment_due_time='2021-11-23 13:22:36', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2101290007', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='6', item='RND.32.9694.5 RND Product 5 (lng-1)', quantity='5.00', id_delivery_unit='21', unit_price='15.6700', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='6', item='RND.38.4401.4 RND Product 4 (lng-1)', quantity='8.00', id_delivery_unit='11', unit_price='38.6400', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 6
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 6
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 6
;;
update srkt_invoices set price_total_excl_vat='387.47', price_total_incl_vat='464.96' where id=6;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 6
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 6
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 6
;;
update srkt_orders set state='2', id_invoice='6' where id=9;;
update srkt_orders set state='2' where id=9;;
insert into `srkt_orders_history` set `id`=null, id_order='9', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='9', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 34
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 34
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='10';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 24
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 24
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='10', id_product='24', quantity='2', unit_price='31.3100', added_on='2021-11-23 13:22:36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 1
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 1
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='10', id_product='1', quantity='6', unit_price='8.5300', added_on='2021-11-23 13:22:36';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 34
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 34
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2020-12-14 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2020-12-14 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201214', lpad(@serial_number, 4, '0'))
      ), id_customer='34', id_customer_uid='10', del_given_name='Steven', del_family_name='White', del_company_name='', del_street_1='3174  Boggess Street', del_street_2='', del_floor='', del_city='Hillsboro', del_zip='45133', del_country='Ohio', inv_given_name='Steven', inv_family_name='White', inv_company_name='', inv_street_1='3174  Boggess Street', inv_street_2='', inv_city='Hillsboro', inv_zip='45133', inv_region='', inv_country='Ohio', confirmation_time='2020-12-14 13:22:36', id_delivery_service='4', id_payment_service='2', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='10', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='10', id_product='24', quantity='2', id_delivery_unit='8', unit_price='31.3100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='10', id_product='1', quantity='6', id_delivery_unit='12', unit_price='8.5300', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 10
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 10
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 34
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=10;;
update srkt_orders set price_total_excl_vat='113.8', price_total_incl_vat='136.58', weight_total='12966' where id=10;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 10
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 10
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 34
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2020-12-14 13:22:36')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2020-12-14 13:22:36')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201214', lpad(@serial_number, 4, '0'))
      ), id_customer='34', id_order='10', customer_street_1='3174  Boggess Street', customer_street_2='', customer_city='Hillsboro', customer_zip='45133', customer_country='Ohio', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2020-12-14 13:22:36', delivery_time='2020-12-14 13:22:36', payment_due_time='2021-11-23 13:22:37', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2012140003', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='7', item='RND.31.1313.23 RND Product 23 (lng-1)', quantity='2.00', id_delivery_unit='8', unit_price='31.3100', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='7', item='RND.12.8277.0 RND Product 0 (lng-1)', quantity='6.00', id_delivery_unit='12', unit_price='8.5300', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 7
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 7
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 7
;;
update srkt_invoices set price_total_excl_vat='113.8', price_total_incl_vat='136.58' where id=7;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 7
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 7
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 7
;;
update srkt_orders set state='2', id_invoice='7' where id=10;;
update srkt_orders set state='2' where id=10;;
insert into `srkt_orders_history` set `id`=null, id_order='10', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='10', id_tag='1';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 17
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 17
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='11';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 37
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 37
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='11', id_product='37', quantity='8', unit_price='48.9500', added_on='2021-11-23 13:22:37';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 29
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 29
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='11', id_product='29', quantity='7', unit_price='13.3100', added_on='2021-11-23 13:22:37';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 17
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 17
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='11', id_product='17', quantity='10', unit_price='12.0300', added_on='2021-11-23 13:22:37';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 17
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 17
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-04-13 13:22:37')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-04-13 13:22:37')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210413', lpad(@serial_number, 4, '0'))
      ), id_customer='17', id_customer_uid='11', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-04-13 13:22:37', id_delivery_service='1', id_payment_service='1', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='11', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='11', id_product='37', quantity='8', id_delivery_unit='7', unit_price='48.9500', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='11', id_product='29', quantity='7', id_delivery_unit='10', unit_price='13.3100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='11', id_product='17', quantity='10', id_delivery_unit='16', unit_price='12.0300', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 11
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 11
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 17
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=11;;
update srkt_orders set price_total_excl_vat='605.07', price_total_incl_vat='726.11', weight_total='41875' where id=11;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 10
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 10
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='12';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 21
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 21
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='12', id_product='21', quantity='1', unit_price='13.3400', added_on='2021-11-23 13:22:37';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 25
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 25
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='12', id_product='25', quantity='7', unit_price='12.2300', added_on='2021-11-23 13:22:37';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 4
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 4
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='12', id_product='4', quantity='7', unit_price='33.6400', added_on='2021-11-23 13:22:37';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 10
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 10
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-10-18 13:22:37')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-10-18 13:22:37')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('211018', lpad(@serial_number, 4, '0'))
      ), id_customer='10', id_customer_uid='12', del_given_name='Miriam', del_family_name='Evans', del_company_name='', del_street_1='2313  Horner Street', del_street_2='', del_floor='', del_city='Montgomery', del_zip='36107', del_country='Alabama', inv_given_name='Miriam', inv_family_name='Evans', inv_company_name='', inv_street_1='2313  Horner Street', inv_street_2='', inv_city='Montgomery', inv_zip='36107', inv_region='', inv_country='Alabama', confirmation_time='2021-10-18 13:22:37', id_delivery_service='1', id_payment_service='3', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='12', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='12', id_product='21', quantity='1', id_delivery_unit='3', unit_price='13.3400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='12', id_product='25', quantity='7', id_delivery_unit='5', unit_price='12.2300', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='12', id_product='4', quantity='7', id_delivery_unit='8', unit_price='33.6400', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 12
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 12
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 10
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=12;;
update srkt_orders set price_total_excl_vat='334.43', price_total_incl_vat='401.36', weight_total='22953' where id=12;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 37
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 37
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='13';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 4
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 4
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='13', id_product='4', quantity='5', unit_price='33.6400', added_on='2021-11-23 13:22:37';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 29
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 29
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='13', id_product='29', quantity='2', unit_price='13.3100', added_on='2021-11-23 13:22:37';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 37
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 37
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-06-30 13:22:37')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-06-30 13:22:37')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210630', lpad(@serial_number, 4, '0'))
      ), id_customer='37', id_customer_uid='13', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-06-30 13:22:37', id_delivery_service='1', id_payment_service='2', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='13', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='13', id_product='4', quantity='5', id_delivery_unit='8', unit_price='33.6400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='13', id_product='29', quantity='2', id_delivery_unit='10', unit_price='13.3100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 13
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 13
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 37
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=13;;
update srkt_orders set price_total_excl_vat='194.82', price_total_incl_vat='233.79', weight_total='13720' where id=13;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 26
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 26
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='14';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 31
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 31
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='14', id_product='31', quantity='6', unit_price='41.6800', added_on='2021-11-23 13:22:37';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 47
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 47
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='14', id_product='47', quantity='10', unit_price='6.9600', added_on='2021-11-23 13:22:37';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 8
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 8
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='14', id_product='8', quantity='5', unit_price='11.1900', added_on='2021-11-23 13:22:37';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 26
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 26
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-06-17 13:22:37')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-06-17 13:22:37')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210617', lpad(@serial_number, 4, '0'))
      ), id_customer='26', id_customer_uid='14', del_given_name='Assunta', del_family_name='Johnson', del_company_name='', del_street_1='3411 Yorkie Lane', del_street_2='', del_floor='', del_city='Blackshear', del_zip='31516', del_country='Georgia', inv_given_name='Assunta', inv_family_name='Johnson', inv_company_name='', inv_street_1='3411 Yorkie Lane', inv_street_2='', inv_city='Blackshear', inv_zip='31516', inv_region='', inv_country='Georgia', confirmation_time='2021-06-17 13:22:37', id_delivery_service='3', id_payment_service='2', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='14', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='14', id_product='31', quantity='6', id_delivery_unit='10', unit_price='41.6800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='14', id_product='47', quantity='10', id_delivery_unit='12', unit_price='6.9600', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='14', id_product='8', quantity='5', id_delivery_unit='21', unit_price='11.1900', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 14
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 14
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 26
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=14;;
update srkt_orders set price_total_excl_vat='375.63', price_total_incl_vat='450.77', weight_total='31887' where id=14;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 14
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 14
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 26
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-06-17 13:22:37')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-06-17 13:22:37')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210617', lpad(@serial_number, 4, '0'))
      ), id_customer='26', id_order='14', customer_street_1='3411 Yorkie Lane', customer_street_2='', customer_city='Blackshear', customer_zip='31516', customer_country='Georgia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-06-17 13:22:37', delivery_time='2021-06-17 13:22:37', payment_due_time='2021-11-23 13:22:38', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2106170011', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='8', item='RND.45.6319.30 RND Product 30 (lng-1)', quantity='6.00', id_delivery_unit='10', unit_price='41.6800', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='8', item='RND.82.9623.46 RND Product 46 (lng-1)', quantity='10.00', id_delivery_unit='12', unit_price='6.9600', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='8', item='RND.27.4995.7 RND Product 7 (lng-1)', quantity='5.00', id_delivery_unit='21', unit_price='11.1900', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 8
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 8
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 8
;;
update srkt_invoices set price_total_excl_vat='375.63', price_total_incl_vat='450.77' where id=8;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 8
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 8
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 8
;;
update srkt_orders set state='2', id_invoice='8' where id=14;;
update srkt_orders set state='2' where id=14;;
insert into `srkt_orders_history` set `id`=null, id_order='14', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='14', id_tag='3';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 2
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 2
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='15';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 18
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 18
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='15', id_product='18', quantity='3', unit_price='19.1100', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 29
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 29
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='15', id_product='29', quantity='7', unit_price='13.3100', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 38
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 38
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='15', id_product='38', quantity='9', unit_price='12.2200', added_on='2021-11-23 13:22:38';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 2
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 2
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-07-20 13:22:38')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-07-20 13:22:38')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210720', lpad(@serial_number, 4, '0'))
      ), id_customer='2', id_customer_uid='15', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-07-20 13:22:38', id_delivery_service='4', id_payment_service='1', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='15', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='15', id_product='18', quantity='3', id_delivery_unit='9', unit_price='19.1100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='15', id_product='29', quantity='7', id_delivery_unit='10', unit_price='13.3100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='15', id_product='38', quantity='9', id_delivery_unit='17', unit_price='12.2200', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 15
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 15
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 2
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=15;;
update srkt_orders set price_total_excl_vat='260.48', price_total_incl_vat='312.52', weight_total='38435' where id=15;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 14
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 14
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='16';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 38
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 38
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='16', id_product='38', quantity='8', unit_price='12.2200', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 4
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 4
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='16', id_product='4', quantity='10', unit_price='33.6400', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 41
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 41
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='16', id_product='41', quantity='3', unit_price='46.1600', added_on='2021-11-23 13:22:38';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 14
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 14
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2020-12-21 13:22:38')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2020-12-21 13:22:38')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201221', lpad(@serial_number, 4, '0'))
      ), id_customer='14', id_customer_uid='16', del_given_name='Steven', del_family_name='White', del_company_name='', del_street_1='3174  Boggess Street', del_street_2='', del_floor='', del_city='Hillsboro', del_zip='45133', del_country='Ohio', inv_given_name='Steven', inv_family_name='White', inv_company_name='', inv_street_1='3174  Boggess Street', inv_street_2='', inv_city='Hillsboro', inv_zip='45133', inv_region='', inv_country='Ohio', confirmation_time='2020-12-21 13:22:38', id_delivery_service='2', id_payment_service='3', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='16', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='16', id_product='38', quantity='8', id_delivery_unit='17', unit_price='12.2200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='16', id_product='4', quantity='10', id_delivery_unit='8', unit_price='33.6400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='16', id_product='41', quantity='3', id_delivery_unit='3', unit_price='46.1600', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 16
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 16
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 14
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=16;;
update srkt_orders set price_total_excl_vat='572.64', price_total_incl_vat='687.15', weight_total='33990' where id=16;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 16
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 16
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 14
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2020-12-21 13:22:38')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2020-12-21 13:22:38')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201221', lpad(@serial_number, 4, '0'))
      ), id_customer='14', id_order='16', customer_street_1='3174  Boggess Street', customer_street_2='', customer_city='Hillsboro', customer_zip='45133', customer_country='Ohio', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2020-12-21 13:22:38', delivery_time='2020-12-21 13:22:38', payment_due_time='2021-11-23 13:22:38', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2012210004', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='9', item='RND.86.7529.37 RND Product 37 (lng-1)', quantity='8.00', id_delivery_unit='17', unit_price='12.2200', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='9', item='RND.80.8246.3 RND Product 3 (lng-1)', quantity='10.00', id_delivery_unit='8', unit_price='33.6400', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='9', item='RND.35.9866.40 RND Product 40 (lng-1)', quantity='3.00', id_delivery_unit='3', unit_price='46.1600', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 9
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 9
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 9
;;
update srkt_invoices set price_total_excl_vat='572.64', price_total_incl_vat='687.15' where id=9;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 9
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 9
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 9
;;
update srkt_orders set state='2', id_invoice='9' where id=16;;
update srkt_orders set state='2' where id=16;;
insert into `srkt_orders_history` set `id`=null, id_order='16', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='16', id_tag='3';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 35
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 35
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='17';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 17
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 17
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='17', id_product='17', quantity='7', unit_price='12.0300', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 3
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 3
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='17', id_product='3', quantity='7', unit_price='28.8200', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 12
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 12
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='17', id_product='12', quantity='9', unit_price='24.1900', added_on='2021-11-23 13:22:38';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 35
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 35
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-09-27 13:22:38')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-09-27 13:22:38')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210927', lpad(@serial_number, 4, '0'))
      ), id_customer='35', id_customer_uid='17', del_given_name='Miriam', del_family_name='Evans', del_company_name='', del_street_1='2313  Horner Street', del_street_2='', del_floor='', del_city='Montgomery', del_zip='36107', del_country='Alabama', inv_given_name='Miriam', inv_family_name='Evans', inv_company_name='', inv_street_1='2313  Horner Street', inv_street_2='', inv_city='Montgomery', inv_zip='36107', inv_region='', inv_country='Alabama', confirmation_time='2021-09-27 13:22:38', id_delivery_service='4', id_payment_service='2', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='17', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='17', id_product='17', quantity='7', id_delivery_unit='16', unit_price='12.0300', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='17', id_product='3', quantity='7', id_delivery_unit='2', unit_price='28.8200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='17', id_product='12', quantity='9', id_delivery_unit='17', unit_price='24.1900', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 17
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 17
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 35
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=17;;
update srkt_orders set price_total_excl_vat='503.66', price_total_incl_vat='604.41', weight_total='32388' where id=17;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 3
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 3
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='18';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 37
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 37
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='18', id_product='37', quantity='6', unit_price='48.9500', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 24
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 24
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='18', id_product='24', quantity='10', unit_price='31.3100', added_on='2021-11-23 13:22:38';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 3
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 3
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-10-02 13:22:38')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-10-02 13:22:38')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('211002', lpad(@serial_number, 4, '0'))
      ), id_customer='3', id_customer_uid='18', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2021-10-02 13:22:38', id_delivery_service='2', id_payment_service='3', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='18', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='18', id_product='37', quantity='6', id_delivery_unit='7', unit_price='48.9500', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='18', id_product='24', quantity='10', id_delivery_unit='8', unit_price='31.3100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 18
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 18
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 3
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=18;;
update srkt_orders set price_total_excl_vat='606.8', price_total_incl_vat='728.14', weight_total='13620' where id=18;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 18
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 18
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 3
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-10-02 13:22:38')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-10-02 13:22:38')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('211002', lpad(@serial_number, 4, '0'))
      ), id_customer='3', id_order='18', customer_street_1='2967  Stratford Drive', customer_street_2='', customer_city='Waipahu', customer_zip='96797', customer_country='Hawaii', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-10-02 13:22:38', delivery_time='2021-10-02 13:22:38', payment_due_time='2021-11-23 13:22:38', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2110020014', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='10', item='RND.25.3546.36 RND Product 36 (lng-1)', quantity='6.00', id_delivery_unit='7', unit_price='48.9500', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='10', item='RND.31.1313.23 RND Product 23 (lng-1)', quantity='10.00', id_delivery_unit='8', unit_price='31.3100', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 10
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 10
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 10
;;
update srkt_invoices set price_total_excl_vat='606.8', price_total_incl_vat='728.14' where id=10;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 10
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 10
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 10
;;
update srkt_orders set state='2', id_invoice='10' where id=18;;
update srkt_orders set state='2' where id=18;;
insert into `srkt_orders_history` set `id`=null, id_order='18', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='18', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 26
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 26
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='19';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 23
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 23
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='19', id_product='23', quantity='9', unit_price='7.1200', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 45
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 45
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='19', id_product='45', quantity='5', unit_price='49.6600', added_on='2021-11-23 13:22:38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 26
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 26
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='19', id_product='26', quantity='2', unit_price='13.1400', added_on='2021-11-23 13:22:38';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 26
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 26
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-10-23 13:22:38')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-10-23 13:22:38')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('211023', lpad(@serial_number, 4, '0'))
      ), id_customer='26', id_customer_uid='19', del_given_name='Assunta', del_family_name='Johnson', del_company_name='', del_street_1='3411 Yorkie Lane', del_street_2='', del_floor='', del_city='Blackshear', del_zip='31516', del_country='Georgia', inv_given_name='Assunta', inv_family_name='Johnson', inv_company_name='', inv_street_1='3411 Yorkie Lane', inv_street_2='', inv_city='Blackshear', inv_zip='31516', inv_region='', inv_country='Georgia', confirmation_time='2021-10-23 13:22:38', id_delivery_service='2', id_payment_service='2', id_destination_country='4', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='19', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='19', id_product='23', quantity='9', id_delivery_unit='7', unit_price='7.1200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='19', id_product='45', quantity='5', id_delivery_unit='7', unit_price='49.6600', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='19', id_product='26', quantity='2', id_delivery_unit='5', unit_price='13.1400', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 19
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 19
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 26
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=19;;
update srkt_orders set price_total_excl_vat='338.66', price_total_incl_vat='406.35', weight_total='33308' where id=19;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 37
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 37
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='20';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 25
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 25
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='20', id_product='25', quantity='5', unit_price='12.2300', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 1
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 1
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='20', id_product='1', quantity='8', unit_price='8.5300', added_on='2021-11-23 13:22:39';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 37
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 37
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-01-22 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-01-22 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210122', lpad(@serial_number, 4, '0'))
      ), id_customer='37', id_customer_uid='20', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-01-22 13:22:39', id_delivery_service='4', id_payment_service='1', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='20', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='20', id_product='25', quantity='5', id_delivery_unit='5', unit_price='12.2300', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='20', id_product='1', quantity='8', id_delivery_unit='12', unit_price='8.5300', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 20
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 20
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 37
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=20;;
update srkt_orders set price_total_excl_vat='129.39', price_total_incl_vat='155.32', weight_total='22531' where id=20;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 42
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 42
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='21';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 31
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 31
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='21', id_product='31', quantity='9', unit_price='41.6800', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 50
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 50
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='21', id_product='50', quantity='2', unit_price='22.5500', added_on='2021-11-23 13:22:39';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 42
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 42
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-06-19 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-06-19 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210619', lpad(@serial_number, 4, '0'))
      ), id_customer='42', id_customer_uid='21', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-06-19 13:22:39', id_delivery_service='3', id_payment_service='3', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='21', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='21', id_product='31', quantity='9', id_delivery_unit='10', unit_price='41.6800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='21', id_product='50', quantity='2', id_delivery_unit='10', unit_price='22.5500', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 21
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 21
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 42
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=21;;
update srkt_orders set price_total_excl_vat='420.22', price_total_incl_vat='504.3', weight_total='13655' where id=21;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 21
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 21
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 42
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-06-19 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-06-19 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210619', lpad(@serial_number, 4, '0'))
      ), id_customer='42', id_order='21', customer_street_1='728  Nelm Street', customer_street_2='', customer_city='Leesburg', customer_zip='20176', customer_country='Virginia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-06-19 13:22:39', delivery_time='2021-06-19 13:22:39', payment_due_time='2021-11-23 13:22:39', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2106190017', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='11', item='RND.45.6319.30 RND Product 30 (lng-1)', quantity='9.00', id_delivery_unit='10', unit_price='41.6800', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='11', item='RND.57.1166.49 RND Product 49 (lng-1)', quantity='2.00', id_delivery_unit='10', unit_price='22.5500', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 11
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 11
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 11
;;
update srkt_invoices set price_total_excl_vat='420.22', price_total_incl_vat='504.3' where id=11;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 11
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 11
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 11
;;
update srkt_orders set state='2', id_invoice='11' where id=21;;
update srkt_orders set state='2' where id=21;;
insert into `srkt_orders_history` set `id`=null, id_order='21', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='21', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 5
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 5
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='22';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 15
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 15
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='22', id_product='15', quantity='5', unit_price='36.3300', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 43
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 43
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='22', id_product='43', quantity='6', unit_price='17.4800', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 39
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 39
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='22', id_product='39', quantity='3', unit_price='25.4800', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 49
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 49
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='22', id_product='49', quantity='5', unit_price='15.2800', added_on='2021-11-23 13:22:39';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 5
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 5
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-04-21 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-04-21 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210421', lpad(@serial_number, 4, '0'))
      ), id_customer='5', id_customer_uid='22', del_given_name='Miriam', del_family_name='Evans', del_company_name='', del_street_1='2313  Horner Street', del_street_2='', del_floor='', del_city='Montgomery', del_zip='36107', del_country='Alabama', inv_given_name='Miriam', inv_family_name='Evans', inv_company_name='', inv_street_1='2313  Horner Street', inv_street_2='', inv_city='Montgomery', inv_zip='36107', inv_region='', inv_country='Alabama', confirmation_time='2021-04-21 13:22:39', id_delivery_service='4', id_payment_service='2', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='22', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='22', id_product='15', quantity='5', id_delivery_unit='19', unit_price='36.3300', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='22', id_product='43', quantity='6', id_delivery_unit='14', unit_price='17.4800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='22', id_product='39', quantity='3', id_delivery_unit='6', unit_price='25.4800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='22', id_product='49', quantity='5', id_delivery_unit='7', unit_price='15.2800', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 22
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 22
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 5
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=22;;
update srkt_orders set price_total_excl_vat='439.37', price_total_incl_vat='527.32', weight_total='28494' where id=22;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 22
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 22
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 5
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-04-21 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-04-21 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210421', lpad(@serial_number, 4, '0'))
      ), id_customer='5', id_order='22', customer_street_1='2313  Horner Street', customer_street_2='', customer_city='Montgomery', customer_zip='36107', customer_country='Alabama', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-04-21 13:22:39', delivery_time='2021-04-21 13:22:39', payment_due_time='2021-11-23 13:22:39', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2104210018', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='12', item='RND.51.2324.14 RND Product 14 (lng-1)', quantity='5.00', id_delivery_unit='19', unit_price='36.3300', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='12', item='RND.27.9906.42 RND Product 42 (lng-1)', quantity='6.00', id_delivery_unit='14', unit_price='17.4800', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='12', item='RND.59.9678.38 RND Product 38 (lng-1)', quantity='3.00', id_delivery_unit='6', unit_price='25.4800', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='12', item='RND.59.7734.48 RND Product 48 (lng-1)', quantity='5.00', id_delivery_unit='7', unit_price='15.2800', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 12
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 12
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 12
;;
update srkt_invoices set price_total_excl_vat='439.37', price_total_incl_vat='527.32' where id=12;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 12
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 12
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 12
;;
update srkt_orders set state='2', id_invoice='12' where id=22;;
update srkt_orders set state='2' where id=22;;
insert into `srkt_orders_history` set `id`=null, id_order='22', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='22', id_tag='1';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 17
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 17
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='23';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 40
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 40
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='23', id_product='40', quantity='5', unit_price='40.7500', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 49
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 49
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='23', id_product='49', quantity='5', unit_price='15.2800', added_on='2021-11-23 13:22:39';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 17
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 17
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-02-01 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-02-01 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210201', lpad(@serial_number, 4, '0'))
      ), id_customer='17', id_customer_uid='23', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-02-01 13:22:39', id_delivery_service='4', id_payment_service='1', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='23', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='23', id_product='40', quantity='5', id_delivery_unit='4', unit_price='40.7500', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='23', id_product='49', quantity='5', id_delivery_unit='7', unit_price='15.2800', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 23
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 23
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 17
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=23;;
update srkt_orders set price_total_excl_vat='280.15', price_total_incl_vat='336.2', weight_total='19325' where id=23;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 23
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 23
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 17
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-02-01 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-02-01 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210201', lpad(@serial_number, 4, '0'))
      ), id_customer='17', id_order='23', customer_street_1='728  Nelm Street', customer_street_2='', customer_city='Leesburg', customer_zip='20176', customer_country='Virginia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-02-01 13:22:39', delivery_time='2021-02-01 13:22:39', payment_due_time='2021-11-23 13:22:39', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2102010019', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='13', item='RND.80.1449.39 RND Product 39 (lng-1)', quantity='5.00', id_delivery_unit='4', unit_price='40.7500', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='13', item='RND.59.7734.48 RND Product 48 (lng-1)', quantity='5.00', id_delivery_unit='7', unit_price='15.2800', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 13
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 13
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 13
;;
update srkt_invoices set price_total_excl_vat='280.15', price_total_incl_vat='336.2' where id=13;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 13
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 13
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 13
;;
update srkt_orders set state='2', id_invoice='13' where id=23;;
update srkt_orders set state='2' where id=23;;
insert into `srkt_orders_history` set `id`=null, id_order='23', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='23', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 32
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 32
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='24';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 23
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 23
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='24', id_product='23', quantity='8', unit_price='7.1200', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 36
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 36
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='24', id_product='36', quantity='7', unit_price='27.2700', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 2
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 2
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='24', id_product='2', quantity='3', unit_price='8.4300', added_on='2021-11-23 13:22:39';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 32
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 32
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-03-01 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-03-01 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210301', lpad(@serial_number, 4, '0'))
      ), id_customer='32', id_customer_uid='24', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-03-01 13:22:39', id_delivery_service='1', id_payment_service='1', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='24', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='24', id_product='23', quantity='8', id_delivery_unit='7', unit_price='7.1200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='24', id_product='36', quantity='7', id_delivery_unit='2', unit_price='27.2700', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='24', id_product='2', quantity='3', id_delivery_unit='19', unit_price='8.4300', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 24
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 24
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 32
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='4.44' where id=24;;
update srkt_orders set price_total_excl_vat='273.14', price_total_incl_vat='327.72', weight_total='39194' where id=24;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 24
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 24
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 32
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-03-01 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-03-01 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210301', lpad(@serial_number, 4, '0'))
      ), id_customer='32', id_order='24', customer_street_1='728  Nelm Street', customer_street_2='', customer_city='Leesburg', customer_zip='20176', customer_country='Virginia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-03-01 13:22:39', delivery_time='2021-03-01 13:22:39', payment_due_time='2021-11-23 13:22:39', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2103010020', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='14', item='RND.13.4908.22 RND Product 22 (lng-1)', quantity='8.00', id_delivery_unit='7', unit_price='7.1200', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='14', item='RND.51.9738.35 RND Product 35 (lng-1)', quantity='7.00', id_delivery_unit='2', unit_price='27.2700', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='14', item='RND.16.3962.1 RND Product 1 (lng-1)', quantity='3.00', id_delivery_unit='19', unit_price='8.4300', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='14', item='Payment', quantity='1', unit_price='3.7', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 14
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 14
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 14
;;
update srkt_invoices set price_total_excl_vat='276.84', price_total_incl_vat='332.16' where id=14;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 14
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 14
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 14
;;
update srkt_orders set state='2', id_invoice='14' where id=24;;
update srkt_orders set state='2' where id=24;;
insert into `srkt_orders_history` set `id`=null, id_order='24', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='24', id_tag='3';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 43
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 43
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='25';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 43
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 43
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='25', id_product='43', quantity='10', unit_price='17.4800', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 39
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 39
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='25', id_product='39', quantity='3', unit_price='25.4800', added_on='2021-11-23 13:22:39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 43
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 43
;;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 9
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 9
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='25', id_product='9', quantity='7', unit_price='40.8100', added_on='2021-11-23 13:22:39';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 43
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 43
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-05-02 13:22:39')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-05-02 13:22:39')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210502', lpad(@serial_number, 4, '0'))
      ), id_customer='43', id_customer_uid='25', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2021-05-02 13:22:39', id_delivery_service='1', id_payment_service='3', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='25', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='25', id_product='43', quantity='17', id_delivery_unit='14', unit_price='17.4800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='25', id_product='39', quantity='3', id_delivery_unit='6', unit_price='25.4800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='25', id_product='9', quantity='7', id_delivery_unit='16', unit_price='40.8100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 25
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 25
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 43
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=25;;
update srkt_orders set price_total_excl_vat='659.27', price_total_incl_vat='791.19', weight_total='28205' where id=25;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 38
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 38
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='26';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 46
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 46
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='26', id_product='46', quantity='5', unit_price='15.0400', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 15
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 15
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='26', id_product='15', quantity='3', unit_price='36.3300', added_on='2021-11-23 13:22:40';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 38
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 38
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2020-12-30 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2020-12-30 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201230', lpad(@serial_number, 4, '0'))
      ), id_customer='38', id_customer_uid='26', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2020-12-30 13:22:40', id_delivery_service='4', id_payment_service='2', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='26', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='26', id_product='46', quantity='5', id_delivery_unit='17', unit_price='15.0400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='26', id_product='15', quantity='3', id_delivery_unit='19', unit_price='36.3300', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 26
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 26
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 38
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=26;;
update srkt_orders set price_total_excl_vat='184.19', price_total_incl_vat='221.05', weight_total='19028' where id=26;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 26
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 26
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 38
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2020-12-30 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2020-12-30 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201230', lpad(@serial_number, 4, '0'))
      ), id_customer='38', id_order='26', customer_street_1='2967  Stratford Drive', customer_street_2='', customer_city='Waipahu', customer_zip='96797', customer_country='Hawaii', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2020-12-30 13:22:40', delivery_time='2020-12-30 13:22:40', payment_due_time='2021-11-23 13:22:40', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2012300005', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='15', item='RND.24.2290.45 RND Product 45 (lng-1)', quantity='5.00', id_delivery_unit='17', unit_price='15.0400', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='15', item='RND.51.2324.14 RND Product 14 (lng-1)', quantity='3.00', id_delivery_unit='19', unit_price='36.3300', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 15
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 15
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 15
;;
update srkt_invoices set price_total_excl_vat='184.19', price_total_incl_vat='221.05' where id=15;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 15
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 15
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 15
;;
update srkt_orders set state='2', id_invoice='15' where id=26;;
update srkt_orders set state='2' where id=26;;
insert into `srkt_orders_history` set `id`=null, id_order='26', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='26', id_tag='1';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 8
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 8
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='27';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 47
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 47
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='27', id_product='47', quantity='2', unit_price='6.9600', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 44
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 44
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='27', id_product='44', quantity='4', unit_price='45.9600', added_on='2021-11-23 13:22:40';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 8
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 8
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-03-05 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-03-05 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210305', lpad(@serial_number, 4, '0'))
      ), id_customer='8', id_customer_uid='27', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2021-03-05 13:22:40', id_delivery_service='3', id_payment_service='1', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='27', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='27', id_product='47', quantity='2', id_delivery_unit='12', unit_price='6.9600', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='27', id_product='44', quantity='4', id_delivery_unit='13', unit_price='45.9600', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 27
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 27
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 8
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=27;;
update srkt_orders set price_total_excl_vat='197.76', price_total_incl_vat='237.3', weight_total='7728' where id=27;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 30
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 30
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='28';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 12
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 12
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='28', id_product='12', quantity='7', unit_price='24.1900', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 27
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 27
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='28', id_product='27', quantity='3', unit_price='20.5200', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 20
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 20
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='28', id_product='20', quantity='3', unit_price='40.7100', added_on='2021-11-23 13:22:40';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 30
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 30
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-08-29 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-08-29 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210829', lpad(@serial_number, 4, '0'))
      ), id_customer='30', id_customer_uid='28', del_given_name='Miriam', del_family_name='Evans', del_company_name='', del_street_1='2313  Horner Street', del_street_2='', del_floor='', del_city='Montgomery', del_zip='36107', del_country='Alabama', inv_given_name='Miriam', inv_family_name='Evans', inv_company_name='', inv_street_1='2313  Horner Street', inv_street_2='', inv_city='Montgomery', inv_zip='36107', inv_region='', inv_country='Alabama', confirmation_time='2021-08-29 13:22:40', id_delivery_service='1', id_payment_service='1', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='28', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='28', id_product='12', quantity='7', id_delivery_unit='17', unit_price='24.1900', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='28', id_product='27', quantity='3', id_delivery_unit='20', unit_price='20.5200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='28', id_product='20', quantity='3', id_delivery_unit='17', unit_price='40.7100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 28
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 28
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 30
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='4.44' where id=28;;
update srkt_orders set price_total_excl_vat='353.02', price_total_incl_vat='423.62', weight_total='22452' where id=28;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 28
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 28
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 30
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-08-29 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-08-29 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210829', lpad(@serial_number, 4, '0'))
      ), id_customer='30', id_order='28', customer_street_1='2313  Horner Street', customer_street_2='', customer_city='Montgomery', customer_zip='36107', customer_country='Alabama', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-08-29 13:22:40', delivery_time='2021-08-29 13:22:40', payment_due_time='2021-11-23 13:22:40', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2108290023', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='16', item='RND.30.5718.11 RND Product 11 (lng-1)', quantity='7.00', id_delivery_unit='17', unit_price='24.1900', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='16', item='RND.51.8371.26 RND Product 26 (lng-1)', quantity='3.00', id_delivery_unit='20', unit_price='20.5200', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='16', item='RND.15.4174.19 RND Product 19 (lng-1)', quantity='3.00', id_delivery_unit='17', unit_price='40.7100', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='16', item='Payment', quantity='1', unit_price='3.7', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 16
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 16
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 16
;;
update srkt_invoices set price_total_excl_vat='356.72', price_total_incl_vat='428.06' where id=16;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 16
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 16
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 16
;;
update srkt_orders set state='2', id_invoice='16' where id=28;;
update srkt_orders set state='2' where id=28;;
insert into `srkt_orders_history` set `id`=null, id_order='28', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='28', id_tag='1';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 24
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 24
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='29';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 40
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 40
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='29', id_product='40', quantity='6', unit_price='40.7500', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 29
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 29
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='29', id_product='29', quantity='6', unit_price='13.3100', added_on='2021-11-23 13:22:40';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 24
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 24
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-03-18 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-03-18 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210318', lpad(@serial_number, 4, '0'))
      ), id_customer='24', id_customer_uid='29', del_given_name='Steven', del_family_name='White', del_company_name='', del_street_1='3174  Boggess Street', del_street_2='', del_floor='', del_city='Hillsboro', del_zip='45133', del_country='Ohio', inv_given_name='Steven', inv_family_name='White', inv_company_name='', inv_street_1='3174  Boggess Street', inv_street_2='', inv_city='Hillsboro', inv_zip='45133', inv_region='', inv_country='Ohio', confirmation_time='2021-03-18 13:22:40', id_delivery_service='2', id_payment_service='1', id_destination_country='4', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='29', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='29', id_product='40', quantity='6', id_delivery_unit='4', unit_price='40.7500', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='29', id_product='29', quantity='6', id_delivery_unit='10', unit_price='13.3100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 29
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 29
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 24
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=29;;
update srkt_orders set price_total_excl_vat='324.36', price_total_incl_vat='389.22', weight_total='29958' where id=29;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 41
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 41
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='30';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 15
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 15
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='30', id_product='15', quantity='3', unit_price='36.3300', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 30
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 30
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='30', id_product='30', quantity='7', unit_price='28.5100', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 37
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 37
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='30', id_product='37', quantity='8', unit_price='48.9500', added_on='2021-11-23 13:22:40';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 41
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 41
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-06-05 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-06-05 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210605', lpad(@serial_number, 4, '0'))
      ), id_customer='41', id_customer_uid='30', del_given_name='Assunta', del_family_name='Johnson', del_company_name='', del_street_1='3411 Yorkie Lane', del_street_2='', del_floor='', del_city='Blackshear', del_zip='31516', del_country='Georgia', inv_given_name='Assunta', inv_family_name='Johnson', inv_company_name='', inv_street_1='3411 Yorkie Lane', inv_street_2='', inv_city='Blackshear', inv_zip='31516', inv_region='', inv_country='Georgia', confirmation_time='2021-06-05 13:22:40', id_delivery_service='2', id_payment_service='1', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='30', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='30', id_product='15', quantity='3', id_delivery_unit='19', unit_price='36.3300', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='30', id_product='30', quantity='7', id_delivery_unit='7', unit_price='28.5100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='30', id_product='37', quantity='8', id_delivery_unit='7', unit_price='48.9500', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 30
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 30
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 41
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=30;;
update srkt_orders set price_total_excl_vat='700.16', price_total_incl_vat='840.19', weight_total='19822' where id=30;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 30
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 30
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 41
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-06-05 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-06-05 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210605', lpad(@serial_number, 4, '0'))
      ), id_customer='41', id_order='30', customer_street_1='3411 Yorkie Lane', customer_street_2='', customer_city='Blackshear', customer_zip='31516', customer_country='Georgia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-06-05 13:22:40', delivery_time='2021-06-05 13:22:40', payment_due_time='2021-11-23 13:22:40', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2106050025', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='17', item='RND.51.2324.14 RND Product 14 (lng-1)', quantity='3.00', id_delivery_unit='19', unit_price='36.3300', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='17', item='RND.70.5132.29 RND Product 29 (lng-1)', quantity='7.00', id_delivery_unit='7', unit_price='28.5100', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='17', item='RND.25.3546.36 RND Product 36 (lng-1)', quantity='8.00', id_delivery_unit='7', unit_price='48.9500', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 17
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 17
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 17
;;
update srkt_invoices set price_total_excl_vat='700.16', price_total_incl_vat='840.19' where id=17;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 17
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 17
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 17
;;
update srkt_orders set state='2', id_invoice='17' where id=30;;
update srkt_orders set state='2' where id=30;;
insert into `srkt_orders_history` set `id`=null, id_order='30', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='30', id_tag='3';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 43
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 43
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='31';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 28
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 28
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='31', id_product='28', quantity='3', unit_price='5.3400', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 21
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 21
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='31', id_product='21', quantity='10', unit_price='13.3400', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 50
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 50
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='31', id_product='50', quantity='5', unit_price='22.5500', added_on='2021-11-23 13:22:40';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 43
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 43
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-05-29 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-05-29 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210529', lpad(@serial_number, 4, '0'))
      ), id_customer='43', id_customer_uid='31', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2021-05-29 13:22:40', id_delivery_service='2', id_payment_service='3', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='31', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='31', id_product='28', quantity='3', id_delivery_unit='9', unit_price='5.3400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='31', id_product='21', quantity='10', id_delivery_unit='3', unit_price='13.3400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='31', id_product='50', quantity='5', id_delivery_unit='10', unit_price='22.5500', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 31
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 31
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 43
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=31;;
update srkt_orders set price_total_excl_vat='262.17', price_total_incl_vat='314.63', weight_total='15883' where id=31;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 47
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 47
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='32';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 15
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 15
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='32', id_product='15', quantity='1', unit_price='36.3300', added_on='2021-11-23 13:22:40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 28
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 28
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='32', id_product='28', quantity='4', unit_price='5.3400', added_on='2021-11-23 13:22:40';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 47
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 47
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-09-03 13:22:40')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-09-03 13:22:40')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210903', lpad(@serial_number, 4, '0'))
      ), id_customer='47', id_customer_uid='32', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-09-03 13:22:40', id_delivery_service='3', id_payment_service='1', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='32', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='32', id_product='15', quantity='1', id_delivery_unit='19', unit_price='36.3300', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='32', id_product='28', quantity='4', id_delivery_unit='9', unit_price='5.3400', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 32
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 32
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 47
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='4.25', payment_fee='0' where id=32;;
update srkt_orders set price_total_excl_vat='57.69', price_total_incl_vat='69.24', weight_total='8790' where id=32;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 3
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 3
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='33';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 43
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 43
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='33', id_product='43', quantity='10', unit_price='17.4800', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 47
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 47
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='33', id_product='47', quantity='10', unit_price='6.9600', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 40
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 40
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='33', id_product='40', quantity='4', unit_price='40.7500', added_on='2021-11-23 13:22:41';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 3
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 3
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-09-29 13:22:41')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-09-29 13:22:41')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210929', lpad(@serial_number, 4, '0'))
      ), id_customer='3', id_customer_uid='33', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2021-09-29 13:22:41', id_delivery_service='2', id_payment_service='2', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='33', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='33', id_product='43', quantity='10', id_delivery_unit='14', unit_price='17.4800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='33', id_product='47', quantity='10', id_delivery_unit='12', unit_price='6.9600', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='33', id_product='40', quantity='4', id_delivery_unit='4', unit_price='40.7500', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 33
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 33
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 3
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=33;;
update srkt_orders set price_total_excl_vat='407.4', price_total_incl_vat='488.9', weight_total='32082' where id=33;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 29
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 29
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='34';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 40
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 40
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='34', id_product='40', quantity='3', unit_price='40.7500', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 24
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 24
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='34', id_product='24', quantity='7', unit_price='31.3100', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 45
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 45
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='34', id_product='45', quantity='5', unit_price='49.6600', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 7
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 7
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='34', id_product='7', quantity='2', unit_price='20.5100', added_on='2021-11-23 13:22:41';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 29
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 29
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-02-27 13:22:41')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-02-27 13:22:41')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210227', lpad(@serial_number, 4, '0'))
      ), id_customer='29', id_customer_uid='34', del_given_name='Steven', del_family_name='White', del_company_name='', del_street_1='3174  Boggess Street', del_street_2='', del_floor='', del_city='Hillsboro', del_zip='45133', del_country='Ohio', inv_given_name='Steven', inv_family_name='White', inv_company_name='', inv_street_1='3174  Boggess Street', inv_street_2='', inv_city='Hillsboro', inv_zip='45133', inv_region='', inv_country='Ohio', confirmation_time='2021-02-27 13:22:41', id_delivery_service='2', id_payment_service='1', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='34', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='34', id_product='40', quantity='3', id_delivery_unit='4', unit_price='40.7500', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='34', id_product='24', quantity='7', id_delivery_unit='8', unit_price='31.3100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='34', id_product='45', quantity='5', id_delivery_unit='7', unit_price='49.6600', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='34', id_product='7', quantity='2', id_delivery_unit='6', unit_price='20.5100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 34
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 34
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 29
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=34;;
update srkt_orders set price_total_excl_vat='630.74', price_total_incl_vat='756.86', weight_total='25004' where id=34;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 34
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 34
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 29
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 2
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-02-27 13:22:41')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-02-27 13:22:41')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210227', lpad(@serial_number, 4, '0'))
      ), id_customer='29', id_order='34', customer_street_1='3174  Boggess Street', customer_street_2='', customer_city='Hillsboro', customer_zip='45133', customer_country='Ohio', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-02-27 13:22:41', delivery_time='2021-02-27 13:22:41', payment_due_time='2021-11-23 13:22:41', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2102270029', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='18', item='RND.80.1449.39 RND Product 39 (lng-1)', quantity='3.00', id_delivery_unit='4', unit_price='40.7500', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='18', item='RND.31.1313.23 RND Product 23 (lng-1)', quantity='7.00', id_delivery_unit='8', unit_price='31.3100', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='18', item='RND.29.7221.44 RND Product 44 (lng-1)', quantity='5.00', id_delivery_unit='7', unit_price='49.6600', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='18', item='RND.17.8653.6 RND Product 6 (lng-1)', quantity='2.00', id_delivery_unit='6', unit_price='20.5100', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 18
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 18
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 18
;;
update srkt_invoices set price_total_excl_vat='630.74', price_total_incl_vat='756.86' where id=18;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 18
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 18
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 18
;;
update srkt_orders set state='2', id_invoice='18' where id=34;;
update srkt_orders set state='2' where id=34;;
insert into `srkt_orders_history` set `id`=null, id_order='34', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='34', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 16
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 16
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='35';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 39
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 39
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='35', id_product='39', quantity='3', unit_price='25.4800', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 8
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 8
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='35', id_product='8', quantity='8', unit_price='11.1900', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 40
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 40
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='35', id_product='40', quantity='6', unit_price='40.7500', added_on='2021-11-23 13:22:41';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 16
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 16
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2020-12-24 13:22:41')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2020-12-24 13:22:41')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201224', lpad(@serial_number, 4, '0'))
      ), id_customer='16', id_customer_uid='35', del_given_name='Assunta', del_family_name='Johnson', del_company_name='', del_street_1='3411 Yorkie Lane', del_street_2='', del_floor='', del_city='Blackshear', del_zip='31516', del_country='Georgia', inv_given_name='Assunta', inv_family_name='Johnson', inv_company_name='', inv_street_1='3411 Yorkie Lane', inv_street_2='', inv_city='Blackshear', inv_zip='31516', inv_region='', inv_country='Georgia', confirmation_time='2020-12-24 13:22:41', id_delivery_service='1', id_payment_service='1', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='35', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='35', id_product='39', quantity='3', id_delivery_unit='6', unit_price='25.4800', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='35', id_product='8', quantity='8', id_delivery_unit='21', unit_price='11.1900', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='35', id_product='40', quantity='6', id_delivery_unit='4', unit_price='40.7500', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 35
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 35
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 16
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=35;;
update srkt_orders set price_total_excl_vat='410.46', price_total_incl_vat='492.58', weight_total='37059' where id=35;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 35
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 35
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 16
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 1
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2020-12-24 13:22:41')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2020-12-24 13:22:41')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('201224', lpad(@serial_number, 4, '0'))
      ), id_customer='16', id_order='35', customer_street_1='3411 Yorkie Lane', customer_street_2='', customer_city='Blackshear', customer_zip='31516', customer_country='Georgia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2020-12-24 13:22:41', delivery_time='2020-12-24 13:22:41', payment_due_time='2021-11-23 13:22:41', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2012240006', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='19', item='RND.59.9678.38 RND Product 38 (lng-1)', quantity='3.00', id_delivery_unit='6', unit_price='25.4800', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='19', item='RND.27.4995.7 RND Product 7 (lng-1)', quantity='8.00', id_delivery_unit='21', unit_price='11.1900', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='19', item='RND.80.1449.39 RND Product 39 (lng-1)', quantity='6.00', id_delivery_unit='4', unit_price='40.7500', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 19
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 19
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 19
;;
update srkt_invoices set price_total_excl_vat='410.46', price_total_incl_vat='492.58' where id=19;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 19
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 19
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 19
;;
update srkt_orders set state='2', id_invoice='19' where id=35;;
update srkt_orders set state='2' where id=35;;
insert into `srkt_orders_history` set `id`=null, id_order='35', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='35', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 34
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 34
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='36';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 13
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 13
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='36', id_product='13', quantity='8', unit_price='13.6500', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 21
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 21
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='36', id_product='21', quantity='8', unit_price='13.3400', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 9
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 9
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='36', id_product='9', quantity='5', unit_price='40.8100', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 46
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 46
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='36', id_product='46', quantity='7', unit_price='15.0400', added_on='2021-11-23 13:22:41';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 34
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 34
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-11-20 13:22:41')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-11-20 13:22:41')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('211120', lpad(@serial_number, 4, '0'))
      ), id_customer='34', id_customer_uid='36', del_given_name='Steven', del_family_name='White', del_company_name='', del_street_1='3174  Boggess Street', del_street_2='', del_floor='', del_city='Hillsboro', del_zip='45133', del_country='Ohio', inv_given_name='Steven', inv_family_name='White', inv_company_name='', inv_street_1='3174  Boggess Street', inv_street_2='', inv_city='Hillsboro', inv_zip='45133', inv_region='', inv_country='Ohio', confirmation_time='2021-11-20 13:22:41', id_delivery_service='4', id_payment_service='1', id_destination_country='4', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='36', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='36', id_product='13', quantity='8', id_delivery_unit='17', unit_price='13.6500', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='36', id_product='21', quantity='8', id_delivery_unit='3', unit_price='13.3400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='36', id_product='9', quantity='5', id_delivery_unit='16', unit_price='40.8100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='36', id_product='46', quantity='7', id_delivery_unit='17', unit_price='15.0400', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 36
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 36
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 34
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=36;;
update srkt_orders set price_total_excl_vat='525.25', price_total_incl_vat='630.32', weight_total='41723' where id=36;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 2
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 2
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='37';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 38
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 38
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='37', id_product='38', quantity='9', unit_price='12.2200', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 24
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 24
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='37', id_product='24', quantity='4', unit_price='31.3100', added_on='2021-11-23 13:22:41';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 2
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 2
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-02-25 13:22:41')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-02-25 13:22:41')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210225', lpad(@serial_number, 4, '0'))
      ), id_customer='2', id_customer_uid='37', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-02-25 13:22:41', id_delivery_service='4', id_payment_service='2', id_destination_country='3', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='37', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='37', id_product='38', quantity='9', id_delivery_unit='17', unit_price='12.2200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='37', id_product='24', quantity='4', id_delivery_unit='8', unit_price='31.3100', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 37
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 37
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 2
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=37;;
update srkt_orders set price_total_excl_vat='235.22', price_total_incl_vat='282.22', weight_total='18630' where id=37;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 37
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 37
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 2
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 2
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-02-25 13:22:41')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-02-25 13:22:41')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210225', lpad(@serial_number, 4, '0'))
      ), id_customer='2', id_order='37', customer_street_1='728  Nelm Street', customer_street_2='', customer_city='Leesburg', customer_zip='20176', customer_country='Virginia', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-02-25 13:22:41', delivery_time='2021-02-25 13:22:41', payment_due_time='2021-11-23 13:22:41', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2102250031', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='20', item='RND.86.7529.37 RND Product 37 (lng-1)', quantity='9.00', id_delivery_unit='17', unit_price='12.2200', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='20', item='RND.31.1313.23 RND Product 23 (lng-1)', quantity='4.00', id_delivery_unit='8', unit_price='31.3100', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 20
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 20
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 20
;;
update srkt_invoices set price_total_excl_vat='235.22', price_total_incl_vat='282.22' where id=20;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 20
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 20
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 20
;;
update srkt_orders set state='2', id_invoice='20' where id=37;;
update srkt_orders set state='2' where id=37;;
insert into `srkt_orders_history` set `id`=null, id_order='37', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='37', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 7
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 7
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='38';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 11
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 11
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='38', id_product='11', quantity='10', unit_price='26.8100', added_on='2021-11-23 13:22:41';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 28
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 28
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='38', id_product='28', quantity='3', unit_price='5.3400', added_on='2021-11-23 13:22:42';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 7
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 7
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-05-31 13:22:42')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-05-31 13:22:42')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210531', lpad(@serial_number, 4, '0'))
      ), id_customer='7', id_customer_uid='38', del_given_name='Christine', del_family_name='Duffy', del_company_name='', del_street_1='728  Nelm Street', del_street_2='', del_floor='', del_city='Leesburg', del_zip='20176', del_country='Virginia', inv_given_name='Christine', inv_family_name='Duffy', inv_company_name='', inv_street_1='728  Nelm Street', inv_street_2='', inv_city='Leesburg', inv_zip='20176', inv_region='', inv_country='Virginia', confirmation_time='2021-05-31 13:22:42', id_delivery_service='4', id_payment_service='1', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='38', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='38', id_product='11', quantity='10', id_delivery_unit='19', unit_price='26.8100', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='38', id_product='28', quantity='3', id_delivery_unit='9', unit_price='5.3400', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 38
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 38
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 7
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 1
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=38;;
update srkt_orders set price_total_excl_vat='284.12', price_total_incl_vat='340.93', weight_total='10973' where id=38;;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 28
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 28
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='39';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 4
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 4
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='39', id_product='4', quantity='10', unit_price='33.6400', added_on='2021-11-23 13:22:42';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 16
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 16
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='39', id_product='16', quantity='6', unit_price='19.0200', added_on='2021-11-23 13:22:42';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 43
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 43
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='39', id_product='43', quantity='5', unit_price='17.4800', added_on='2021-11-23 13:22:42';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 28
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 28
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-10-31 13:22:42')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-10-31 13:22:42')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('211031', lpad(@serial_number, 4, '0'))
      ), id_customer='28', id_customer_uid='39', del_given_name='Carol', del_family_name='Quinn', del_company_name='', del_street_1='2967  Stratford Drive', del_street_2='', del_floor='', del_city='Waipahu', del_zip='96797', del_country='Hawaii', inv_given_name='Carol', inv_family_name='Quinn', inv_company_name='', inv_street_1='2967  Stratford Drive', inv_street_2='', inv_city='Waipahu', inv_zip='96797', inv_region='', inv_country='Hawaii', confirmation_time='2021-10-31 13:22:42', id_delivery_service='3', id_payment_service='3', id_destination_country='1', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-sk';;
insert into `srkt_orders_history` set `id`=null, id_order='39', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='39', id_product='4', quantity='10', id_delivery_unit='8', unit_price='33.6400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='39', id_product='16', quantity='6', id_delivery_unit='11', unit_price='19.0200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='39', id_product='43', quantity='5', id_delivery_unit='14', unit_price='17.4800', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 39
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 39
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 28
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=39;;
update srkt_orders set price_total_excl_vat='537.92', price_total_incl_vat='645.52', weight_total='33767' where id=39;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 39
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 39
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 28
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 3
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-10-31 13:22:42')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-10-31 13:22:42')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('211031', lpad(@serial_number, 4, '0'))
      ), id_customer='28', id_order='39', customer_street_1='2967  Stratford Drive', customer_street_2='', customer_city='Waipahu', customer_zip='96797', customer_country='Hawaii', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-10-31 13:22:42', delivery_time='2021-10-31 13:22:42', payment_due_time='2021-11-23 13:22:42', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2110310033', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='21', item='RND.80.8246.3 RND Product 3 (lng-1)', quantity='10.00', id_delivery_unit='8', unit_price='33.6400', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='21', item='RND.91.8184.15 RND Product 15 (lng-1)', quantity='6.00', id_delivery_unit='11', unit_price='19.0200', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='21', item='RND.27.9906.42 RND Product 42 (lng-1)', quantity='5.00', id_delivery_unit='14', unit_price='17.4800', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 21
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 21
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 21
;;
update srkt_invoices set price_total_excl_vat='537.92', price_total_incl_vat='645.52' where id=21;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 21
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 21
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 21
;;
update srkt_orders set state='2', id_invoice='21' where id=39;;
update srkt_orders set state='2' where id=39;;
insert into `srkt_orders_history` set `id`=null, id_order='39', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='39', id_tag='2';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 50
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 50
;;
insert into `srkt_shopping_carts` set `id`=null, id_customer_uid='40';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 10
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 10
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='40', id_product='10', quantity='4', unit_price='33.4900', added_on='2021-11-23 13:22:42';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 4
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 4
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='40', id_product='4', quantity='6', unit_price='33.6400', added_on='2021-11-23 13:22:42';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 32
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 32
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='40', id_product='32', quantity='3', unit_price='35.7200', added_on='2021-11-23 13:22:42';;

            select
              *
            from `srkt_products_variations_groups_items`
            where `id_product` = 48
;;

              select
                *
              from `srkt_products_variations`
              where `id_product` = 48
;;
insert into `srkt_shopping_carts_items` set `id`=null, id_shopping_cart='40', id_product='48', quantity='6', unit_price='10.2200', added_on='2021-11-23 13:22:42';;

      select
        c.*,
        (
          select
            group_concat(uid)
          from srkt_customers_uid
          where id_customer = c.id
        ) as pridelene_uid_identifikatory
      from `srkt_customers` c
      where `id` = 50
;;

        select
          *
        from srkt_customers_addresses
        where `id_customer` = 50
;;
insert into `srkt_orders` set `id`=null, `accounting_year` = (year('2021-07-30 13:22:42')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`o`.`serial_number`), 0)
            from `srkt_orders` o
            where year(`o`.`confirmation_time`) = year('2021-07-30 13:22:42')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210730', lpad(@serial_number, 4, '0'))
      ), id_customer='50', id_customer_uid='40', del_given_name='Miriam', del_family_name='Evans', del_company_name='', del_street_1='2313  Horner Street', del_street_2='', del_floor='', del_city='Montgomery', del_zip='36107', del_country='Alabama', inv_given_name='Miriam', inv_family_name='Evans', inv_company_name='', inv_street_1='2313  Horner Street', inv_street_2='', inv_city='Montgomery', inv_zip='36107', inv_region='', inv_country='Alabama', confirmation_time='2021-07-30 13:22:42', id_delivery_service='4', id_payment_service='3', id_destination_country='2', state='1', phone_number='+1 123 456 789', email='example@email.com', domain='language-cz';;
insert into `srkt_orders_history` set `id`=null, id_order='40', state='1', `event_time` = (now());;
insert into `srkt_orders_items` set `id`=null, id_order='40', id_product='10', quantity='4', id_delivery_unit='4', unit_price='33.4900', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='40', id_product='4', quantity='6', id_delivery_unit='8', unit_price='33.6400', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='40', id_product='32', quantity='3', id_delivery_unit='7', unit_price='35.7200', vat_percent='20';;
insert into `srkt_orders_items` set `id`=null, id_order='40', id_product='48', quantity='6', id_delivery_unit='7', unit_price='10.2200', vat_percent='20';;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 40
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 40
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 50
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
update srkt_orders set delivery_fee='0', payment_fee='0' where id=40;;
update srkt_orders set price_total_excl_vat='504.28', price_total_incl_vat='605.12', weight_total='27935' where id=40;;

      select
        obj.*
      from srkt_orders obj
      where obj.id = 40
;;

        select
          i.*,
          p.number as product_number,
          p.weight as product_weight,
          p.name_lang_1 as product_name
        from `srkt_orders_items` i
        left join `srkt_products` p on p.id = i.id_product
        where i.id_order = 40
;;

        select
          k.*
        from `srkt_customers` k
        where k.id = 50
;;

        select
          f.*
        from `srkt_invoices` f
        where f.id = 0
;;

        select
          ds.*
        from `srkt_shipping_delivery_services` ds
        where ds.id = 4
;;

        select
          ps.*
        from `srkt_shipping_payment_services` ps
        where ps.id = 3
;;
insert into `srkt_invoices` set `id`=null, `accounting_year` = (year('2021-07-30 13:22:42')), `serial_number` = (
        @serial_number := (ifnull(
          (
            select
              ifnull(max(`i`.`serial_number`), 0)
            from `srkt_invoices` `i`
            where year(`i`.`issue_time`) = year('2021-07-30 13:22:42')
          ),
          0
        ) + 1)
      ), `number` = (
        @number := concat('210730', lpad(@serial_number, 4, '0'))
      ), id_customer='50', id_order='40', customer_street_1='2313  Horner Street', customer_street_2='', customer_city='Montgomery', customer_zip='36107', customer_country='Alabama', customer_company_id='', customer_company_tax_id='', customer_company_vat_id='', customer_email='example@email.com', customer_phone='+1 123 456 789', supplier_name='MyCompany ltd.', supplier_street_1='Brandenburgische Straße 81', supplier_city='Berlin', supplier_zip='10119', supplier_country='Germany', supplier_company_id='123456789', supplier_company_tax_id='9988776655', supplier_company_vat_id='DE9988776655', supplier_email='info@mycompany.sk', supplier_phone='030 55 61562', issue_time='2021-07-30 13:22:42', delivery_time='2021-07-30 13:22:42', payment_due_time='2021-11-23 13:22:42', `variable_symbol` = (@number), constant_symbol='0008', payment_method='1', order_number='2107300034', state='1';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='22', item='RND.89.7964.9 RND Product 9 (lng-1)', quantity='4.00', id_delivery_unit='4', unit_price='33.4900', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='22', item='RND.80.8246.3 RND Product 3 (lng-1)', quantity='6.00', id_delivery_unit='8', unit_price='33.6400', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='22', item='RND.65.5058.31 RND Product 31 (lng-1)', quantity='3.00', id_delivery_unit='7', unit_price='35.7200', vat_percent='20';;
insert into `srkt_invoices_items` set `id`=null, id_invoice='22', item='RND.96.1055.47 RND Product 47 (lng-1)', quantity='6.00', id_delivery_unit='7', unit_price='10.2200', vat_percent='20';;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 22
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 22
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 22
;;
update srkt_invoices set price_total_excl_vat='504.28', price_total_incl_vat='605.12' where id=22;;

      select
        fv.*
      from srkt_invoices fv
      where fv.id = 22
;;

        select
          o.*
        from srkt_orders o
        where o.id_invoice = 22
;;

        select
          p.*
        from srkt_invoices_items p
        where p.id_invoice = 22
;;
update srkt_orders set state='2', id_invoice='22' where id=40;;
update srkt_orders set state='2' where id=40;;
insert into `srkt_orders_history` set `id`=null, id_order='40', state='2', `event_time` = (now());;
insert into `srkt_orders_tags_assignment` set `id`=null, id_order='40', id_tag='3';;
insert into `srkt_web_menu` set `id`='101', domain='language-sk', name='Menu v hlavičke';;
insert into `srkt_web_menu_items` set `id`=null, id_menu='101', title='Úvod', url='uvod', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_menu_items` set `id`=null, id_menu='101', title='O nás', url='o-nas', expand_product_categories = 0, id_parent='1';;
insert into `srkt_web_menu_items` set `id`=null, id_menu='101', title='Produkty', url='produkty', expand_product_categories = 1, id_parent=null;;
insert into `srkt_web_menu_items` set `id`=null, id_menu='101', title='Blog', url='blog', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_menu_items` set `id`=null, id_menu='101', title='Kontakt', url='contact', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_menu` set `id`='102', domain='language-sk', name='Menu v pätičke';;
insert into `srkt_web_menu_items` set `id`=null, id_menu='102', title='O nás', url='o-nas', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_menu_items` set `id`=null, id_menu='102', title='Kontakt', url='contact', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Úvod', url='uvod', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Misc\\/Slideshow\",\"settings\":{\"speed\":1000}},\"section_2\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"Vitajte\",\"headingLevel\":1,\"content\":\"Aliquam ultrices nisl nisi, sed semper elit ultrices in. Fusce blandit ligula a ex faucibus porttitor. Vivamus\\r\\npellentesque dolor in nisl blandit, fermentum sollicitudin felis porttitor. Etiam nibh justo, efficitur sit amet\\r\\nefficitur accumsan, tincidunt non elit. Duis semper purus vitae quam viverra, non ultrices elit viverra. Pellentesque\\r\\nhabitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam iaculis feugiat luctus.\\r\\nSuspendisse eget sodales ligula.\"}},\"section_3\":{\"plugin\":\"WAI\\/SimpleContent\\/H2\",\"settings\":{\"heading\":\"Odpor\\u00fa\\u010dame\"}},\"section_4\":{\"plugin\":\"WAI\\/Product\\/FilteredList\",\"settings\":{\"filterType\":\"recommended\",\"layout\":\"tiles\",\"product_count\":6}},\"section_5\":{\"plugin\":\"WAI\\/SimpleContent\\/TwoColumns\",\"settings\":{\"column1Content\":\"Aliquam ultrices nisl nisi, sed semper elit ultrices in. Fusce blandit ligula a ex faucibus porttitor. Vivamus\\r\\npellentesque dolor in nisl blandit, fermentum sollicitudin felis porttitor. Etiam nibh justo, efficitur sit amet\\r\\nefficitur accumsan, tincidunt non elit. Duis semper purus vitae quam viverra, non ultrices elit viverra. Pellentesque\\r\\nhabitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam iaculis feugiat luctus.\\r\\nSuspendisse eget sodales ligula.\",\"column1Width\":4,\"column2Content\":\"Nam ligula eros, vestibulum sed sem sed, interdum molestie elit. Morbi fringilla leo augue, ut ultricies enim\\r\\ncondimentum nec. Duis ac pharetra tellus, ac pellentesque risus. Integer varius dictum sapien in venenatis. Sed varius\\r\\nsapien tincidunt faucibus ultrices. Curabitur bibendum lorem vel urna vulputate dignissim. Nam sed orci lobortis,\\r\\nplacerat neque eu, tempus purus. Sed sit amet erat vitae nisi hendrerit tincidunt et nec odio. Nam ac ex nec libero\\r\\nvenenatis consectetur ut a felis. Nam malesuada, dui eu aliquam elementum, lacus risus congue orci, eu varius dui enim\\r\\nat nibh. Praesent commodo felis luctus iaculis sodales. Ut ac blandit quam, a convallis risus.\",\"column2Width\":8,\"column2CSSClasses\":\"text-right\"}},\"section_6\":{\"plugin\":\"WAI\\/SimpleContent\\/H2\",\"settings\":{\"heading\":\"Z\\u013eava\"}},\"section_7\":{\"plugin\":\"WAI\\/Product\\/FilteredList\",\"settings\":{\"filterType\":\"on_sale\",\"layout\":\"tiles\",\"product_count\":6}},\"section_8\":{\"plugin\":\"WAI\\/SimpleContent\\/TwoColumns\",\"settings\":{\"column1Content\":\"Nam ligula eros, vestibulum sed sem sed, interdum molestie elit. Morbi fringilla leo augue, ut ultricies enim\\r\\ncondimentum nec. Duis ac pharetra tellus, ac pellentesque risus. Integer varius dictum sapien in venenatis. Sed varius\\r\\nsapien tincidunt faucibus ultrices. Curabitur bibendum lorem vel urna vulputate dignissim. Nam sed orci lobortis,\\r\\nplacerat neque eu, tempus purus. Sed sit amet erat vitae nisi hendrerit tincidunt et nec odio. Nam ac ex nec libero\\r\\nvenenatis consectetur ut a felis. Nam malesuada, dui eu aliquam elementum, lacus risus congue orci, eu varius dui enim\\r\\nat nibh. Praesent commodo felis luctus iaculis sodales. Ut ac blandit quam, a convallis risus.\",\"column1Width\":8,\"column2Content\":\"Aliquam ultrices nisl nisi, sed semper elit ultrices in. Fusce blandit ligula a ex faucibus porttitor. Vivamus\\r\\npellentesque dolor in nisl blandit, fermentum sollicitudin felis porttitor. Etiam nibh justo, efficitur sit amet\\r\\nefficitur accumsan, tincidunt non elit. Duis semper purus vitae quam viverra, non ultrices elit viverra. Pellentesque\\r\\nhabitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam iaculis feugiat luctus.\\r\\nSuspendisse eget sodales ligula.\",\"column2Width\":4,\"column2CSSClasses\":\"text-right\"}}}}', publish_always = 1, seo_title='Úvod', seo_description='Úvod';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='O nás', url='o-nas', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"O n\\u00e1s\",\"content\":\"<b>Lorem Ipsum is simply dummy text<\\/b> of the printing and typesetting industry.\\r\\nLorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\\r\\nwhen an unknown printer took a galley of type and scrambled it to make a type\\r\\nspecimen book. It has survived not only five centuries, but also the leap into\\r\\nelectronic typesetting, remaining essentially unchanged. It was popularised in\\r\\nthe 1960s with the release of Letraset sheets containing Lorem Ipsum passages,\\r\\nand more recently with desktop publishing software like Aldus PageMaker including\\r\\nversions of Lorem Ipsum.\"}},\"section_2\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"Vitajte\",\"content\":\"<b>Lorem Ipsum is simply dummy text<\\/b> of the printing and typesetting industry.\\r\\nLorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\\r\\nwhen an unknown printer took a galley of type and scrambled it to make a type\\r\\nspecimen book. It has survived not only five centuries, but also the leap into\\r\\nelectronic typesetting, remaining essentially unchanged. It was popularised in\\r\\nthe 1960s with the release of Letraset sheets containing Lorem Ipsum passages,\\r\\nand more recently with desktop publishing software like Aldus PageMaker including\\r\\nversions of Lorem Ipsum.\"}}}}', publish_always = 1, seo_title='O nás', seo_description='O nás';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Kontakt', url='contact', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"\",\"content\":\"<div class=\\\"contact-area\\\" style=\\\"width: 100%\\\">\\r\\n  <div class=\\\"container\\\">\\r\\n    <div class=\\\"custom-row-2\\\">\\r\\n      <div class=\\\"col-lg-6 col-md-12\\\">\\r\\n        <div class=\\\"contact-info-wrap\\\">\\r\\n          <div class=\\\"row\\\">\\r\\n            <div class=\\\"col-12\\\">\\r\\n              <h1>Kontakt<\\/h1>\\r\\n            <\\/div>\\r\\n            <div class=\\\"col-12 col-md-6 col-lg-6\\\">\\r\\n              <div class=\\\"single-contact-info\\\">\\r\\n                <div class=\\\"contact-icon\\\">\\r\\n                  <i class=\\\"ion-android-call\\\"><\\/i>\\r\\n                <\\/div>\\r\\n                <div class=\\\"contact-info-dec\\\">\\r\\n                  <p><a href=\\\"tel:\\/\\/+421 908 897 149\\\">+421 908 897 149<\\/a><\\/p>\\r\\n                <\\/div>\\r\\n              <\\/div>\\r\\n            <\\/div>\\r\\n            <div class=\\\"col-12 col-md-6 col-lg-6\\\">\\r\\n              <div class=\\\"single-contact-info\\\">\\r\\n                <div class=\\\"contact-icon\\\">\\r\\n                  <i class=\\\"ion-android-globe\\\"><\\/i>\\r\\n                <\\/div>\\r\\n                <div class=\\\"contact-info-dec\\\">\\r\\n                  <p><a href=\\\"mailto:\\/\\/info@surikata.io\\\">info@surikata.io<\\/a><\\/p>\\r\\n                <\\/div>\\r\\n              <\\/div>\\r\\n            <\\/div>\\r\\n            <div class=\\\"col-12\\\">\\r\\n              <div class=\\\"single-contact-info\\\">\\r\\n                <div class=\\\"contact-icon\\\">\\r\\n                  <i class=\\\"ion-android-pin\\\"><\\/i>\\r\\n                <\\/div>\\r\\n                <div class=\\\"contact-info-dec\\\">\\r\\n                  <p>WAI s.r.o<br\\/>\\r\\n                    Sl\\u00e1dkovi\\u010dova 10<br\\/>\\r\\n                    921 01 Pie\\u0161\\u0165any<\\/p>\\r\\n                <\\/div>\\r\\n              <\\/div>\\r\\n            <\\/div>\\r\\n          <\\/div>\\r\\n          <div class=\\\"contact-social\\\">\\r\\n            <h3>Sledujte n\\u00e1s<\\/h3>\\r\\n            <div class=\\\"social-info\\\">\\r\\n              <ul>\\r\\n                <li>\\r\\n                  <a href=\\\"#\\\"><i class=\\\"ion-social-facebook\\\"><\\/i><\\/a>\\r\\n                <\\/li>\\r\\n                <li>\\r\\n                  <a href=\\\"#\\\"><i class=\\\"ion-social-youtube\\\"><\\/i><\\/a>\\r\\n                <\\/li>\\r\\n                <li>\\r\\n                  <a href=\\\"#\\\"><i class=\\\"ion-social-instagram\\\"><\\/i><\\/a>\\r\\n                <\\/li>\\r\\n              <\\/ul>\\r\\n            <\\/div>\\r\\n          <\\/div>\\r\\n        <\\/div>\\r\\n      <\\/div>\\r\\n      <div class=\\\"col-lg-6 col-md-9\\\">\\r\\n        <div class=\\\"contact-form\\\">\\r\\n          <div class=\\\"contact-title mb-30\\\">\\r\\n            <h2>Nechajte n\\u00e1m spr\\u00e1vu<\\/h2>\\r\\n          <\\/div>\\r\\n          <form class=\\\"contact-form-style\\\" id=\\\"contact-form\\\" onsubmit=\\\"return false;\\\" method=\\\"post\\\">\\r\\n            <div class=\\\"row\\\">\\r\\n              <div class=\\\"col-lg-6\\\">\\r\\n                <input name=\\\"name\\\" placeholder=\\\"Meno*\\\" type=\\\"text\\\" onblur=\\\"validateInputs(this)\\\"\\/>\\r\\n              <\\/div>\\r\\n              <div class=\\\"col-lg-6\\\">\\r\\n                <input name=\\\"email\\\" placeholder=\\\"Email*\\\" type=\\\"email\\\" onblur=\\\"validateInputs(this)\\\"\\/>\\r\\n              <\\/div>\\r\\n              <div class=\\\"col-lg-12\\\">\\r\\n                <input name=\\\"phone_number\\\" placeholder=\\\"Telef\\u00f3n*\\\" type=\\\"text\\\" onblur=\\\"validateInputs(this)\\\"\\/>\\r\\n              <\\/div>\\r\\n              <div class=\\\"col-lg-12\\\">\\r\\n                <textarea name=\\\"contact_message\\\" placeholder=\\\"Va\\u0161a spr\\u00e1va*\\\" onblur=\\\"validateInputs(this)\\\"><\\/textarea>\\r\\n                <button class=\\\"submit\\\" type=\\\"button\\\" onclick=\\\"sendContactForm(\'#contact-form\')\\\">Posla\\u0165 spr\\u00e1vu<\\/button>\\r\\n              <\\/div>\\r\\n            <\\/div>\\r\\n          <\\/form>\\r\\n          <p class=\\\"form-messege\\\"><\\/p>\\r\\n        <\\/div>\\r\\n      <\\/div>\\r\\n    <\\/div>\\r\\n    <div class=\\\"contact-map\\\">\\r\\n      <div id=\\\"map\\\">\\r\\n        <script async\\r\\n                src=\\\"https:\\/\\/maps.googleapis.com\\/maps\\/api\\/js?key=AIzaSyDf7R5KF87EYvZJHlrByQ6l2tdlcfYUuv0&callback=initMap\\\">\\r\\n        <\\/script>\\r\\n        <script>\\r\\n          let map;\\r\\n\\r\\n          function initMap() {\\r\\n            map = new google.maps.Map(document.getElementById(\'map\'), {\\r\\n              center: {lat: 48.5893312, lng: 17.8251578},\\r\\n              zoom: 15\\r\\n            });\\r\\n          }\\r\\n        <\\/script>\\r\\n      <\\/div>\\r\\n    <\\/div>\\r\\n  <\\/div>\\r\\n<\\/div>\"}}}}', publish_always = 1, seo_title='Kontakt', seo_description='Kontakt';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Hľadať', url='hladat', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Misc\\/WebsiteSearch\",\"settings\":{\"heading\":\"H\\u013eada\\u0165\",\"numberOfResults\":10,\"searchInProducts\":\"name_lang,brief_lang,description_lang\",\"searchInProductCategories\":\"name_lang\",\"searchInBlogs\":\"name,content\"}}}}', publish_always = 1, seo_title='Hľadať', seo_description='Hľadať';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Produkty', url='produkty', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"sidebar\":{\"plugin\":\"WAI\\/Product\\/Filter\",\"settings\":{\"showProductCategories\":1,\"layout\":\"sidebar\",\"showBrands\":1,\"showFeaturesFilter\":1}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/Product\\/Catalog\",\"settings\":{\"defaultItemsPerPage\":6}}}}', publish_always = 1, seo_title='Produkty', seo_description='Produkty';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Odporúčame', url='odporucame', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/SimpleContent\\/H2\",\"settings\":{\"heading\":\"Z\\u013eavy\"}},\"section_3\":{\"plugin\":\"WAI\\/Product\\/FilteredList\",\"settings\":{\"filterType\":\"on_sale\",\"layout\":\"tiles\",\"product_count\":99}},\"section_4\":{\"plugin\":\"WAI\\/SimpleContent\\/H2\",\"settings\":{\"heading\":\"V\\u00fdpredaj\"}},\"section_5\":{\"plugin\":\"WAI\\/Product\\/FilteredList\",\"settings\":{\"filterType\":\"sale_out\",\"layout\":\"tiles\",\"product_count\":99}}}}', publish_always = 1, seo_title='Odporúčame', seo_description='Odporúčame';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Detail produktu', url='', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/Product\\/Detail\",\"settings\":{\"show_similar_products\":1,\"show_accessories\":1,\"showAuthor\":1}}}}', publish_always = 1, seo_title='Detail produktu', seo_description='Detail produktu';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Košík', url='kosik', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Order\\/CartOverview\"}}}', publish_always = 1, seo_title='Košík', seo_description='Košík';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Objednať', url='objednat', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Order\\/Checkout\"}}}', publish_always = 1, seo_title='Objednať', seo_description='Objednať';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Potvrdenie objednávky', url='', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Order\\/Confirmation\"}}}', publish_always = 1, seo_title='Potvrdenie objednávky', seo_description='Potvrdenie objednávky';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Order payment received', url='', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Order\\/PaymentConfirmation\"}}}', publish_always = 1, seo_title='Order payment received', seo_description='Order payment received';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Vytvoriť účet', url='vytvorit-ucet', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/Registration\",\"settings\":{\"showPrivacyTerms\":1,\"privacyTermsUrl\":\"privacy-terms\"}}}}', publish_always = 1, seo_title='Vytvoriť účet', seo_description='Vytvoriť účet';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Vytvoriť účet - Potvrdenie', url='vytvorit-ucet/potvrdenie', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/RegistrationConfirmation\"}}}', publish_always = 1, seo_title='Vytvoriť účet - Potvrdenie', seo_description='Vytvoriť účet - Potvrdenie';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Môj účet - Overenie', url='', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/ValidationConfirmation\"}}}', publish_always = 1, seo_title='Môj účet - Overenie', seo_description='Môj účet - Overenie';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Obnoviť heslo', url='obnovit-heslo', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/ForgotPassword\"}}}', publish_always = 1, seo_title='Obnoviť heslo', seo_description='Obnoviť heslo';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Môj účet', url='moj-ucet', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/Home\"}}}', publish_always = 1, seo_title='Môj účet', seo_description='Môj účet';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Môj účet - Objednávky', url='moj-ucet/objednavky', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/OrderList\"}}}', publish_always = 1, seo_title='Môj účet - Objednávky', seo_description='Môj účet - Objednávky';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Môj účet - Prihlásenie', url='prihlasenie', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/Login\",\"settings\":{\"showPrivacyTerms\":1,\"privacyTermsUrl\":\"privacy-terms\"}}}}', publish_always = 1, seo_title='Môj účet - Prihlásenie', seo_description='Môj účet - Prihlásenie';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Ochrana osobných údajov', url='ochrana-osobnych-udajov', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"section_1\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"Pravidl\\u00e1 ochrany osobn\\u00fdch \\u00fadajov\",\"content\":\"<b>Lorem Ipsum is simply dummy text<\\/b> of the printing and typesetting industry.\\r\\nLorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\\r\\nwhen an unknown printer took a galley of type and scrambled it to make a type\\r\\nspecimen book. It has survived not only five centuries, but also the leap into\\r\\nelectronic typesetting, remaining essentially unchanged. It was popularised in\\r\\nthe 1960s with the release of Letraset sheets containing Lorem Ipsum passages,\\r\\nand more recently with desktop publishing software like Aldus PageMaker including\\r\\nversions of Lorem Ipsum.\"}}}}', publish_always = 1, seo_title='Ochrana osobných údajov', seo_description='Ochrana osobných údajov';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Novinky', url='novinky', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"sidebar\":{\"plugin\":\"WAI\\/News\",\"settings\":{\"contentType\":\"sidebar\"}},\"section_1\":{\"plugin\":\"WAI\\/News\",\"settings\":{\"contentType\":\"listOrDetail\"}}}}', publish_always = 1, seo_title='Novinky', seo_description='Novinky';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Blog', url='blog', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"sidebar\":{\"plugin\":\"WAI\\/Blog\\/Sidebar\",\"settings\":{\"showRecent\":1,\"showArchive\":1,\"showAdvertising\":1}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/Blog\\/Catalog\",\"settings\":{\"itemsPerPage\":3,\"showAuthor\":1}}}}', publish_always = 1, seo_title='Blog', seo_description='Blog';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Blog', url='', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"sidebar\":{\"plugin\":\"WAI\\/Blog\\/Sidebar\",\"settings\":{\"showRecent\":1,\"showArchive\":1,\"showAdvertising\":1}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/Blog\\/Detail\"}}}', publish_always = 1, seo_title='Blog', seo_description='Blog';;
insert into `srkt_web_redirects` set `id`=null, domain='language-sk', from_url='', to_url='//{% SERVER_HTTP_HOST %}{% REWRITE_BASE %}sk/uvod', type='302';;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/companyInfo/slogan',
              `value` = 'Môj nový eshop: language-sk'
            on duplicate key update
              `path` = 'settings/web/language-sk/companyInfo/slogan',
              `value` = 'Môj nový eshop: language-sk'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/companyInfo/contactPhoneNumber',
              `value` = '+421 111 222 333'
            on duplicate key update
              `path` = 'settings/web/language-sk/companyInfo/contactPhoneNumber',
              `value` = '+421 111 222 333'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/companyInfo/contactEmail',
              `value` = 'info@{% SERVER_HTTP_HOST %}'
            on duplicate key update
              `path` = 'settings/web/language-sk/companyInfo/contactEmail',
              `value` = 'info@{% SERVER_HTTP_HOST %}'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/companyInfo/logo',
              `value` = 'your-logo.png'
            on duplicate key update
              `path` = 'settings/web/language-sk/companyInfo/logo',
              `value` = 'your-logo.png'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/companyInfo/urlFacebook',
              `value` = 'https://surikata.io'
            on duplicate key update
              `path` = 'settings/web/language-sk/companyInfo/urlFacebook',
              `value` = 'https://surikata.io'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/companyInfo/urlTwitter',
              `value` = 'https://surikata.io'
            on duplicate key update
              `path` = 'settings/web/language-sk/companyInfo/urlTwitter',
              `value` = 'https://surikata.io'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/companyInfo/urlYouTube',
              `value` = 'https://surikata.io'
            on duplicate key update
              `path` = 'settings/web/language-sk/companyInfo/urlYouTube',
              `value` = 'https://surikata.io'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/companyInfo/urlInstagram',
              `value` = 'https://surikata.io'
            on duplicate key update
              `path` = 'settings/web/language-sk/companyInfo/urlInstagram',
              `value` = 'https://surikata.io'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/themeMainColor',
              `value` = '#17C3B2'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/themeMainColor',
              `value` = '#17C3B2'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/themeSecondColor',
              `value` = '#222222'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/themeSecondColor',
              `value` = '#222222'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/themeThirdColor',
              `value` = '#FE6D73'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/themeThirdColor',
              `value` = '#FE6D73'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/themeGreyColor',
              `value` = '#888888'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/themeGreyColor',
              `value` = '#888888'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/themeLightGreyColor',
              `value` = '#f5f5f5'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/themeLightGreyColor',
              `value` = '#f5f5f5'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/bodyBgColor',
              `value` = '#ffffff'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/bodyBgColor',
              `value` = '#ffffff'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/bodyTextColor',
              `value` = '#333333'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/bodyTextColor',
              `value` = '#333333'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/bodyLinkColor',
              `value` = '#17C3B2'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/bodyLinkColor',
              `value` = '#17C3B2'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/bodyHeadingColor',
              `value` = '#333333'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/bodyHeadingColor',
              `value` = '#333333'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/headerBgColor',
              `value` = '#000000'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/headerBgColor',
              `value` = '#000000'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/headerTextColor',
              `value` = '#333333'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/headerTextColor',
              `value` = '#333333'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/headerLinkColor',
              `value` = '#17C3B2'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/headerLinkColor',
              `value` = '#17C3B2'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/headerHeadingColor',
              `value` = '#ffffff'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/headerHeadingColor',
              `value` = '#ffffff'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/footerBgColor',
              `value` = '#222222'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/footerBgColor',
              `value` = '#222222'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/footerTextColor',
              `value` = '#f8f1e4'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/footerTextColor',
              `value` = '#f8f1e4'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/footerLinkColor',
              `value` = '#17C3B2'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/footerLinkColor',
              `value` = '#17C3B2'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/footerHeadingColor',
              `value` = '#ffffff'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/footerHeadingColor',
              `value` = '#ffffff'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/custom_css',
              `value` = '\r\n        li.slideshow-basic {\r\n          background: rgb(29,6,7);\r\n          background: linear-gradient(180deg, rgba(29,6,7,1) 0%, rgba(29,6,7,0.75) 15%, rgba(73,18,18,0.6) 35%, rgba(156,36,38,0) 100%);\r\n        }\r\n        .rslides {\r\n          background: #000;\r\n        }\r\n      '
            on duplicate key update
              `path` = 'settings/web/language-sk/design/custom_css',
              `value` = '\r\n        li.slideshow-basic {\r\n          background: rgb(29,6,7);\r\n          background: linear-gradient(180deg, rgba(29,6,7,1) 0%, rgba(29,6,7,0.75) 15%, rgba(73,18,18,0.6) 35%, rgba(156,36,38,0) 100%);\r\n        }\r\n        .rslides {\r\n          background: #000;\r\n        }\r\n      '
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/theme',
              `value` = 'Basic'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/theme',
              `value` = 'Basic'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/headerMenuID',
              `value` = '101'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/headerMenuID',
              `value` = '101'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/design/footerMenuID',
              `value` = '102'
            on duplicate key update
              `path` = 'settings/web/language-sk/design/footerMenuID',
              `value` = '102'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/legalDisclaimers/generalTerms',
              `value` = 'Bienvenue. VOP!'
            on duplicate key update
              `path` = 'settings/web/language-sk/legalDisclaimers/generalTerms',
              `value` = 'Bienvenue. VOP!'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/legalDisclaimers/privacyPolicy',
              `value` = 'Bienvenue. OOU!'
            on duplicate key update
              `path` = 'settings/web/language-sk/legalDisclaimers/privacyPolicy',
              `value` = 'Bienvenue. OOU!'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/legalDisclaimers/returnPolicy',
              `value` = 'Bienvenue. RP!'
            on duplicate key update
              `path` = 'settings/web/language-sk/legalDisclaimers/returnPolicy',
              `value` = 'Bienvenue. RP!'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/emails/signature',
              `value` = '<p>language-sk - <a href=\'http://language-sk\' target=\'_blank\'>language-sk</a></p>'
            on duplicate key update
              `path` = 'settings/web/language-sk/emails/signature',
              `value` = '<p>language-sk - <a href=\'http://language-sk\' target=\'_blank\'>language-sk</a></p>'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/emails/after_order_confirmation_SUBJECT',
              `value` = 'Objednávka č. {% number %} - Surikata eshop'
            on duplicate key update
              `path` = 'settings/web/language-sk/emails/after_order_confirmation_SUBJECT',
              `value` = 'Objednávka č. {% number %} - Surikata eshop'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/emails/after_order_confirmation_BODY',
              `value` = '<h2>Potvrdenie objednávky</h2>\r\n<p>Vážený zákazník,</p>\r\n<p>Ďakujeme vám za váš nákup. Vašu objednávku <b>{% number %}</b></p>\r\n<p> sme zaregistrovali a vybavíme ju v čo najkratšom možno čase.</p>\r\n<h2>Detaily objednávky</h2>\r\n<h3>Fakturačná adresa</h3>\r\n<ul>\r\n  <li>Názov spoločnosti: {% invCompanyName %}</li>\r\n  <li>IČO: {% companyId %}</li>\r\n  <li>DIČ: {% companyTaxId %}</li>\r\n  <li>IČ DPH: {% companyVatId %}</li>\r\n  <li>Meno: {% invGivenName %}</li>\r\n  <li>Priezvisko: {% invFamilyName %}</li>\r\n  <li>Ulica 1: {% invStreet1 %}</li>\r\n  <li>Ulica 2: {% invStreet2 %}</li>\r\n  <li>Mesto: {% invCity %}</li>\r\n  <li>PSČ: {% invZip %}</li>\r\n</ul>\r\n<h3>Dodacia adresa</h3>\r\n<ul>\r\n  <li>Meno: {% delGivenName %}</li>\r\n  <li>Priezvisko: {% delFamilyName %}</li>\r\n  <li>Ulica 1: {% delStreet1 %}</li>\r\n  <li>Ulica 2: {% delStreet2 %}</li>\r\n  <li>Mesto: {% delCity %}</li>\r\n  <li>PSČ: {% delZip %}</li>\r\n  <li>Telefón: {% phoneNumber %}</li>\r\n  <li>Email: {% email %}</li>\r\n</ul>'
            on duplicate key update
              `path` = 'settings/web/language-sk/emails/after_order_confirmation_BODY',
              `value` = '<h2>Potvrdenie objednávky</h2>\r\n<p>Vážený zákazník,</p>\r\n<p>Ďakujeme vám za váš nákup. Vašu objednávku <b>{% number %}</b></p>\r\n<p> sme zaregistrovali a vybavíme ju v čo najkratšom možno čase.</p>\r\n<h2>Detaily objednávky</h2>\r\n<h3>Fakturačná adresa</h3>\r\n<ul>\r\n  <li>Názov spoločnosti: {% invCompanyName %}</li>\r\n  <li>IČO: {% companyId %}</li>\r\n  <li>DIČ: {% companyTaxId %}</li>\r\n  <li>IČ DPH: {% companyVatId %}</li>\r\n  <li>Meno: {% invGivenName %}</li>\r\n  <li>Priezvisko: {% invFamilyName %}</li>\r\n  <li>Ulica 1: {% invStreet1 %}</li>\r\n  <li>Ulica 2: {% invStreet2 %}</li>\r\n  <li>Mesto: {% invCity %}</li>\r\n  <li>PSČ: {% invZip %}</li>\r\n</ul>\r\n<h3>Dodacia adresa</h3>\r\n<ul>\r\n  <li>Meno: {% delGivenName %}</li>\r\n  <li>Priezvisko: {% delFamilyName %}</li>\r\n  <li>Ulica 1: {% delStreet1 %}</li>\r\n  <li>Ulica 2: {% delStreet2 %}</li>\r\n  <li>Mesto: {% delCity %}</li>\r\n  <li>PSČ: {% delZip %}</li>\r\n  <li>Telefón: {% phoneNumber %}</li>\r\n  <li>Email: {% email %}</li>\r\n</ul>'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/emails/after_registration_SUBJECT',
              `value` = 'Overte Vašu emailovú adresu - Surikata Eshop'
            on duplicate key update
              `path` = 'settings/web/language-sk/emails/after_registration_SUBJECT',
              `value` = 'Overte Vašu emailovú adresu - Surikata Eshop'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/emails/after_registration_BODY',
              `value` = '<h2>Ahoj {% givenName %}!</h2>\r\n<p><b>Kvôli bezpečnosti potrebujeme overiť vašu emailovú adresu, aby ste ju mohli použiť na našom eshope.</b></p>\r\n<p>Kliknite na odkaz nižšie alebo skopírujte a prejdite na url aby sme mohli overiť vašu identitu.</p>\r\n<p><a href=\"{% validationUrl %}\" target=\"_blank\">{% validationUrl %}</a></p>'
            on duplicate key update
              `path` = 'settings/web/language-sk/emails/after_registration_BODY',
              `value` = '<h2>Ahoj {% givenName %}!</h2>\r\n<p><b>Kvôli bezpečnosti potrebujeme overiť vašu emailovú adresu, aby ste ju mohli použiť na našom eshope.</b></p>\r\n<p>Kliknite na odkaz nižšie alebo skopírujte a prejdite na url aby sme mohli overiť vašu identitu.</p>\r\n<p><a href=\"{% validationUrl %}\" target=\"_blank\">{% validationUrl %}</a></p>'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/emails/forgotten_password_SUBJECT',
              `value` = 'Obnovenie hesla - Surikata eshop'
            on duplicate key update
              `path` = 'settings/web/language-sk/emails/forgotten_password_SUBJECT',
              `value` = 'Obnovenie hesla - Surikata eshop'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-sk/emails/forgotten_password_BODY',
              `value` = '<h2>Ahoj {% givenName %}!</h2>\r\n<p>Odkaz na obnovenie vášho hesla je nižšie.</p>\r\n<p><a href=\"{% passwordRecoveryUrl %}\" target=\"_blank\">{% passwordRecoveryUrl %}</a></p>'
            on duplicate key update
              `path` = 'settings/web/language-sk/emails/forgotten_password_BODY',
              `value` = '<h2>Ahoj {% givenName %}!</h2>\r\n<p>Odkaz na obnovenie vášho hesla je nižšie.</p>\r\n<p><a href=\"{% passwordRecoveryUrl %}\" target=\"_blank\">{% passwordRecoveryUrl %}</a></p>'
;;
start transaction;;
insert into `srkt_blogs_tags` set `id`='101', domain='language-sk', name='Počítače', `description` = 'Všetko o počítačoch';;
insert into `srkt_blogs_tags` set `id`='102', domain='language-sk', name='Biznis', `description` = 'Všetko o biznise';;
insert into `srkt_blogs_tags` set `id`='103', domain='language-sk', name='Móda', `description` = 'Všetko o móde';;
insert into `srkt_blogs` set `id`='101', domain='language-sk', name='Blog [language-sk] #1', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='101', id_tag='102';;
insert into `srkt_blogs` set `id`='102', domain='language-sk', name='Blog [language-sk] #2', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='102', id_tag='103';;
insert into `srkt_blogs` set `id`='103', domain='language-sk', name='Blog [language-sk] #3', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='103', id_tag='101';;
insert into `srkt_blogs` set `id`='104', domain='language-sk', name='Blog [language-sk] #4', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='104', id_tag='101';;
insert into `srkt_blogs` set `id`='105', domain='language-sk', name='Blog [language-sk] #5', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='105', id_tag='101';;
insert into `srkt_blogs` set `id`='106', domain='language-sk', name='Blog [language-sk] #6', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='106', id_tag='103';;
insert into `srkt_blogs` set `id`='107', domain='language-sk', name='Blog [language-sk] #7', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='107', id_tag='103';;
insert into `srkt_blogs` set `id`='108', domain='language-sk', name='Blog [language-sk] #8', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='108', id_tag='103';;
insert into `srkt_blogs` set `id`='109', domain='language-sk', name='Blog [language-sk] #9', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='109', id_tag='102';;
insert into `srkt_blogs` set `id`='110', domain='language-sk', name='Blog [language-sk] #10', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='110', id_tag='102';;
insert into `srkt_blogs` set `id`='111', domain='language-sk', name='Blog [language-sk] #11', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='111', id_tag='101';;
insert into `srkt_blogs` set `id`='112', domain='language-sk', name='Blog [language-sk] #12', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='112', id_tag='102';;
insert into `srkt_blogs` set `id`='113', domain='language-sk', name='Blog [language-sk] #13', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='113', id_tag='103';;
insert into `srkt_blogs` set `id`='114', domain='language-sk', name='Blog [language-sk] #14', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='114', id_tag='102';;
insert into `srkt_blogs` set `id`='115', domain='language-sk', name='Blog [language-sk] #15', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='115', id_tag='102';;
insert into `srkt_blogs` set `id`='116', domain='language-sk', name='Blog [language-sk] #16', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='116', id_tag='102';;
insert into `srkt_blogs` set `id`='117', domain='language-sk', name='Blog [language-sk] #17', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='117', id_tag='103';;
insert into `srkt_blogs` set `id`='118', domain='language-sk', name='Blog [language-sk] #18', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='118', id_tag='103';;
insert into `srkt_blogs` set `id`='119', domain='language-sk', name='Blog [language-sk] #19', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='119', id_tag='103';;
insert into `srkt_blogs` set `id`='120', domain='language-sk', name='Blog [language-sk] #20', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='120', id_tag='103';;
commit;;
insert into `srkt_homepage_slideshow` set `id`=null, domain='language-sk', heading='Vitajte', description='Váš najlepší eshop', button_url='produkty', button_text='Začať nakupovať', image='slide-1.jpg';;
insert into `srkt_homepage_slideshow` set `id`=null, domain='language-sk', heading='Zľavy', description='Máme pre vás zľavy', button_url='zlavy', button_text='Zobraziť zľavy', image='slide-2.jpg';;
insert into `srkt_homepage_slideshow` set `id`=null, domain='language-sk', heading='Skúste niečo extra', description='Predávame najlepšie produkty', image='slide-3.jpg';;
insert into `srkt_news` set `id`=null, title='Vitajte v našom eshope', `content` = 'Tento eshop sme vytvorili na platforme Surikata.io.', `perex` = 'Tento eshop sme vytvorili na platforme Surikata.io.', domain='language-sk';;
insert into `srkt_web_pages` set `id`=null, domain='language-sk', name='Porovnať produkty', url='porovnat', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":101,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":101,\"secondaryMenuId\":102,\"mainMenuTitle\":\"Str\\u00e1nky\",\"secondaryMenuTitle\":\"Na\\u0161a firma\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Kontaktujte n\\u00e1s\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Najnov\\u0161ie blogy\"}},\"sidebar\":{\"plugin\":\"WAI\\/Product\\/Filter\",\"settings\":{\"showProductCategories\":1,\"layout\":\"sidebar\",\"showBrands\":1,\"showFeaturesFilter\":1}},\"section_1\":{\"plugin\":\"WAI\\/Proprietary\\/Product\\/Compare\"}}}', publish_always = 1, seo_title='Porovnať produkty', seo_description='Porovnať produkty';;
insert into `srkt_web_menu` set `id`='201', domain='language-cz', name='Header Menu';;
insert into `srkt_web_menu_items` set `id`=null, id_menu='201', title='Úvod', url='uvod', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_menu_items` set `id`=null, id_menu='201', title='About us', url='about-us', expand_product_categories = 0, id_parent='8';;
insert into `srkt_web_menu_items` set `id`=null, id_menu='201', title='Products', url='products', expand_product_categories = 1, id_parent=null;;
insert into `srkt_web_menu_items` set `id`=null, id_menu='201', title='Blog', url='blog', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_menu_items` set `id`=null, id_menu='201', title='Contact', url='contact', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_menu` set `id`='202', domain='language-cz', name='Footer Menu';;
insert into `srkt_web_menu_items` set `id`=null, id_menu='202', title='About us', url='about-us', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_menu_items` set `id`=null, id_menu='202', title='Contact', url='contact', expand_product_categories = 0, id_parent=null;;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Úvod', url='uvod', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Misc\\/Slideshow\",\"settings\":{\"speed\":1000}},\"section_2\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"Welcome\",\"headingLevel\":1,\"content\":\"Aliquam ultrices nisl nisi, sed semper elit ultrices in. Fusce blandit ligula a ex faucibus porttitor. Vivamus\\r\\npellentesque dolor in nisl blandit, fermentum sollicitudin felis porttitor. Etiam nibh justo, efficitur sit amet\\r\\nefficitur accumsan, tincidunt non elit. Duis semper purus vitae quam viverra, non ultrices elit viverra. Pellentesque\\r\\nhabitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam iaculis feugiat luctus.\\r\\nSuspendisse eget sodales ligula.\"}},\"section_3\":{\"plugin\":\"WAI\\/SimpleContent\\/H2\",\"settings\":{\"heading\":\"We recommend\"}},\"section_4\":{\"plugin\":\"WAI\\/Product\\/FilteredList\",\"settings\":{\"filterType\":\"recommended\",\"layout\":\"tiles\",\"product_count\":6}},\"section_5\":{\"plugin\":\"WAI\\/SimpleContent\\/TwoColumns\",\"settings\":{\"column1Content\":\"Aliquam ultrices nisl nisi, sed semper elit ultrices in. Fusce blandit ligula a ex faucibus porttitor. Vivamus\\r\\npellentesque dolor in nisl blandit, fermentum sollicitudin felis porttitor. Etiam nibh justo, efficitur sit amet\\r\\nefficitur accumsan, tincidunt non elit. Duis semper purus vitae quam viverra, non ultrices elit viverra. Pellentesque\\r\\nhabitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam iaculis feugiat luctus.\\r\\nSuspendisse eget sodales ligula.\",\"column1Width\":4,\"column2Content\":\"Nam ligula eros, vestibulum sed sem sed, interdum molestie elit. Morbi fringilla leo augue, ut ultricies enim\\r\\ncondimentum nec. Duis ac pharetra tellus, ac pellentesque risus. Integer varius dictum sapien in venenatis. Sed varius\\r\\nsapien tincidunt faucibus ultrices. Curabitur bibendum lorem vel urna vulputate dignissim. Nam sed orci lobortis,\\r\\nplacerat neque eu, tempus purus. Sed sit amet erat vitae nisi hendrerit tincidunt et nec odio. Nam ac ex nec libero\\r\\nvenenatis consectetur ut a felis. Nam malesuada, dui eu aliquam elementum, lacus risus congue orci, eu varius dui enim\\r\\nat nibh. Praesent commodo felis luctus iaculis sodales. Ut ac blandit quam, a convallis risus.\",\"column2Width\":8,\"column2CSSClasses\":\"text-right\"}},\"section_6\":{\"plugin\":\"WAI\\/SimpleContent\\/H2\",\"settings\":{\"heading\":\"Discount\"}},\"section_7\":{\"plugin\":\"WAI\\/Product\\/FilteredList\",\"settings\":{\"filterType\":\"on_sale\",\"layout\":\"tiles\",\"product_count\":6}},\"section_8\":{\"plugin\":\"WAI\\/SimpleContent\\/TwoColumns\",\"settings\":{\"column1Content\":\"Nam ligula eros, vestibulum sed sem sed, interdum molestie elit. Morbi fringilla leo augue, ut ultricies enim\\r\\ncondimentum nec. Duis ac pharetra tellus, ac pellentesque risus. Integer varius dictum sapien in venenatis. Sed varius\\r\\nsapien tincidunt faucibus ultrices. Curabitur bibendum lorem vel urna vulputate dignissim. Nam sed orci lobortis,\\r\\nplacerat neque eu, tempus purus. Sed sit amet erat vitae nisi hendrerit tincidunt et nec odio. Nam ac ex nec libero\\r\\nvenenatis consectetur ut a felis. Nam malesuada, dui eu aliquam elementum, lacus risus congue orci, eu varius dui enim\\r\\nat nibh. Praesent commodo felis luctus iaculis sodales. Ut ac blandit quam, a convallis risus.\",\"column1Width\":8,\"column2Content\":\"Aliquam ultrices nisl nisi, sed semper elit ultrices in. Fusce blandit ligula a ex faucibus porttitor. Vivamus\\r\\npellentesque dolor in nisl blandit, fermentum sollicitudin felis porttitor. Etiam nibh justo, efficitur sit amet\\r\\nefficitur accumsan, tincidunt non elit. Duis semper purus vitae quam viverra, non ultrices elit viverra. Pellentesque\\r\\nhabitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nullam iaculis feugiat luctus.\\r\\nSuspendisse eget sodales ligula.\",\"column2Width\":4,\"column2CSSClasses\":\"text-right\"}}}}', publish_always = 1, seo_title='Úvod', seo_description='Úvod';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='About us', url='about-us', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"About us\",\"content\":\"<b>Lorem Ipsum is simply dummy text<\\/b> of the printing and typesetting industry.\\r\\nLorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\\r\\nwhen an unknown printer took a galley of type and scrambled it to make a type\\r\\nspecimen book. It has survived not only five centuries, but also the leap into\\r\\nelectronic typesetting, remaining essentially unchanged. It was popularised in\\r\\nthe 1960s with the release of Letraset sheets containing Lorem Ipsum passages,\\r\\nand more recently with desktop publishing software like Aldus PageMaker including\\r\\nversions of Lorem Ipsum.\"}},\"section_2\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"Welcome\",\"content\":\"<b>Lorem Ipsum is simply dummy text<\\/b> of the printing and typesetting industry.\\r\\nLorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\\r\\nwhen an unknown printer took a galley of type and scrambled it to make a type\\r\\nspecimen book. It has survived not only five centuries, but also the leap into\\r\\nelectronic typesetting, remaining essentially unchanged. It was popularised in\\r\\nthe 1960s with the release of Letraset sheets containing Lorem Ipsum passages,\\r\\nand more recently with desktop publishing software like Aldus PageMaker including\\r\\nversions of Lorem Ipsum.\"}}}}', publish_always = 1, seo_title='About us', seo_description='About us';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Contact', url='contact', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"\",\"content\":\"<div class=\\\"contact-area\\\" style=\\\"width: 100%\\\">\\r\\n  <div class=\\\"container\\\">\\r\\n    <div class=\\\"custom-row-2\\\">\\r\\n      <div class=\\\"col-lg-6 col-md-12\\\">\\r\\n        <div class=\\\"contact-info-wrap\\\">\\r\\n          <div class=\\\"row\\\">\\r\\n            <div class=\\\"col-12\\\">\\r\\n              <h1>Kontakt<\\/h1>\\r\\n            <\\/div>\\r\\n            <div class=\\\"col-12 col-md-6 col-lg-6\\\">\\r\\n              <div class=\\\"single-contact-info\\\">\\r\\n                <div class=\\\"contact-icon\\\">\\r\\n                  <i class=\\\"ion-android-call\\\"><\\/i>\\r\\n                <\\/div>\\r\\n                <div class=\\\"contact-info-dec\\\">\\r\\n                  <p><a href=\\\"tel:\\/\\/+421 908 897 149\\\">+421 908 897 149<\\/a><\\/p>\\r\\n                <\\/div>\\r\\n              <\\/div>\\r\\n            <\\/div>\\r\\n            <div class=\\\"col-12 col-md-6 col-lg-6\\\">\\r\\n              <div class=\\\"single-contact-info\\\">\\r\\n                <div class=\\\"contact-icon\\\">\\r\\n                  <i class=\\\"ion-android-globe\\\"><\\/i>\\r\\n                <\\/div>\\r\\n                <div class=\\\"contact-info-dec\\\">\\r\\n                  <p><a href=\\\"mailto:\\/\\/info@surikata.io\\\">info@surikata.io<\\/a><\\/p>\\r\\n                <\\/div>\\r\\n              <\\/div>\\r\\n            <\\/div>\\r\\n            <div class=\\\"col-12\\\">\\r\\n              <div class=\\\"single-contact-info\\\">\\r\\n                <div class=\\\"contact-icon\\\">\\r\\n                  <i class=\\\"ion-android-pin\\\"><\\/i>\\r\\n                <\\/div>\\r\\n                <div class=\\\"contact-info-dec\\\">\\r\\n                  <p>WAI s.r.o<br\\/>\\r\\n                    Sl\\u00e1dkovi\\u010dova 10<br\\/>\\r\\n                    921 01 Pie\\u0161\\u0165any<\\/p>\\r\\n                <\\/div>\\r\\n              <\\/div>\\r\\n            <\\/div>\\r\\n          <\\/div>\\r\\n          <div class=\\\"contact-social\\\">\\r\\n            <h3>Sledujte n\\u00e1s<\\/h3>\\r\\n            <div class=\\\"social-info\\\">\\r\\n              <ul>\\r\\n                <li>\\r\\n                  <a href=\\\"#\\\"><i class=\\\"ion-social-facebook\\\"><\\/i><\\/a>\\r\\n                <\\/li>\\r\\n                <li>\\r\\n                  <a href=\\\"#\\\"><i class=\\\"ion-social-youtube\\\"><\\/i><\\/a>\\r\\n                <\\/li>\\r\\n                <li>\\r\\n                  <a href=\\\"#\\\"><i class=\\\"ion-social-instagram\\\"><\\/i><\\/a>\\r\\n                <\\/li>\\r\\n              <\\/ul>\\r\\n            <\\/div>\\r\\n          <\\/div>\\r\\n        <\\/div>\\r\\n      <\\/div>\\r\\n      <div class=\\\"col-lg-6 col-md-9\\\">\\r\\n        <div class=\\\"contact-form\\\">\\r\\n          <div class=\\\"contact-title mb-30\\\">\\r\\n            <h2>Nechajte n\\u00e1m spr\\u00e1vu<\\/h2>\\r\\n          <\\/div>\\r\\n          <form class=\\\"contact-form-style\\\" id=\\\"contact-form\\\" onsubmit=\\\"return false;\\\" method=\\\"post\\\">\\r\\n            <div class=\\\"row\\\">\\r\\n              <div class=\\\"col-lg-6\\\">\\r\\n                <input name=\\\"name\\\" placeholder=\\\"Meno*\\\" type=\\\"text\\\" onblur=\\\"validateInputs(this)\\\"\\/>\\r\\n              <\\/div>\\r\\n              <div class=\\\"col-lg-6\\\">\\r\\n                <input name=\\\"email\\\" placeholder=\\\"Email*\\\" type=\\\"email\\\" onblur=\\\"validateInputs(this)\\\"\\/>\\r\\n              <\\/div>\\r\\n              <div class=\\\"col-lg-12\\\">\\r\\n                <input name=\\\"phone_number\\\" placeholder=\\\"Telef\\u00f3n*\\\" type=\\\"text\\\" onblur=\\\"validateInputs(this)\\\"\\/>\\r\\n              <\\/div>\\r\\n              <div class=\\\"col-lg-12\\\">\\r\\n                <textarea name=\\\"contact_message\\\" placeholder=\\\"Va\\u0161a spr\\u00e1va*\\\" onblur=\\\"validateInputs(this)\\\"><\\/textarea>\\r\\n                <button class=\\\"submit\\\" type=\\\"button\\\" onclick=\\\"sendContactForm(\'#contact-form\')\\\">Posla\\u0165 spr\\u00e1vu<\\/button>\\r\\n              <\\/div>\\r\\n            <\\/div>\\r\\n          <\\/form>\\r\\n          <p class=\\\"form-messege\\\"><\\/p>\\r\\n        <\\/div>\\r\\n      <\\/div>\\r\\n    <\\/div>\\r\\n    <div class=\\\"contact-map\\\">\\r\\n      <div id=\\\"map\\\">\\r\\n        <script async\\r\\n                src=\\\"https:\\/\\/maps.googleapis.com\\/maps\\/api\\/js?key=AIzaSyDf7R5KF87EYvZJHlrByQ6l2tdlcfYUuv0&callback=initMap\\\">\\r\\n        <\\/script>\\r\\n        <script>\\r\\n          let map;\\r\\n\\r\\n          function initMap() {\\r\\n            map = new google.maps.Map(document.getElementById(\'map\'), {\\r\\n              center: {lat: 48.5893312, lng: 17.8251578},\\r\\n              zoom: 15\\r\\n            });\\r\\n          }\\r\\n        <\\/script>\\r\\n      <\\/div>\\r\\n    <\\/div>\\r\\n  <\\/div>\\r\\n<\\/div>\"}}}}', publish_always = 1, seo_title='Contact', seo_description='Contact';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Search', url='search', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Misc\\/WebsiteSearch\",\"settings\":{\"heading\":\"Search\",\"numberOfResults\":10,\"searchInProducts\":\"name_lang,brief_lang,description_lang\",\"searchInProductCategories\":\"name_lang\",\"searchInBlogs\":\"name,content\"}}}}', publish_always = 1, seo_title='Search', seo_description='Search';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Products', url='products', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"sidebar\":{\"plugin\":\"WAI\\/Product\\/Filter\",\"settings\":{\"showProductCategories\":1,\"layout\":\"sidebar\",\"showBrands\":1,\"showFeaturesFilter\":1}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/Product\\/Catalog\",\"settings\":{\"defaultItemsPerPage\":6}}}}', publish_always = 1, seo_title='Products', seo_description='Products';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='We recommend', url='we-recommend', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/SimpleContent\\/H2\",\"settings\":{\"heading\":\"Discounts\"}},\"section_3\":{\"plugin\":\"WAI\\/Product\\/FilteredList\",\"settings\":{\"filterType\":\"on_sale\",\"layout\":\"tiles\",\"product_count\":99}},\"section_4\":{\"plugin\":\"WAI\\/SimpleContent\\/H2\",\"settings\":{\"heading\":\"Sale out\"}},\"section_5\":{\"plugin\":\"WAI\\/Product\\/FilteredList\",\"settings\":{\"filterType\":\"sale_out\",\"layout\":\"tiles\",\"product_count\":99}}}}', publish_always = 1, seo_title='We recommend', seo_description='We recommend';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Product detail', url='', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/Product\\/Detail\",\"settings\":{\"show_similar_products\":1,\"show_accessories\":1,\"showAuthor\":1}}}}', publish_always = 1, seo_title='Product detail', seo_description='Product detail';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Cart', url='cart', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Order\\/CartOverview\"}}}', publish_always = 1, seo_title='Cart', seo_description='Cart';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Checkout', url='checkout', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Order\\/Checkout\"}}}', publish_always = 1, seo_title='Checkout', seo_description='Checkout';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Order confirmed', url='', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Order\\/Confirmation\"}}}', publish_always = 1, seo_title='Order confirmed', seo_description='Order confirmed';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Order payment received', url='', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Order\\/PaymentConfirmation\"}}}', publish_always = 1, seo_title='Order payment received', seo_description='Order payment received';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Create Account', url='create-account', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/Registration\",\"settings\":{\"showPrivacyTerms\":1,\"privacyTermsUrl\":\"privacy-terms\"}}}}', publish_always = 1, seo_title='Create Account', seo_description='Create Account';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Create Account - Confirmation', url='create-account/confirmation', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/RegistrationConfirmation\"}}}', publish_always = 1, seo_title='Create Account - Confirmation', seo_description='Create Account - Confirmation';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='My account - Validation', url='', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/ValidationConfirmation\"}}}', publish_always = 1, seo_title='My account - Validation', seo_description='My account - Validation';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Reset Password', url='reset-password', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/ForgotPassword\"}}}', publish_always = 1, seo_title='Reset Password', seo_description='Reset Password';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='My Account', url='my-account', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/Home\"}}}', publish_always = 1, seo_title='My Account', seo_description='My Account';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='My Account - Orders', url='my-account/orders', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/OrderList\"}}}', publish_always = 1, seo_title='My Account - Orders', seo_description='My Account - Orders';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='My Account - Sign in', url='sign-in', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/Customer\\/Login\",\"settings\":{\"showPrivacyTerms\":1,\"privacyTermsUrl\":\"privacy-terms\"}}}}', publish_always = 1, seo_title='My Account - Sign in', seo_description='My Account - Sign in';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Privacy Terms', url='privacy-terms', `content_structure` = '{\"layout\":\"WithoutSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"section_1\":{\"plugin\":\"WAI\\/SimpleContent\\/OneColumn\",\"settings\":{\"heading\":\"We value your privacy\",\"content\":\"<b>Lorem Ipsum is simply dummy text<\\/b> of the printing and typesetting industry.\\r\\nLorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,\\r\\nwhen an unknown printer took a galley of type and scrambled it to make a type\\r\\nspecimen book. It has survived not only five centuries, but also the leap into\\r\\nelectronic typesetting, remaining essentially unchanged. It was popularised in\\r\\nthe 1960s with the release of Letraset sheets containing Lorem Ipsum passages,\\r\\nand more recently with desktop publishing software like Aldus PageMaker including\\r\\nversions of Lorem Ipsum.\"}}}}', publish_always = 1, seo_title='Privacy Terms', seo_description='Privacy Terms';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='News', url='news', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"sidebar\":{\"plugin\":\"WAI\\/News\",\"settings\":{\"contentType\":\"sidebar\"}},\"section_1\":{\"plugin\":\"WAI\\/News\",\"settings\":{\"contentType\":\"listOrDetail\"}}}}', publish_always = 1, seo_title='News', seo_description='News';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Blog', url='blog', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"sidebar\":{\"plugin\":\"WAI\\/Blog\\/Sidebar\",\"settings\":{\"showRecent\":1,\"showArchive\":1,\"showAdvertising\":1}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/Blog\\/Catalog\",\"settings\":{\"itemsPerPage\":3,\"showAuthor\":1}}}}', publish_always = 1, seo_title='Blog', seo_description='Blog';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Blog', url='', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"sidebar\":{\"plugin\":\"WAI\\/Blog\\/Sidebar\",\"settings\":{\"showRecent\":1,\"showArchive\":1,\"showAdvertising\":1}},\"section_1\":{\"plugin\":\"WAI\\/Common\\/Breadcrumb\",\"settings\":{\"showHomePage\":1}},\"section_2\":{\"plugin\":\"WAI\\/Blog\\/Detail\"}}}', publish_always = 1, seo_title='Blog', seo_description='Blog';;
insert into `srkt_web_redirects` set `id`=null, domain='language-cz', from_url='', to_url='//{% SERVER_HTTP_HOST %}{% REWRITE_BASE %}cz/uvod', type='302';;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/companyInfo/slogan',
              `value` = 'Môj nový eshop: language-cz'
            on duplicate key update
              `path` = 'settings/web/language-cz/companyInfo/slogan',
              `value` = 'Môj nový eshop: language-cz'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/companyInfo/contactPhoneNumber',
              `value` = '+421 111 222 333'
            on duplicate key update
              `path` = 'settings/web/language-cz/companyInfo/contactPhoneNumber',
              `value` = '+421 111 222 333'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/companyInfo/contactEmail',
              `value` = 'info@{% SERVER_HTTP_HOST %}'
            on duplicate key update
              `path` = 'settings/web/language-cz/companyInfo/contactEmail',
              `value` = 'info@{% SERVER_HTTP_HOST %}'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/companyInfo/logo',
              `value` = 'your-logo.png'
            on duplicate key update
              `path` = 'settings/web/language-cz/companyInfo/logo',
              `value` = 'your-logo.png'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/companyInfo/urlFacebook',
              `value` = 'https://surikata.io'
            on duplicate key update
              `path` = 'settings/web/language-cz/companyInfo/urlFacebook',
              `value` = 'https://surikata.io'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/companyInfo/urlTwitter',
              `value` = 'https://surikata.io'
            on duplicate key update
              `path` = 'settings/web/language-cz/companyInfo/urlTwitter',
              `value` = 'https://surikata.io'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/companyInfo/urlYouTube',
              `value` = 'https://surikata.io'
            on duplicate key update
              `path` = 'settings/web/language-cz/companyInfo/urlYouTube',
              `value` = 'https://surikata.io'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/companyInfo/urlInstagram',
              `value` = 'https://surikata.io'
            on duplicate key update
              `path` = 'settings/web/language-cz/companyInfo/urlInstagram',
              `value` = 'https://surikata.io'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/themeMainColor',
              `value` = '#17C3B2'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/themeMainColor',
              `value` = '#17C3B2'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/themeSecondColor',
              `value` = '#222222'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/themeSecondColor',
              `value` = '#222222'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/themeThirdColor',
              `value` = '#FE6D73'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/themeThirdColor',
              `value` = '#FE6D73'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/themeGreyColor',
              `value` = '#888888'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/themeGreyColor',
              `value` = '#888888'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/themeLightGreyColor',
              `value` = '#f5f5f5'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/themeLightGreyColor',
              `value` = '#f5f5f5'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/bodyBgColor',
              `value` = '#ffffff'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/bodyBgColor',
              `value` = '#ffffff'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/bodyTextColor',
              `value` = '#333333'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/bodyTextColor',
              `value` = '#333333'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/bodyLinkColor',
              `value` = '#17C3B2'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/bodyLinkColor',
              `value` = '#17C3B2'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/bodyHeadingColor',
              `value` = '#333333'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/bodyHeadingColor',
              `value` = '#333333'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/headerBgColor',
              `value` = '#000000'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/headerBgColor',
              `value` = '#000000'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/headerTextColor',
              `value` = '#333333'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/headerTextColor',
              `value` = '#333333'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/headerLinkColor',
              `value` = '#17C3B2'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/headerLinkColor',
              `value` = '#17C3B2'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/headerHeadingColor',
              `value` = '#ffffff'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/headerHeadingColor',
              `value` = '#ffffff'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/footerBgColor',
              `value` = '#222222'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/footerBgColor',
              `value` = '#222222'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/footerTextColor',
              `value` = '#f8f1e4'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/footerTextColor',
              `value` = '#f8f1e4'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/footerLinkColor',
              `value` = '#17C3B2'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/footerLinkColor',
              `value` = '#17C3B2'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/footerHeadingColor',
              `value` = '#ffffff'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/footerHeadingColor',
              `value` = '#ffffff'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/custom_css',
              `value` = '\r\n        li.slideshow-basic {\r\n          background: rgb(29,6,7);\r\n          background: linear-gradient(180deg, rgba(29,6,7,1) 0%, rgba(29,6,7,0.75) 15%, rgba(73,18,18,0.6) 35%, rgba(156,36,38,0) 100%);\r\n        }\r\n        .rslides {\r\n          background: #000;\r\n        }\r\n      '
            on duplicate key update
              `path` = 'settings/web/language-cz/design/custom_css',
              `value` = '\r\n        li.slideshow-basic {\r\n          background: rgb(29,6,7);\r\n          background: linear-gradient(180deg, rgba(29,6,7,1) 0%, rgba(29,6,7,0.75) 15%, rgba(73,18,18,0.6) 35%, rgba(156,36,38,0) 100%);\r\n        }\r\n        .rslides {\r\n          background: #000;\r\n        }\r\n      '
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/theme',
              `value` = 'Basic'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/theme',
              `value` = 'Basic'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/headerMenuID',
              `value` = '201'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/headerMenuID',
              `value` = '201'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/design/footerMenuID',
              `value` = '202'
            on duplicate key update
              `path` = 'settings/web/language-cz/design/footerMenuID',
              `value` = '202'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/legalDisclaimers/generalTerms',
              `value` = 'Bienvenue. VOP!'
            on duplicate key update
              `path` = 'settings/web/language-cz/legalDisclaimers/generalTerms',
              `value` = 'Bienvenue. VOP!'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/legalDisclaimers/privacyPolicy',
              `value` = 'Bienvenue. OOU!'
            on duplicate key update
              `path` = 'settings/web/language-cz/legalDisclaimers/privacyPolicy',
              `value` = 'Bienvenue. OOU!'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/legalDisclaimers/returnPolicy',
              `value` = 'Bienvenue. RP!'
            on duplicate key update
              `path` = 'settings/web/language-cz/legalDisclaimers/returnPolicy',
              `value` = 'Bienvenue. RP!'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/emails/signature',
              `value` = '<p>language-cz - <a href=\'http://language-cz\' target=\'_blank\'>language-cz</a></p>'
            on duplicate key update
              `path` = 'settings/web/language-cz/emails/signature',
              `value` = '<p>language-cz - <a href=\'http://language-cz\' target=\'_blank\'>language-cz</a></p>'
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/emails/after_order_confirmation_SUBJECT',
              `value` = ''
            on duplicate key update
              `path` = 'settings/web/language-cz/emails/after_order_confirmation_SUBJECT',
              `value` = ''
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/emails/after_order_confirmation_BODY',
              `value` = ''
            on duplicate key update
              `path` = 'settings/web/language-cz/emails/after_order_confirmation_BODY',
              `value` = ''
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/emails/after_registration_SUBJECT',
              `value` = ''
            on duplicate key update
              `path` = 'settings/web/language-cz/emails/after_registration_SUBJECT',
              `value` = ''
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/emails/after_registration_BODY',
              `value` = ''
            on duplicate key update
              `path` = 'settings/web/language-cz/emails/after_registration_BODY',
              `value` = ''
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/emails/forgotten_password_SUBJECT',
              `value` = ''
            on duplicate key update
              `path` = 'settings/web/language-cz/emails/forgotten_password_SUBJECT',
              `value` = ''
;;

            insert into `srkt_adios_config` set
              `path` = 'settings/web/language-cz/emails/forgotten_password_BODY',
              `value` = ''
            on duplicate key update
              `path` = 'settings/web/language-cz/emails/forgotten_password_BODY',
              `value` = ''
;;
start transaction;;
insert into `srkt_blogs_tags` set `id`='201', domain='language-cz', name='Computers', `description` = 'All about computers';;
insert into `srkt_blogs_tags` set `id`='202', domain='language-cz', name='Business', `description` = 'All about business';;
insert into `srkt_blogs_tags` set `id`='203', domain='language-cz', name='Fashion', `description` = 'All about fashion';;
insert into `srkt_blogs` set `id`='201', domain='language-cz', name='Blog [language-cz] #1', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='201', id_tag='201';;
insert into `srkt_blogs` set `id`='202', domain='language-cz', name='Blog [language-cz] #2', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='202', id_tag='202';;
insert into `srkt_blogs` set `id`='203', domain='language-cz', name='Blog [language-cz] #3', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='203', id_tag='201';;
insert into `srkt_blogs` set `id`='204', domain='language-cz', name='Blog [language-cz] #4', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='204', id_tag='201';;
insert into `srkt_blogs` set `id`='205', domain='language-cz', name='Blog [language-cz] #5', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='205', id_tag='201';;
insert into `srkt_blogs` set `id`='206', domain='language-cz', name='Blog [language-cz] #6', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='206', id_tag='203';;
insert into `srkt_blogs` set `id`='207', domain='language-cz', name='Blog [language-cz] #7', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='207', id_tag='201';;
insert into `srkt_blogs` set `id`='208', domain='language-cz', name='Blog [language-cz] #8', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='208', id_tag='201';;
insert into `srkt_blogs` set `id`='209', domain='language-cz', name='Blog [language-cz] #9', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='209', id_tag='201';;
insert into `srkt_blogs` set `id`='210', domain='language-cz', name='Blog [language-cz] #10', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='210', id_tag='201';;
insert into `srkt_blogs` set `id`='211', domain='language-cz', name='Blog [language-cz] #11', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='211', id_tag='202';;
insert into `srkt_blogs` set `id`='212', domain='language-cz', name='Blog [language-cz] #12', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='212', id_tag='202';;
insert into `srkt_blogs` set `id`='213', domain='language-cz', name='Blog [language-cz] #13', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='213', id_tag='202';;
insert into `srkt_blogs` set `id`='214', domain='language-cz', name='Blog [language-cz] #14', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='214', id_tag='203';;
insert into `srkt_blogs` set `id`='215', domain='language-cz', name='Blog [language-cz] #15', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='215', id_tag='202';;
insert into `srkt_blogs` set `id`='216', domain='language-cz', name='Blog [language-cz] #16', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='216', id_tag='201';;
insert into `srkt_blogs` set `id`='217', domain='language-cz', name='Blog [language-cz] #17', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='217', id_tag='202';;
insert into `srkt_blogs` set `id`='218', domain='language-cz', name='Blog [language-cz] #18', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='218', id_tag='201';;
insert into `srkt_blogs` set `id`='219', domain='language-cz', name='Blog [language-cz] #19', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='219', id_tag='202';;
insert into `srkt_blogs` set `id`='220', domain='language-cz', name='Blog [language-cz] #20', `content` = '<h2>Maecenas volutpat pulvinar convallis.</h2>\r\n<p><br></p>\r\n<p>Fusce a feugiat eros. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. \r\nInteger luctus consequat ullamcorper. Nam urna eros, scelerisque ut ullamcorper non, tempor vitae sapien. \r\nIn dapibus dolor finibus orci sollicitudin congue. Aliquam pharetra purus dolor, ut fringilla diam porttitor condimentum. \r\nFusce porttitor turpis vel sem pulvinar fermentum. Mauris ut nulla tempor lectus lacinia fermentum at a massa. Nullam sit amet porta augue, sit amet convallis tortor. \r\nPraesent ornare augue vel dolor porttitor viverra. Maecenas vehicula, <strong>lorem at consequat accumsan</strong>, leo leo varius erat, et facilisis dolor mauris eget lorem. \r\nMaecenas dapibus justo non dolor porta, ac molestie nulla eleifend. Praesent ut elit mauris. Aliquam blandit lectus varius, pulvinar nibh et, euismod lectus.</p>\r\n\r\n<h2>Cras sagittis, velit quis bibendum lacinia.</h2>\r\n<p><br></p> \r\n<p><em>Justo augue pretium erat, nec auctor est justo nec erat. Integer finibus tortor interdum erat blandit, ut hendrerit leo pretium.</em></p>\r\n<p>Vivamus non venenatis nisi. In sed metus ut lacus tincidunt ornare. \r\nQuisque arcu lorem, luctus vitae eros eu, viverra maximus erat. Vivamus vulputate commodo massa a lobortis. Cras venenatis ante orci, sed mattis orci cursus in. \r\nPhasellus at ultricies elit, sit amet fringilla velit. Integer aliquam odio vel lacus posuere vestibulum. Mauris sit amet erat blandit, ultricies diam id, ultricies nibh.</p>\r\n\r\n<h2>Cras sed mi ac ligula finibus sagittis in id mauris.</h2>\r\n<p><br></p>\r\n<ol>\r\n  <li>Aliquam erat volutpat.</li> \r\n  <li>Class aptent taciti sociosqu.</li>\r\n  <li>Ad litora torquent per conubia nostra, per inceptos himenaeos.</li>\r\n</ol> \r\n<p><br></p>\r\n<p>\r\nProin accumsan diam mollis, tempus mauris id, facilisis nisl. Nulla vitae fringilla justo, ac sodales eros. Aenean lacinia est sagittis nulla congue consequat. \r\nDonec a mauris eu mi ultrices bibendum et eget mi. Praesent facilisis, quam eget interdum blandit, dolor dui facilisis erat, rutrum mollis odio enim ut orci. \r\nClass aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Interdum et malesuada fames ac ante ipsum primis in faucibus. \r\nAliquam sapien mauris, ullamcorper in molestie id, consequat nec velit. Quisque eget fermentum ipsum.\r\n</p>\r\n\r\n<h2>Vivamus non gravida dolor.</h2>\r\n<p><br></p> \r\n<p>Pellentesque dapibus commodo est, ut pulvinar diam congue a. Duis vitae lacus feugiat, varius urna eu, faucibus nisi. \r\nDonec mauris lorem, congue eu orci ac, sodales auctor dolor. Praesent porttitor metus quis sollicitudin condimentum. \r\nPhasellus vestibulum nunc diam, in ullamcorper risus cursus aliquam. Curabitur pharetra eget lectus sit amet ullamcorper. \r\nDonec lectus nisl, vulputate vitae blandit eget, iaculis sed velit. Maecenas a velit eu ligula molestie ullamcorper. \r\nAenean gravida lobortis leo non accumsan. Nulla consequat dignissim orci, eget vestibulum nisl sollicitudin vitae. \r\nDonec imperdiet ligula sed quam venenatis, non placerat tellus molestie. Pellentesque tempus enim ipsum, in rutrum enim ornare at.</p> ', `perex` = '<h3>Mauris placerat eleifend nulla, ac maximus odio pharetra a. </h3>\r\n<p><br></p>\r\n<p>Nam dignissim sit amet tellus ac scelerisque. Nunc et mollis lacus. \r\nProin eu tortor justo. Pellentesque <u>lobortis augue</u> ac dolor cursus luctus. Nulla facilisi.\r\nMauris nec feugiat sapien, id luctus mi. Mauris nibh sem, blandit nec risus sed, faucibus varius orci. \r\nIn condimentum tempor orci.</p>', image='blog.png', `created_at` = '2021-11-23', id_user='1';;
insert into `srkt_blogs_tags_assignment` set `id`=null, id_blog='220', id_tag='202';;
commit;;
insert into `srkt_homepage_slideshow` set `id`=null, domain='language-cz', heading='Welcome', description='Your best online store', button_url='produkty', button_text='Start shopping', image='slide-1.jpg';;
insert into `srkt_homepage_slideshow` set `id`=null, domain='language-cz', heading='Discounts', description='We have something special for your', button_url='discounts', button_text='Show discounts', image='slide-2.jpg';;
insert into `srkt_homepage_slideshow` set `id`=null, domain='language-cz', heading='Check our luxury products', description='We sell only most-rated and reliable products', image='slide-3.jpg';;
insert into `srkt_news` set `id`=null, title='Welcome to our online store', `content` = 'We built our online store using Surikata.io.', `perex` = 'We built our online store using Surikata.io.', domain='language-cz';;
insert into `srkt_web_pages` set `id`=null, domain='language-cz', name='Compare products', url='compare', `content_structure` = '{\"layout\":\"WithLeftSidebar\",\"panels\":{\"header\":{\"plugin\":\"WAI\\/Common\\/Header\"},\"navigation\":{\"plugin\":\"WAI\\/Common\\/Navigation\",\"settings\":{\"menuId\":201,\"homepageUrl\":\"uvod\",\"showCategories\":true}},\"footer\":{\"plugin\":\"WAI\\/Common\\/Footer\",\"settings\":{\"mainMenuId\":201,\"secondaryMenuId\":202,\"mainMenuTitle\":\"Pages\",\"secondaryMenuTitle\":\"Our Company\",\"showContactAddress\":0,\"showContactEmail\":1,\"showContactPhoneNumber\":1,\"contactTitle\":\"Contact us\",\"showPayments\":1,\"showSocialMedia\":1,\"showSecondaryMenu\":1,\"showMainMenu\":1,\"showBlogs\":1,\"Newsletter\":1,\"blogsTitle\":\"Recent blogs\"}},\"sidebar\":{\"plugin\":\"WAI\\/Product\\/Filter\",\"settings\":{\"showProductCategories\":1,\"layout\":\"sidebar\",\"showBrands\":1,\"showFeaturesFilter\":1}},\"section_1\":{\"plugin\":\"WAI\\/Proprietary\\/Product\\/Compare\"}}}', publish_always = 1, seo_title='Compare products', seo_description='Compare products';;
insert into `srkt_products_variations_attributes` set `id`='1', name_lang_1='Size', name_lang_2='Veľkosť';;
insert into `srkt_products_variations_attributes` set `id`='2', name_lang_1='Color', name_lang_2='Farba';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='1', value_lang_1='S';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='1', value_lang_1='M';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='1', value_lang_1='L';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='1', value_lang_1='XL';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='1', value_lang_1='XXL';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='2', value_lang_1='blue';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='2', value_lang_1='red';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='2', value_lang_1='green';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='2', value_lang_1='yellow';;
insert into `srkt_products_variations_values` set `id`=null, id_attribute='2', value_lang_1='brown';;
